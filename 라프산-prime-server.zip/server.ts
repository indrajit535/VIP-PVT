import crypto from 'crypto';
import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET =
  process.env.SESSION_SECRET ||
  crypto.createHash('sha256').update('sdd-pvt-quantum-core-secret').digest('hex');

const PRIMARY_PASSKEY = process.env.PASSKEY_PRIMARY || '263';

const WINGO_1M_API_URL =
  'https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json';

function parseHistoryList(json: unknown): { issueNumber: string; number: string }[] {
  const obj = json as {
    data?: { list?: unknown[] } | unknown[];
    list?: unknown[];
  };
  const rawList =
    (obj?.data && !Array.isArray(obj.data) ? obj.data.list : undefined) ||
    obj?.list ||
    (Array.isArray(obj?.data) ? obj.data : undefined) ||
    (Array.isArray(json) ? json : undefined);

  if (!Array.isArray(rawList) || rawList.length === 0) return [];

  const parsed = rawList
    .slice(0, 40)
    .map((item) => {
      const row = item as Record<string, unknown>;
      const issueNumber = String(
        row.issueNumber ?? row.issue ?? row.period ?? row.periodNumber ?? ''
      ).trim();
      const rawNum = String(
        row.number ?? row.num ?? row.result ?? row.digit ?? row.openNum ?? ''
      ).trim();
      const digit = parseInt(rawNum, 10);
      if (!issueNumber || !Number.isFinite(digit)) return null;
      return { issueNumber, number: String(Math.abs(digit) % 10) };
    })
    .filter((x): x is { issueNumber: string; number: string } => x !== null);

  parsed.sort((a, b) => (a.issueNumber < b.issueNumber ? 1 : a.issueNumber > b.issueNumber ? -1 : 0));
  return parsed;
}

function signSession(payload: Record<string, unknown>): string {
  const data = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verifyToken(token: string): Record<string, unknown> | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [data, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(data).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    return JSON.parse(Buffer.from(data, 'base64url').toString('utf8')) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function verifyPasskey(input: string): boolean {
  const trimmed = input.trim();
  if (!trimmed) return false;
  return trimmed === PRIMARY_PASSKEY;
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.post('/api/auth/verify', (req, res) => {
    const { passkey, deviceId } = req.body as { passkey?: string; deviceId?: string };
    if (typeof passkey !== 'string' || !verifyPasskey(passkey)) {
      res.status(401).json({ ok: false, error: 'INVALID PASSKEY' });
      return;
    }

    const safeDevice =
      typeof deviceId === 'string' && deviceId.trim()
        ? deviceId.trim().slice(0, 64)
        : 'SDD-Q-DEFAULT';
    const sessionPayload = {
      key: 'SDD_PVT',
      device: safeDevice,
      at: Date.now(),
      lifetime: true,
    };
    const token = signSession(sessionPayload);
    res.json({ ok: true, session: { ...sessionPayload, token } });
  });

  app.get('/api/auth/session', (req, res) => {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
    if (!token) {
      res.status(401).json({ ok: false });
      return;
    }
    const payload = verifyToken(token);
    if (!payload) {
      res.status(401).json({ ok: false });
      return;
    }
    res.json({ ok: true, session: payload });
  });

  app.get('/api/wingo/history', async (_req, res) => {
    const ts = Date.now();
    const targetUrl = `${WINGO_1M_API_URL}?ts=${ts}`;
    const attempts: { url: string; headers: Record<string, string> }[] = [
      {
        url: targetUrl,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
          Accept: 'application/json, text/plain, */*',
          'Accept-Language': 'en-US,en;q=0.9',
          Referer: 'https://draw.ar-lottery01.com/',
          Origin: 'https://draw.ar-lottery01.com',
          'Cache-Control': 'no-cache',
        },
      },
      {
        url: `https://api.allorigins.win/raw?url=${encodeURIComponent(targetUrl)}`,
        headers: { Accept: 'application/json' },
      },
    ];

    for (const attempt of attempts) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        const response = await fetch(attempt.url, {
          method: 'GET',
          headers: attempt.headers,
          signal: controller.signal,
        });
        clearTimeout(timeout);

        if (!response.ok) continue;
        const json = await response.json();
        const parsed = parseHistoryList(json);
        if (parsed.length > 0) {
          res.json({ ok: true, source: 'live', list: parsed });
          return;
        }
      } catch {
        continue;
      }
    }

    res.status(502).json({ ok: false, error: 'WinGo 1M history API unreachable from server' });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

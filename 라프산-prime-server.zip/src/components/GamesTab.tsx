import { useState } from 'react';
import { soundEngine } from '../utils/audio';

const PRESET_GAMES = [
  { name: 'WinGo 1M', url: 'https://bdggame.com' },
  { name: 'BDG Game', url: 'https://bdggame.com' },
  { name: 'Tiranga', url: 'https://tirangagames.top' },
  { name: '91Club', url: 'https://91club.com' },
];

export function GamesTab() {
  const [urlInput, setUrlInput] = useState('');
  const [activeUrl, setActiveUrl] = useState<string | null>(null);

  const launchUrl = (rawUrl: string) => {
    soundEngine.key();
    const trimmed = rawUrl.trim();
    if (!trimmed) return;
    const normalized = trimmed.startsWith('http://') || trimmed.startsWith('https://')
      ? trimmed
      : 'https://' + trimmed;
    setActiveUrl(normalized);
  };

  let hostname = 'external';
  if (activeUrl) {
    try {
      hostname = new URL(activeUrl).hostname;
    } catch {
      hostname = 'external';
    }
  }

  return (
    <div className="animate-fade-in">
      <div
        className="rounded-[22px] p-3.5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{
          background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
        }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase font-black">
          🌐 GAME PORTAL
        </h2>

        <label
          htmlFor="gameUrlInput"
          className="block text-[9px] text-[#A7F3D0] tracking-[1px] font-bold mb-1 mt-2 uppercase font-mono-jb"
        >
          ENTER GAME URL
        </label>
        <input
          id="gameUrlInput"
          type="url"
          value={urlInput}
          onChange={(e) => setUrlInput(e.target.value)}
          placeholder="https://your-game.com"
          className="w-full bg-[#0C1C13] border border-[#00FF80] rounded-[10px] text-[#E2FEE8] px-3 py-2.5 text-[13px] font-mono-jb outline-none focus:shadow-[0_0_0_3px_rgba(0,255,128,0.3)]"
        />

        <button
          type="button"
          onClick={() => launchUrl(urlInput)}
          className="w-full min-h-[44px] py-3 mt-2 rounded-xl font-orbitron font-black text-[11px] tracking-[1.5px] uppercase text-[#060D09] shadow-[0_4px_14px_rgba(0,255,128,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
          style={{ background: 'linear-gradient(135deg,#00FF80,#9333EA)' }}
        >
          ▶ OPEN GAME
        </button>

        <div className="mt-2.5 flex gap-1.5 flex-wrap">
          {PRESET_GAMES.map((g) => (
            <button
              key={g.name}
              type="button"
              onClick={() => {
                setUrlInput(g.url);
                launchUrl(g.url);
              }}
              className="min-h-[36px] px-3 py-1.5 rounded-lg font-orbitron font-black text-[9px] tracking-[1px] uppercase text-white cursor-pointer active:scale-[0.97] transition-transform"
              style={{ background: 'linear-gradient(135deg,#9333EA,#581C87)' }}
            >
              {g.name}
            </button>
          ))}
        </div>

        {activeUrl && (
          <div className="mt-3 bg-[#040A07] rounded-[14px] overflow-hidden border-2 border-[#00FF80]">
            <div className="px-3 py-2 bg-[#0E2217] text-[#A7F3D0] text-[10px] font-mono-jb flex justify-between items-center">
              <span className="text-[#00FF80] font-bold">🔒 {hostname}</span>
              <a
                href={activeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#00FF80] font-bold no-underline hover:underline"
              >
                OPEN ↗
              </a>
            </div>
            <iframe
              src={activeUrl}
              title={`Game Portal - ${hostname}`}
              className="w-full h-[420px] border-0 bg-black"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
            />
          </div>
        )}
      </div>
    </div>
  );
}

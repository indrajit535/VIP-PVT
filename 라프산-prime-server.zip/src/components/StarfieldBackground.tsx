import { useEffect, useRef } from 'react';

interface Star {
  x: number;
  y: number;
  r: number;
  color: string;
  speed: number;
  baseAlpha: number;
  phase: number;
  dx: number;
  dy: number;
}

const COLORS = ['#00FF80', '#A7F3D0', '#9333EA', '#C084FC', '#00CC66'];

export function StarfieldBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let stars: Star[] = [];
    let rafId = 0;
    let last = performance.now();
    let frame = 0;

    const resize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    const makeStars = () => {
      stars = Array.from({ length: 45 }, (_, i) => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.4 + 0.8,
        color: COLORS[i % COLORS.length],
        speed: Math.random() * 0.02 + 0.015,
        baseAlpha: Math.random() * 0.45 + 0.35,
        phase: Math.random() * Math.PI * 2,
        dx: (Math.random() - 0.5) * 0.12,
        dy: (Math.random() - 0.5) * 0.12,
      }));
    };

    const handleResize = () => {
      resize();
      makeStars();
    };

    resize();
    makeStars();

    const loop = (t: number) => {
      rafId = requestAnimationFrame(loop);
      if (t - last < 30) return;
      last = t;
      frame++;
      ctx.clearRect(0, 0, width, height);
      for (const s of stars) {
        s.x += s.dx;
        s.y += s.dy;
        if (s.x < 0) s.x = width;
        if (s.x > width) s.x = 0;
        if (s.y < 0) s.y = height;
        if (s.y > height) s.y = 0;

        const alpha = Math.max(
          0.15,
          Math.min(0.95, s.baseAlpha + Math.sin(frame * s.speed + s.phase) * 0.3)
        );
        ctx.globalAlpha = alpha;
        ctx.fillStyle = s.color;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    };

    window.addEventListener('resize', handleResize);
    rafId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
      <div
        className="absolute inset-0 pointer-events-none opacity-85"
        style={{
          background:
            'radial-gradient(circle at 50% 12%,rgba(0,255,128,.2) 0%,rgba(6,13,9,.6) 60%,transparent 90%),radial-gradient(circle at 85% 75%,rgba(147,51,234,.22) 0%,transparent 55%),radial-gradient(circle at 15% 85%,rgba(0,204,102,.15) 0%,transparent 55%)',
        }}
      />
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
}

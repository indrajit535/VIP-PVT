import { FormEvent, useEffect, useRef, useState } from 'react';
import type { UserSession } from '../types/wingo';
import { soundEngine } from '../utils/audio';
import { storage } from '../utils/storage';

interface LoginGatewayProps {
  onSuccess: (session: UserSession) => void;
  onNotify: (message: string) => void;
}

export function LoginGateway({ onSuccess, onNotify }: LoginGatewayProps) {
  const [passkey, setPasskey] = useState('');
  const [message, setMessage] = useState<{ text: string; color: string } | null>(null);
  const [shaking, setShaking] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const deviceId = storage.getDeviceId();

  useEffect(() => {
    const timer = setTimeout(() => {
      inputRef.current?.focus();
    }, 200);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmed = passkey.trim();
    if (!trimmed) {
      setMessage({ text: 'ENTER PASSWORD', color: '#9333EA' });
      soundEngine.denied();
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ passkey: trimmed, deviceId }),
      });

      const data = (await res.json()) as {
        ok?: boolean;
        session?: UserSession;
        error?: string;
      };

      if (res.ok && data.ok && data.session) {
        soundEngine.granted();
        setMessage({ text: '✓ SDD PVT ACCESS GRANTED', color: '#00FF80' });
        storage.saveSession(data.session);
        setTimeout(() => onSuccess(data.session!), 600);
      } else {
        soundEngine.denied();
        setMessage({ text: data.error || 'INVALID PASSWORD', color: '#9333EA' });
        setShaking(true);
        setTimeout(() => setShaking(false), 220);
      }
    } catch {
      soundEngine.denied();
      setMessage({ text: 'SERVER CONNECTION ERROR', color: '#9333EA' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-[90dvh] flex items-center justify-center px-2 py-6 animate-fade-in">
      <div className="w-full max-w-[420px]">
        <div className="text-center mb-5">
          <div
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold tracking-[2px] font-mono-jb border border-[#00FF80] text-[#00FF80]"
            style={{
              background: 'rgba(0,255,128,.15)',
              boxShadow: '0 0 12px rgba(0,255,128,.3)',
            }}
          >
            ⚡ SDD PVT GATEWAY
          </div>
          <h1
            className="font-orbitron text-2xl sm:text-[28px] font-black tracking-[2px] mt-3 mb-1 bg-clip-text text-transparent"
            style={{
              backgroundImage: 'linear-gradient(90deg,#00FF80,#9333EA)',
            }}
          >
            SDD PVT
          </h1>
          <div className="text-[10px] text-[#A7F3D0] tracking-[1.8px] font-bold">
            UNIFIED 1000-RULE + TITAN 200 ENGINE
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-[24px] p-4 sm:p-5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
          style={{
            background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
          }}
        >
          <div className="flex justify-between items-center pb-2.5 mb-2.5 border-b border-[#00FF80]/30 font-mono-jb text-[10px] gap-2">
            <div className="text-[#E2FEE8] font-bold truncate">
              DEVICE: <b className="text-[#00FF80]">{deviceId.slice(0, 12)}</b>
            </div>
            <div className="text-[#00FF80] bg-[#00FF80]/20 px-2 py-0.5 rounded-[10px] border border-[#00FF80] font-bold text-[9px] shrink-0">
              LIFETIME ACCESS
            </div>
          </div>

          <div
            className={`bg-[#040A07] border-2 border-dashed border-[#00FF80] rounded-[18px] p-4 text-center transition-transform ${
              shaking ? 'animate-shake' : ''
            }`}
          >
            <div className="text-[9px] text-[#00FF80] tracking-[2px] font-bold mb-1.5">
              ENTER PASSWORD
            </div>
            <input
              ref={inputRef}
              type="password"
              inputMode="numeric"
              value={passkey}
              onChange={(e) => setPasskey(e.target.value)}
              placeholder="•••"
              aria-label="Enter Login Password"
              className="w-full text-center text-xl font-black tracking-[4px] font-orbitron bg-transparent border-0 border-b-2 border-[#9333EA] rounded-none py-2 text-[#00FF80] focus:outline-none focus:border-[#00FF80]"
            />
          </div>

          <div
            className="h-[18px] text-[11px] mt-2 text-center font-bold font-mono-jb"
            style={{ color: message?.color || '#00FF80' }}
            role="status"
          >
            {message?.text || ''}
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full min-h-[46px] py-3 px-4 mt-3 rounded-xl font-orbitron font-black text-[11px] tracking-[1.5px] uppercase text-[#060D09] shadow-[0_4px_14px_rgba(0,255,128,0.4)] active:scale-[0.97] transition-transform cursor-pointer disabled:opacity-70"
            style={{
              background: 'linear-gradient(135deg,#00FF80,#9333EA)',
            }}
          >
            {submitting ? 'VERIFYING...' : '🔓 UNLOCK SDD PVT'}
          </button>

          <div className="mt-3 pt-2.5 border-t border-[#00FF80]/30 text-[10px] text-[#A7F3D0] text-center font-mono-jb">
            Need activation?{' '}
            <button
              type="button"
              onClick={() => onNotify('Contact SDD PVT Administrator for access password.')}
              className="text-[#00FF80] underline cursor-pointer bg-transparent border-0 p-1 font-mono-jb text-[10px]"
            >
              Request Password
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

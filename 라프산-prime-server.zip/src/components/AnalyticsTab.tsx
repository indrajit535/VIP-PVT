import { useEffect, useRef } from 'react';
import type { DrawRecord, PredictionResult } from '../types/wingo';

interface AnalyticsTabProps {
  history: DrawRecord[];
  prediction: PredictionResult | null;
}

export function AnalyticsTab({ history, prediction }: AnalyticsTabProps) {
  const waveRef = useRef<HTMLCanvasElement | null>(null);
  const brainRef = useRef<HTMLCanvasElement | null>(null);
  const isBigRef = useRef(true);

  useEffect(() => {
    isBigRef.current = (prediction?.size ?? 'BIG') === 'BIG';
  }, [prediction?.size]);

  useEffect(() => {
    const waveCanvas = waveRef.current;
    const brainCanvas = brainRef.current;
    if (!waveCanvas || !brainCanvas) return;
    const wCtx = waveCanvas.getContext('2d');
    const bCtx = brainCanvas.getContext('2d');
    if (!wCtx || !bCtx) return;

    let waveRaf = 0;
    let brainRaf = 0;
    let t = 0;

    const loopWave = () => {
      waveRaf = requestAnimationFrame(loopWave);
      t += 0.035;
      const w = waveCanvas.width;
      const h = waveCanvas.height;
      const bg = wCtx.createLinearGradient(0, 0, 0, h);
      bg.addColorStop(0, '#0A1C13');
      bg.addColorStop(0.5, '#1B0926');
      bg.addColorStop(1, '#040A07');
      wCtx.fillStyle = bg;
      wCtx.fillRect(0, 0, w, h);

      wCtx.strokeStyle = 'rgba(0,255,128,.1)';
      wCtx.lineWidth = 1;
      for (let x = 0; x < w; x += 24) {
        wCtx.beginPath();
        wCtx.moveTo(x, 0);
        wCtx.lineTo(x, h);
        wCtx.stroke();
      }
      for (let y = 0; y < h; y += 24) {
        wCtx.beginPath();
        wCtx.moveTo(0, y);
        wCtx.lineTo(w, y);
        wCtx.stroke();
      }

      const isBig = isBigRef.current;
      for (let i = 0; i < 3; i++) {
        const isMain = i === 2;
        wCtx.strokeStyle = isMain
          ? isBig
            ? '#00FF80'
            : '#9333EA'
          : `rgba(${isBig ? '0,255,128' : '147,51,234'},${0.25 - i * 0.05})`;
        wCtx.lineWidth = isMain ? 2.5 : 1.2;
        wCtx.shadowBlur = isMain ? 14 : 0;
        wCtx.shadowColor = isMain
          ? isBig
            ? 'rgba(0,255,128,.8)'
            : 'rgba(147,51,234,.8)'
          : 'transparent';
        wCtx.beginPath();
        for (let x = 0; x <= w; x += 3) {
          const p = (x / w) * Math.PI * 4;
          const y =
            h / 2 +
            Math.sin(p * (1.2 + i * 0.4) - t * (1 + i * 0.5)) * (22 + i * 6) +
            Math.cos(p * 0.7 + t * 0.8) * 12;
          if (x === 0) wCtx.moveTo(x, y);
          else wCtx.lineTo(x, y);
        }
        wCtx.stroke();
      }

      wCtx.shadowBlur = 0;
      const scan = (t * 80) % w;
      const g = wCtx.createLinearGradient(scan - 30, 0, scan, 0);
      g.addColorStop(0, 'rgba(0,255,128,0)');
      g.addColorStop(1, 'rgba(0,255,128,.45)');
      wCtx.fillStyle = g;
      wCtx.fillRect(scan - 30, 0, 30, h);
    };

    const bw = brainCanvas.width;
    const bh = brainCanvas.height;
    const cx = bw / 2;
    const cy = bh / 2;
    const nodes = Array.from({ length: 65 }, () => {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const R = 100;
      return {
        x: R * Math.sin(phi) * Math.cos(theta),
        y: R * Math.sin(phi) * Math.sin(theta),
        z: R * Math.cos(phi),
      };
    });

    const edges: { a: number; b: number; prog: number; speed: number }[] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dz = nodes[i].z - nodes[j].z;
        if (Math.hypot(dx, dy, dz) < 60) {
          edges.push({ a: i, b: j, prog: Math.random(), speed: 0.01 + Math.random() * 0.02 });
        }
      }
    }

    let angle = 0;
    const loopBrain = () => {
      brainRaf = requestAnimationFrame(loopBrain);
      angle += 0.008;
      const bg = bCtx.createRadialGradient(cx, cy, 10, cx, cy, 200);
      bg.addColorStop(0, 'rgba(0,255,128,.15)');
      bg.addColorStop(1, 'rgba(6,13,9,1)');
      bCtx.fillStyle = bg;
      bCtx.fillRect(0, 0, bw, bh);

      const cosA = Math.cos(angle);
      const sinA = Math.sin(angle);
      const cosT = Math.cos(angle * 0.5);
      const sinT = Math.sin(angle * 0.5);

      const proj = nodes.map((n) => {
        const x1 = n.x * cosA + n.z * sinA;
        const z1 = -n.x * sinA + n.z * cosA;
        const y1 = n.y * cosT - z1 * sinT;
        const z2 = n.y * sinT + z1 * cosT;
        const s = 260 / (260 + z2 + 150);
        return { px: cx + x1 * s * 2, py: cy + y1 * s * 2, z: z2, s };
      });

      edges.forEach((e) => {
        const a = proj[e.a];
        const b = proj[e.b];
        const alpha = Math.max(0.05, (a.z + b.z + 200) / 400) * 0.5;
        bCtx.strokeStyle = `rgba(0,255,128,${alpha})`;
        bCtx.lineWidth = 0.8;
        bCtx.beginPath();
        bCtx.moveTo(a.px, a.py);
        bCtx.lineTo(b.px, b.py);
        bCtx.stroke();

        e.prog = (e.prog + e.speed) % 1;
        const sx = a.px + (b.px - a.px) * e.prog;
        const sy = a.py + (b.py - a.py) * e.prog;
        bCtx.fillStyle = '#00FF80';
        bCtx.shadowBlur = 8;
        bCtx.shadowColor = '#00FF80';
        bCtx.beginPath();
        bCtx.arc(sx, sy, 1.8, 0, Math.PI * 2);
        bCtx.fill();
        bCtx.shadowBlur = 0;
      });

      proj
        .slice()
        .sort((a, b) => a.z - b.z)
        .forEach((p) => {
          const rad = 3.5 * p.s;
          const glow = bCtx.createRadialGradient(
            p.px - rad * 0.3,
            p.py - rad * 0.3,
            rad * 0.1,
            p.px,
            p.py,
            rad
          );
          glow.addColorStop(0, '#FFFFFF');
          glow.addColorStop(0.5, '#00FF80');
          glow.addColorStop(1, '#9333EA');
          bCtx.fillStyle = glow;
          bCtx.shadowBlur = 12;
          bCtx.shadowColor = '#00FF80';
          bCtx.beginPath();
          bCtx.arc(p.px, p.py, rad, 0, Math.PI * 2);
          bCtx.fill();
          bCtx.shadowBlur = 0;
        });
    };

    waveRaf = requestAnimationFrame(loopWave);
    brainRaf = requestAnimationFrame(loopBrain);

    return () => {
      cancelAnimationFrame(waveRaf);
      cancelAnimationFrame(brainRaf);
    };
  }, []);

  const sample = history.slice(0, 100);
  let bigCount = 0;
  sample.forEach((d) => {
    if (parseInt(String(d.number), 10) >= 5) bigCount++;
  });
  const bigPct = sample.length > 0 ? Math.round((bigCount / sample.length) * 100) : 50;

  return (
    <div className="animate-fade-in grid grid-cols-1 lg:grid-cols-2 gap-3">
      <div
        className="rounded-[22px] p-3 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{
          background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
        }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase font-black">
          📈 QUANTUM OSCILLOSCOPE
        </h2>
        <div className="w-full h-[200px] lg:h-[260px] rounded-2xl overflow-hidden relative bg-[#040A07] border border-[#00FF80]">
          <canvas ref={waveRef} width={600} height={220} className="w-full h-full block" />
          <div className="absolute top-2 left-2 right-2 flex justify-between pointer-events-none font-mono-jb text-[9px] font-bold tracking-[0.7px]">
            <span className="bg-[#0A1810]/85 px-2 py-1 rounded border border-[#00FF80]/40 text-[#00FF80]">
              MODE: DRAGON_STRIKE
            </span>
            <span className="bg-[#0A1810]/85 px-2 py-1 rounded border border-[#9333EA]/50 text-[#C084FC]">
              60 FPS
            </span>
          </div>
        </div>
      </div>

      <div
        className="rounded-[22px] p-3 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{
          background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
        }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase font-black">
          🧠 3D NEURAL CORE
        </h2>
        <div className="w-full h-[260px] rounded-2xl overflow-hidden relative bg-[#040A07] border border-[#00FF80]">
          <canvas ref={brainRef} width={600} height={300} className="w-full h-full block" />
          <div className="absolute top-2 left-2 right-2 flex justify-between pointer-events-none font-mono-jb text-[9px] font-bold tracking-[0.7px]">
            <span className="bg-[#0A1810]/85 px-2 py-1 rounded border border-[#00FF80]/40 text-[#00FF80]">
              DRAGON ENGINE
            </span>
            <span className="bg-[#0A1810]/85 px-2 py-1 rounded border border-[#9333EA]/50 text-[#C084FC]">
              CORES: 12
            </span>
          </div>
        </div>
      </div>

      <div
        className="lg:col-span-2 rounded-[22px] p-3.5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{
          background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
        }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase font-black">
          📊 LIVE STATS
        </h2>
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2.5 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              BIG RATIO
            </div>
            <div className="text-sm font-bold text-[#00FF80] mt-1 font-mono-jb">{bigPct}%</div>
          </div>
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2.5 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              SMALL RATIO
            </div>
            <div className="text-sm font-bold text-[#C084FC] mt-1 font-mono-jb">
              {100 - bigPct}%
            </div>
          </div>
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2.5 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              SAMPLES
            </div>
            <div className="text-sm font-bold text-[#00FF80] mt-1 font-mono-jb">
              {sample.length}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

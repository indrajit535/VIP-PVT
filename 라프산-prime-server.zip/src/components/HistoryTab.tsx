import type { HistoryEntry } from '../types/wingo';

interface HistoryTabProps {
  trackerHistory: HistoryEntry[];
  onManualResult: (isWin: boolean) => void;
  onClearHistory: () => void;
}

export function HistoryTab({
  trackerHistory,
  onManualResult,
  onClearHistory,
}: HistoryTabProps) {
  const jacks = trackerHistory.filter((h) => h.isJackpot).length;
  const wins = trackerHistory.filter((h) => h.isWin && !h.isJackpot).length;
  const totalWins = wins + jacks;
  const losses = trackerHistory.filter((h) => !h.isWin).length;
  const rate =
    trackerHistory.length > 0 ? Math.round((totalWins / trackerHistory.length) * 100) : 0;

  let streak = 0;
  for (const h of trackerHistory) {
    if (h.isWin) streak++;
    else break;
  }

  const profit = trackerHistory.reduce((sum, h) => sum + (h.profit || 0), 0);

  return (
    <div className="animate-fade-in flex flex-col gap-3">
      <div
        className="rounded-[22px] p-3.5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{
          background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
        }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase flex items-center justify-between font-black">
          <span>🏆 WIN/LOSS DRAGON TRACKER</span>
          <button
            type="button"
            onClick={onClearHistory}
            className="min-h-[34px] px-3 py-1.5 rounded-lg font-orbitron font-black text-[9px] tracking-[1.2px] uppercase text-white cursor-pointer active:scale-[0.97] transition-transform"
            style={{ background: 'linear-gradient(135deg,#9333EA,#581C87)' }}
          >
            CLEAR
          </button>
        </h2>

        <div className="grid grid-cols-3 md:grid-cols-6 gap-1.5 mt-2">
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              WINS
            </div>
            <div className="text-[13px] font-bold text-[#00FF80] mt-0.5 font-mono-jb">
              {totalWins}
            </div>
          </div>
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              LOSSES
            </div>
            <div className="text-[13px] font-bold text-[#C084FC] mt-0.5 font-mono-jb">
              {losses}
            </div>
          </div>
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              WIN RATE
            </div>
            <div className="text-[13px] font-bold text-[#00FF80] mt-0.5 font-mono-jb">
              {rate}%
            </div>
          </div>
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              STREAK
            </div>
            <div className="text-[13px] font-bold text-[#00FF80] mt-0.5 font-mono-jb">
              {streak}
            </div>
          </div>
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              JACKPOTS
            </div>
            <div className="text-[13px] font-bold text-[#00FF80] mt-0.5 font-mono-jb">
              {jacks}
            </div>
          </div>
          <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
            <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
              PROFIT
            </div>
            <div
              className={`text-[13px] font-bold mt-0.5 font-mono-jb ${
                profit >= 0 ? 'text-[#00FF80]' : 'text-[#C084FC]'
              }`}
            >
              {profit.toFixed(2)}u
            </div>
          </div>
        </div>

        <div className="flex gap-1.5 mt-2.5">
          <button
            type="button"
            onClick={() => onManualResult(true)}
            className="flex-1 min-h-[44px] py-2.5 rounded-xl font-orbitron font-black text-[10px] tracking-[1.5px] uppercase text-[#060D09] shadow-[0_4px_14px_rgba(0,255,128,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
            style={{ background: 'linear-gradient(135deg,#00FF80,#008040)' }}
          >
            + WIN
          </button>
          <button
            type="button"
            onClick={() => onManualResult(false)}
            className="flex-1 min-h-[44px] py-2.5 rounded-xl font-orbitron font-black text-[10px] tracking-[1.5px] uppercase text-white shadow-[0_4px_14px_rgba(147,51,234,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
            style={{ background: 'linear-gradient(135deg,#9333EA,#581C87)' }}
          >
            + LOSS
          </button>
        </div>
      </div>

      <div
        className="rounded-[22px] p-3.5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{
          background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
        }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase font-black">
          📋 RESULTS LOG
        </h2>

        {trackerHistory.length === 0 ? (
          <div className="text-[#A7F3D0] italic text-[11px] text-center py-4 font-mono-jb">
            No prediction records yet
          </div>
        ) : (
          <div className="flex flex-col gap-1.5">
            {trackerHistory.slice(0, 50).map((h) => {
              const label = h.isJackpot ? 'JACKPOT' : h.isWin ? 'WIN' : 'LOSS';
              const borderCls = h.isWin
                ? 'border-[#00FF80]/70 bg-[#00FF80]/10'
                : 'border-[#9333EA]/70 bg-[#9333EA]/10';
              return (
                <div
                  key={h.id}
                  className={`flex justify-between items-center gap-2 px-2.5 py-2.5 rounded-[11px] text-[11px] border ${borderCls}`}
                >
                  <div className="flex flex-col gap-0.5 min-w-0 flex-1">
                    <div className="font-bold text-[#00FF80] font-mono-jb text-[10px]">
                      #{String(h.period).slice(-6)}
                    </div>
                    <div className="text-[9px] text-[#A7F3D0] font-mono-jb truncate">
                      {h.time} · P:{h.predicted}(#{h.predictedBall}) · A:{h.actualNumber}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 font-mono-jb text-[9px] font-bold">
                    <span className="text-[#E2FEE8]">{h.actualSize}</span>
                    <span className="text-[#A7F3D0]/50" aria-hidden="true">
                      /
                    </span>
                    <span
                      className={
                        h.isJackpot
                          ? 'text-[#00FF80] font-black'
                          : h.isWin
                          ? 'text-[#00FF80]'
                          : 'text-[#F5D0FE]'
                      }
                    >
                      {label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

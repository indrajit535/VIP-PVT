import type { PredictionResult } from '../types/wingo';
import { ballColor } from '../utils/engine';

interface QuantumRadarProps {
  prediction: PredictionResult | null;
}

const DEGREE_TICKS = [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330];

export function QuantumRadar({ prediction }: QuantumRadarProps) {
  const pred: PredictionResult = prediction ?? {
    period: '---',
    size: 'BIG',
    color: 'GREEN',
    ball: 7,
    opposite: 2,
    safe: [5, 7, 8],
    level: 1,
    mult: '1X',
    confidence: 89.0,
    algo: 'SDD PVT UNIFIED CORE',
    combined: {
      votesBig: 50,
      votesSmall: 50,
      patterns: [],
      top: null,
      direction: 'BIG',
      confidence: 89.0,
      telemetry: {
        titan200Triggered: 0,
        titan200TopPattern: 'INIT',
        formulaName: 'TITAN-NEURAL',
        formulaScore: 0,
        samadHash: null,
        samadSize: null,
        regimeName: 'NEUTRAL',
        regimeIcon: '≈',
        oracleMatch: null,
        rules1000Triggered: 0,
        rules1000BigScore: 0,
        rules1000SmallScore: 0,
        rules1000Confidence: 50,
        recoveryActive: false,
        triColor: 'GREEN',
      },
    },
  };

  const isBig = pred.size === 'BIG';
  const tCls = ballColor(pred.ball).cls;
  const oCls = ballColor(pred.opposite).cls;

  const cx1 = Math.round(170 + 135 * Math.cos(-Math.PI / 4));
  const cy1 = Math.round(170 + 135 * Math.sin(-Math.PI / 4));
  const cx2 = Math.round(170 + 135 * Math.cos((3 * Math.PI) / 4));
  const cy2 = Math.round(170 + 135 * Math.sin((3 * Math.PI) / 4));
  const g1 = tCls === 'g' ? 'ballG' : 'ballP';
  const g2 = oCls === 'g' ? 'ballG' : 'ballP';

  return (
    <div className="relative w-full aspect-square max-w-[270px] sm:max-w-[325px] mx-auto my-1 flex items-center justify-center">
      <svg
        className="w-full h-full"
        viewBox="0 0 340 340"
        style={{ filter: 'drop-shadow(0 6px 16px rgba(0,255,128,.3))' }}
        aria-label="SDD PVT Quantum Radar"
      >
        <defs>
          <radialGradient id="rg1" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#0E2217" />
            <stop offset="65%" stopColor="#0C1C13" />
            <stop offset="100%" stopColor="#040A07" />
          </radialGradient>
          <linearGradient id="rg2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00FF80" stopOpacity="0.65" />
            <stop offset="40%" stopColor="#9333EA" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#008040" stopOpacity="0" />
          </linearGradient>
          <radialGradient id="rg3" cx="45%" cy="40%" r="55%">
            <stop offset="0%" stopColor="#0A2C1A" />
            <stop offset="60%" stopColor="#14091C" />
            <stop offset="100%" stopColor="#060D09" />
          </radialGradient>
          <linearGradient id="rg4" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00FF80" />
            <stop offset="50%" stopColor="#9333EA" />
            <stop offset="100%" stopColor="#00FF80" />
          </linearGradient>
          <radialGradient id="ballG" cx="32%" cy="28%" r="65%">
            <stop offset="0%" stopColor="#A7F3D0" />
            <stop offset="35%" stopColor="#00FF80" />
            <stop offset="75%" stopColor="#008040" />
            <stop offset="100%" stopColor="#00331A" />
          </radialGradient>
          <radialGradient id="ballP" cx="32%" cy="28%" r="65%">
            <stop offset="0%" stopColor="#F5D0FE" />
            <stop offset="35%" stopColor="#C084FC" />
            <stop offset="75%" stopColor="#7E22CE" />
            <stop offset="100%" stopColor="#3B0764" />
          </radialGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        <circle cx="170" cy="170" r="165" fill="url(#rg1)" stroke="#00FF80" strokeWidth="1.8" />
        <circle
          cx="170"
          cy="170"
          r="158"
          fill="#0A140F"
          stroke="#00FF80"
          strokeWidth="1.2"
          strokeOpacity="0.8"
        />
        <circle
          cx="170"
          cy="170"
          r="148"
          fill="none"
          stroke="#00CC66"
          strokeWidth="1"
          strokeDasharray="3 3"
        />
        <circle
          cx="170"
          cy="170"
          r="120"
          fill="none"
          stroke="#9333EA"
          strokeWidth="0.8"
          strokeDasharray="2 4"
        />
        <circle
          cx="170"
          cy="170"
          r="85"
          fill="none"
          stroke="#00CC66"
          strokeWidth="0.8"
          strokeDasharray="3 3"
        />
        <circle
          cx="170"
          cy="170"
          r="135"
          fill="none"
          stroke="#00FF80"
          strokeWidth="1.4"
          strokeDasharray="5 5"
          strokeOpacity="0.85"
        />

        <g className="animate-radar-sweep-rev">
          <circle
            cx="170"
            cy="170"
            r="153"
            fill="none"
            stroke="#9333EA"
            strokeWidth="1.5"
            strokeDasharray="16 20"
            strokeOpacity="0.85"
            filter="url(#glow)"
          />
        </g>

        <g className="animate-radar-sweep">
          <path d="M 170 170 L 320 170 A 150 150 0 0 0 256 47 Z" fill="url(#rg2)" />
          <line
            x1="170"
            y1="170"
            x2="320"
            y2="170"
            stroke="#00FF80"
            strokeWidth="2.2"
            strokeLinecap="round"
            filter="url(#glow)"
          />
          <circle cx="316" cy="170" r="3" fill="#00FF80" />
        </g>

        {DEGREE_TICKS.map((a) => {
          const rad = (a * Math.PI) / 180;
          const x1 = 170 + 158 * Math.cos(rad);
          const y1 = 170 + 158 * Math.sin(rad);
          const innerR = a % 90 === 0 ? 144 : 151;
          const x2 = 170 + innerR * Math.cos(rad);
          const y2 = 170 + innerR * Math.sin(rad);
          return (
            <line
              key={a}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={a % 90 === 0 ? '#00FF80' : '#9333EA'}
              strokeWidth={a % 90 === 0 ? 2 : 1}
              strokeOpacity={a % 90 === 0 ? 0.9 : 0.6}
            />
          );
        })}

        <text
          x="170"
          y="18"
          textAnchor="middle"
          fill="#00FF80"
          fontSize="9"
          fontFamily="monospace"
          fontWeight="900"
        >
          000° N
        </text>
        <text
          x="326"
          y="173"
          textAnchor="end"
          fill="#9333EA"
          fontSize="8.5"
          fontFamily="monospace"
          fontWeight="800"
        >
          090° E
        </text>
        <text
          x="170"
          y="328"
          textAnchor="middle"
          fill="#9333EA"
          fontSize="8.5"
          fontFamily="monospace"
          fontWeight="800"
        >
          180° S
        </text>
        <text
          x="14"
          y="173"
          textAnchor="start"
          fill="#9333EA"
          fontSize="8.5"
          fontFamily="monospace"
          fontWeight="800"
        >
          270° W
        </text>

        <g className="animate-radar-orbit">
          <circle
            cx={cx1}
            cy={cy1}
            r="22"
            fill="none"
            stroke={tCls === 'g' ? '#00FF80' : '#9333EA'}
            strokeWidth="1.5"
            strokeDasharray="4 3"
            opacity="0.9"
          />
          <circle
            cx={cx1}
            cy={cy1}
            r="16"
            fill={`url(#${g1})`}
            stroke="#00FF80"
            strokeWidth="1.5"
          />
          <circle cx={cx1 - 5} cy={cy1 - 5} r="4.5" fill="#FFFFFF" opacity="0.85" />
          <g className="animate-radar-orbit-rev" style={{ transformOrigin: `${cx1}px ${cy1}px` }}>
            <text
              x={cx1}
              y={cy1 + 5}
              textAnchor="middle"
              fill="#FFFFFF"
              fontSize="13"
              fontWeight="900"
              fontFamily="Orbitron,sans-serif"
            >
              {pred.ball}
            </text>
            <rect
              x={cx1 - 25}
              y={cy1 - 30}
              width="50"
              height="13"
              rx="3"
              fill="#0E2217"
              stroke="#00FF80"
              strokeWidth="1"
            />
            <text
              x={cx1}
              y={cy1 - 21}
              textAnchor="middle"
              fill="#00FF80"
              fontSize="7.5"
              fontWeight="900"
              fontFamily="monospace"
            >
              TARGET #{pred.ball}
            </text>
          </g>
        </g>

        <g className="animate-radar-orbit">
          <circle
            cx={cx2}
            cy={cy2}
            r="22"
            fill="none"
            stroke={oCls === 'g' ? '#00FF80' : '#9333EA'}
            strokeWidth="1.5"
            strokeDasharray="4 3"
            opacity="0.9"
          />
          <circle
            cx={cx2}
            cy={cy2}
            r="16"
            fill={`url(#${g2})`}
            stroke="#9333EA"
            strokeWidth="1.5"
          />
          <circle cx={cx2 - 5} cy={cy2 - 5} r="4.5" fill="#FFFFFF" opacity="0.85" />
          <g className="animate-radar-orbit-rev" style={{ transformOrigin: `${cx2}px ${cy2}px` }}>
            <text
              x={cx2}
              y={cy2 + 5}
              textAnchor="middle"
              fill="#FFFFFF"
              fontSize="13"
              fontWeight="900"
              fontFamily="Orbitron,sans-serif"
            >
              {pred.opposite}
            </text>
            <rect
              x={cx2 - 24}
              y={cy2 + 18}
              width="48"
              height="13"
              rx="3"
              fill="#0E2217"
              stroke="#9333EA"
              strokeWidth="1"
            />
            <text
              x={cx2}
              y={cy2 + 27.5}
              textAnchor="middle"
              fill="#9333EA"
              fontSize="7.5"
              fontWeight="900"
              fontFamily="monospace"
            >
              OPP #{pred.opposite}
            </text>
          </g>
        </g>

        <circle cx="170" cy="170" r="104" fill="url(#rg3)" stroke="url(#rg4)" strokeWidth="2.5" />
        <circle
          cx="170"
          cy="170"
          r="97"
          fill="none"
          stroke="#00FF80"
          strokeWidth="1.5"
          strokeDasharray="4 3"
        />
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center p-4 z-10">
        <div className="text-[7.5px] sm:text-[8px] text-[#A7F3D0] tracking-[1.6px] mb-0.5 font-bold">
          PREDICTED DIRECTION
        </div>
        <div
          className={`font-orbitron text-[32px] sm:text-[40px] font-black tracking-[3px] leading-none ${
            isBig ? 'text-[#00FF80] pred-shadow-big' : 'text-[#C084FC] pred-shadow-small'
          }`}
        >
          {pred.size}
        </div>
        <div className="text-[10px] sm:text-[11px] text-[#E2FEE8] mt-1 tracking-[1px] font-bold">
          {pred.color}
        </div>

        <div className="flex gap-3 justify-center mt-1.5 sm:mt-2">
          <div className="flex flex-col items-center">
            <div
              className={`relative w-9 h-9 sm:w-[42px] sm:h-[42px] rounded-full flex items-center justify-center font-black text-base sm:text-lg border-2 border-[#00FF80] shadow-[0_4px_14px_rgba(0,0,0,0.6)] font-orbitron ${
                tCls === 'g' ? 'text-[#060D09]' : 'text-white'
              }`}
              style={{
                background:
                  tCls === 'g'
                    ? 'radial-gradient(circle at 30% 30%,#A7F3D0 0%,#00FF80 45%,#008040 80%,#00331A 100%)'
                    : 'radial-gradient(circle at 30% 30%,#F5D0FE 0%,#C084FC 40%,#7E22CE 70%,#3B0764 100%)',
              }}
            >
              <span
                className="absolute top-1 left-1.5 w-2.5 h-1.5 bg-white/70 rounded-full blur-[1px] -rotate-30"
                aria-hidden="true"
              />
              {pred.ball}
            </div>
            <div className="text-[7px] sm:text-[7.5px] text-[#A7F3D0] tracking-[1px] mt-0.5 font-bold">
              TARGET
            </div>
          </div>

          <div className="flex flex-col items-center">
            <div
              className={`relative w-9 h-9 sm:w-[42px] sm:h-[42px] rounded-full flex items-center justify-center font-black text-base sm:text-lg border-2 border-[#00FF80] shadow-[0_4px_14px_rgba(0,0,0,0.6)] font-orbitron ${
                oCls === 'g' ? 'text-[#060D09]' : 'text-white'
              }`}
              style={{
                background:
                  oCls === 'g'
                    ? 'radial-gradient(circle at 30% 30%,#A7F3D0 0%,#00FF80 45%,#008040 80%,#00331A 100%)'
                    : 'radial-gradient(circle at 30% 30%,#F5D0FE 0%,#C084FC 40%,#7E22CE 70%,#3B0764 100%)',
              }}
            >
              <span
                className="absolute top-1 left-1.5 w-2.5 h-1.5 bg-white/70 rounded-full blur-[1px] -rotate-30"
                aria-hidden="true"
              />
              {pred.opposite}
            </div>
            <div className="text-[7px] sm:text-[7.5px] text-[#A7F3D0] tracking-[1px] mt-0.5 font-bold">
              OPPOSITE
            </div>
          </div>
        </div>

        <div className="text-[8.5px] sm:text-[9px] text-[#A7F3D0] mt-1 font-bold font-mono-jb">
          SAFE: <span className="text-[#00FF80]">{pred.safe.join(', ')}</span>
        </div>
      </div>
    </div>
  );
}

import { storage } from '../utils/storage';

interface AccountTabProps {
  soundEnabled: boolean;
  mockMode: boolean;
  onToggleSound: () => void;
  onToggleMockMode: () => void;
  onRequestLogout: () => void;
}

export function AccountTab({
  soundEnabled,
  mockMode,
  onToggleSound,
  onToggleMockMode,
  onRequestLogout,
}: AccountTabProps) {
  const deviceId = storage.getDeviceId();

  return (
    <div className="animate-fade-in grid grid-cols-1 lg:grid-cols-2 gap-3 items-start">
      <div
        className="rounded-[20px] p-3.5 border border-[#00FF80] shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{ background: 'linear-gradient(135deg,#1B0926,#0A1C13)' }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase font-black">
          🛡️ SDD PVT ACCESS PASS
        </h2>

        <div
          className="p-3 rounded-[14px] text-[#E2FEE8] mt-2 border border-[#00FF80]"
          style={{ background: 'linear-gradient(135deg,#0E2217,#1B0926)' }}
        >
          <div className="text-[9px] text-[#00FF80] tracking-[1.5px] font-bold mb-1">
            ACCOUNT STATUS
          </div>
          <div className="text-[15px] font-mono-jb font-bold text-[#00FF80] tracking-[2px]">
            SDD PVT PREMIUM
          </div>
          <div className="mt-2.5 pt-2.5 border-t border-[#00FF80]/30 text-[10px] font-mono-jb text-[#A7F3D0] space-y-1">
            <div className="truncate">
              DEVICE ID: <b className="text-[#00FF80]">{deviceId}</b>
            </div>
            <div>
              SERVER: <b className="text-[#E2FEE8]">SDD PVT QUANTUM CORE</b>
            </div>
            <div>
              ENGINES: <b className="text-[#00FF80]">TITAN 200 + 1000-RULE + DRAGON</b>
            </div>
            <div>
              VALIDITY: <b className="text-[#00FF80]">LIFETIME ♾️</b>
            </div>
          </div>
        </div>
      </div>

      <div
        className="rounded-[20px] p-3.5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
        style={{
          background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
        }}
      >
        <h2 className="font-orbitron text-xs text-[#00FF80] mb-2.5 tracking-[1.5px] uppercase font-black">
          ⚙️ SYSTEM SETTINGS
        </h2>

        <div className="flex justify-between items-center py-2.5 border-b border-[#00FF80]/30 gap-3">
          <div>
            <b className="text-[11px] text-[#00FF80] block">SOUND EFFECTS</b>
            <div className="text-[9px] text-[#A7F3D0]">Audio cues &amp; countdown ticks</div>
          </div>
          <button
            type="button"
            onClick={onToggleSound}
            className={`min-h-[42px] min-w-[64px] px-4 py-1.5 rounded-lg font-orbitron font-black text-[10px] tracking-[1px] uppercase cursor-pointer active:scale-[0.97] transition-transform ${
              soundEnabled ? 'text-[#060D09]' : 'text-white'
            }`}
            style={{
              background: soundEnabled
                ? 'linear-gradient(135deg,#00FF80,#008040)'
                : 'linear-gradient(135deg,#9333EA,#581C87)',
            }}
          >
            {soundEnabled ? 'ON' : 'OFF'}
          </button>
        </div>

        <div className="flex justify-between items-center py-2.5 gap-3">
          <div>
            <b className="text-[11px] text-[#00FF80] block">MOCK DATA FEED</b>
            <div className="text-[9px] text-[#A7F3D0]">Use simulated stream</div>
          </div>
          <button
            type="button"
            onClick={onToggleMockMode}
            className={`min-h-[42px] min-w-[64px] px-4 py-1.5 rounded-lg font-orbitron font-black text-[10px] tracking-[1px] uppercase cursor-pointer active:scale-[0.97] transition-transform ${
              mockMode ? 'text-[#060D09]' : 'text-white'
            }`}
            style={{
              background: mockMode
                ? 'linear-gradient(135deg,#00FF80,#008040)'
                : 'linear-gradient(135deg,#9333EA,#581C87)',
            }}
          >
            {mockMode ? 'ON' : 'OFF'}
          </button>
        </div>

        <button
          type="button"
          onClick={onRequestLogout}
          className="w-full min-h-[46px] py-3 mt-3 rounded-xl font-orbitron font-black text-[11px] tracking-[1.5px] uppercase text-white shadow-[0_4px_14px_rgba(147,51,234,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
          style={{ background: 'linear-gradient(135deg,#9333EA,#581C87)' }}
        >
          🚪 LOGOUT
        </button>
      </div>
    </div>
  );
}

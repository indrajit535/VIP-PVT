import type { DrawRecord, PredictionResult } from '../types/wingo';
import { QuantumRadar } from './QuantumRadar';

interface RoundsTabProps {
  currentPeriod: string;
  secondsLeft: number;
  prediction: PredictionResult | null;
  history: DrawRecord[];
  onCopyPrediction: () => void;
  onForceSync: () => void;
  onTestPopup: (type: 'WIN' | 'LOSS' | 'JACKPOT') => void;
}

export function RoundsTab({
  currentPeriod,
  secondsLeft,
  prediction,
  history,
  onCopyPrediction,
  onForceSync,
  onTestPopup,
}: RoundsTabProps) {
  const shortPeriod =
    currentPeriod && currentPeriod.length > 6
      ? '#' + currentPeriod.slice(-6)
      : '#' + currentPeriod;
  const isWarn = secondsLeft <= 5;
  const patterns = prediction?.combined.patterns || [];
  const tel = prediction?.combined.telemetry;
  const chips = history.slice(0, 30);

  return (
    <div className="animate-fade-in grid grid-cols-1 lg:grid-cols-12 gap-3 items-start">
      <div className="lg:col-span-7 flex flex-col gap-3">
        <div
          className="rounded-[20px] p-3 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
          style={{
            background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
          }}
        >
          <div
            className="flex justify-between items-center gap-2 px-3 py-2.5 border-2 border-[#00FF80] rounded-2xl shadow-[0_0_14px_rgba(0,255,128,0.2)]"
            style={{ background: 'linear-gradient(135deg,#0E2217,#14091C)' }}
          >
            <div className="min-w-0 flex-1">
              <div className="text-[9px] text-[#A7F3D0] tracking-[1.2px] font-bold">
                PREDICTED PERIOD
              </div>
              <div
                className="text-base sm:text-lg font-black text-[#00FF80] tracking-[1px] mt-0.5 font-orbitron tabular-nums"
                style={{ textShadow: '0 0 8px rgba(0,255,128,.4)' }}
              >
                {shortPeriod}
              </div>
              <div className="text-[9px] text-[#6EE7B7] mt-0.5 font-mono-jb truncate">
                {currentPeriod}
              </div>
            </div>

            <div
              className={`px-2.5 sm:px-3 py-2 rounded-xl min-w-[76px] sm:min-w-[88px] text-right border transition-colors shrink-0 ${
                isWarn ? 'border-[#9333EA] animate-pulse-warn' : 'border-[#00FF80]'
              }`}
              style={{
                background: isWarn
                  ? 'linear-gradient(135deg,#3B0764,#500724)'
                  : 'linear-gradient(135deg,#09150E,#200529)',
                boxShadow: '0 0 10px rgba(0,255,128,.25)',
              }}
            >
              <div
                className={`text-xl sm:text-[22px] font-black tracking-[1px] font-orbitron tabular-nums ${
                  isWarn ? 'text-[#F0ABFC]' : 'text-[#00FF80]'
                }`}
                style={{ textShadow: '0 0 10px rgba(0,255,128,.5)' }}
              >
                {String(secondsLeft).padStart(2, '0')}
              </div>
              <div className="text-[8px] text-[#A7F3D0] tracking-[1px] mt-0.5 font-semibold">
                SECONDS
              </div>
            </div>
          </div>
        </div>

        <div
          className="rounded-[20px] p-3 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
          style={{
            background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
          }}
        >
          <QuantumRadar prediction={prediction} />

          <div className="grid grid-cols-3 gap-1.5 mt-2">
            <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
              <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
                CONFIDENCE
              </div>
              <div className="text-xs sm:text-[13px] font-bold text-[#00FF80] mt-0.5 font-mono-jb">
                {prediction ? `${prediction.confidence}%` : '--'}
              </div>
            </div>
            <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
              <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
                LEVEL
              </div>
              <div className="text-xs sm:text-[13px] font-bold text-[#00FF80] mt-0.5 font-mono-jb">
                {prediction ? `L${prediction.level} ${prediction.mult}` : '--'}
              </div>
            </div>
            <div className="bg-[#0A1810]/90 border border-[#00FF80]/30 rounded-[10px] p-2 text-center">
              <div className="text-[8px] text-[#A7F3D0] uppercase tracking-[0.7px] font-bold">
                VOTES B/S
              </div>
              <div className="text-xs sm:text-[13px] font-bold text-[#C084FC] mt-0.5 font-mono-jb">
                {prediction
                  ? `${prediction.combined.votesBig}/${prediction.combined.votesSmall}`
                  : '--'}
              </div>
            </div>
          </div>

          {tel && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 mt-1.5 font-mono-jb text-[9px]">
              <div className="bg-[#040A07] border border-[#00FF80]/25 rounded-lg px-2 py-1.5 truncate">
                <span className="text-[#A7F3D0]/70">200-PAT: </span>
                <span className="text-[#00FF80] font-bold">{tel.titan200Triggered} ACTIVE</span>
              </div>
              <div className="bg-[#040A07] border border-[#00FF80]/25 rounded-lg px-2 py-1.5 truncate">
                <span className="text-[#A7F3D0]/70">1000-RULE: </span>
                <span className="text-[#00FF80] font-bold">{tel.rules1000Triggered}/1000</span>
              </div>
              <div className="bg-[#040A07] border border-[#00FF80]/25 rounded-lg px-2 py-1.5 truncate">
                <span className="text-[#A7F3D0]/70">SAMAD: </span>
                <span className="text-[#C084FC] font-bold">
                  {tel.samadHash !== null ? `#${tel.samadHash} ${tel.samadSize}` : '--'}
                </span>
              </div>
              <div className="bg-[#040A07] border border-[#00FF80]/25 rounded-lg px-2 py-1.5 truncate">
                <span className="text-[#A7F3D0]/70">FORMULA: </span>
                <span className="text-[#00FF80] font-bold">{tel.formulaScore}/10</span>
              </div>
              <div className="bg-[#040A07] border border-[#00FF80]/25 rounded-lg px-2 py-1.5 truncate">
                <span className="text-[#A7F3D0]/70">REGIME: </span>
                <span className="text-[#E2FEE8] font-bold">
                  {tel.regimeIcon} {tel.regimeName}
                </span>
              </div>
              <div className="bg-[#040A07] border border-[#00FF80]/25 rounded-lg px-2 py-1.5 truncate">
                <span className="text-[#A7F3D0]/70">TRI-COLOR: </span>
                <span className="text-[#00FF80] font-bold">{tel.triColor}</span>
              </div>
            </div>
          )}

          <div className="mt-2 px-2.5 py-2 rounded-[9px] text-[10px] font-bold flex items-center gap-1.5 tracking-[0.4px] font-mono-jb bg-[#00FF80]/12 border border-[#00FF80] text-[#A7F3D0] break-words">
            {prediction
              ? `⚡ ${prediction.algo} · Conf: ${prediction.confidence}%`
              : '⚛️ Initializing SDD PVT Combined Engine...'}
          </div>

          <button
            type="button"
            onClick={onCopyPrediction}
            className="w-full min-h-[46px] py-3 px-4 mt-2 rounded-xl font-orbitron font-black text-[11px] tracking-[1.4px] uppercase text-[#060D09] shadow-[0_4px_14px_rgba(0,255,128,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
            style={{ background: 'linear-gradient(135deg,#00FF80,#9333EA)' }}
          >
            📋 COPY VIP PREDICTION
          </button>

          <button
            type="button"
            onClick={onForceSync}
            className="w-full min-h-[44px] py-3 px-4 mt-2 rounded-xl font-orbitron font-black text-[11px] tracking-[1.4px] uppercase text-white shadow-[0_4px_14px_rgba(147,51,234,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
            style={{ background: 'linear-gradient(135deg,#9333EA,#581C87)' }}
          >
            🔄 FORCE SYNC NOW
          </button>

          <div className="mt-3 pt-2.5 border-t border-[#00FF80]/30">
            <div className="text-[9px] text-[#A7F3D0] font-bold tracking-[1px] mb-1.5 text-center font-mono-jb">
              🧪 MANUAL TEST POPUPS
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => onTestPopup('WIN')}
                className="min-h-[42px] py-2 px-1 rounded-xl font-orbitron font-black text-[9px] tracking-[1px] uppercase text-[#060D09] shadow-[0_4px_14px_rgba(0,255,128,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
                style={{ background: 'linear-gradient(135deg,#00FF80,#008040)' }}
              >
                TEST WIN
              </button>
              <button
                type="button"
                onClick={() => onTestPopup('LOSS')}
                className="min-h-[42px] py-2 px-1 rounded-xl font-orbitron font-black text-[9px] tracking-[1px] uppercase text-white shadow-[0_4px_14px_rgba(147,51,234,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
                style={{ background: 'linear-gradient(135deg,#9333EA,#581C87)' }}
              >
                TEST LOSS
              </button>
              <button
                type="button"
                onClick={() => onTestPopup('JACKPOT')}
                className="min-h-[42px] py-2 px-1 rounded-xl font-orbitron font-black text-[9px] tracking-[1px] uppercase text-[#060D09] shadow-[0_4px_14px_rgba(0,255,128,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
                style={{ background: 'linear-gradient(135deg,#00FF80,#9333EA)' }}
              >
                JACKPOT
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-5 flex flex-col gap-3">
        <div
          className="rounded-[20px] p-3.5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
          style={{
            background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
          }}
        >
          <h2 className="font-orbitron text-[11px] sm:text-xs text-[#00FF80] mb-2.5 tracking-[1.2px] uppercase flex items-center justify-between font-black gap-2">
            <span className="truncate">🐉 COMBINED ENGINE SIGNALS</span>
            <span className="text-[10px] text-[#A7F3D0] font-mono-jb shrink-0">
              {patterns.length} active
            </span>
          </h2>

          <div className="max-h-[280px] lg:max-h-[360px] overflow-y-auto pr-1 custom-scrollbar">
            {patterns.length === 0 ? (
              <div className="text-[#A7F3D0] italic text-[11px] text-center py-4 font-mono-jb">
                Scanning 1000-Rule + Titan 200 Matrix...
              </div>
            ) : (
              patterns.map((p) => {
                const borderStyle =
                  p.cat === 'DRAGON' || p.cat === 'FORMULA'
                    ? 'border-[#00FF80]/60 shadow-[0_0_10px_rgba(0,255,128,0.2)]'
                    : p.cat === 'STREAK3' || p.cat === 'RULE1000'
                    ? 'border-[#9333EA]/60'
                    : 'border-[#00FF80]/30';
                return (
                  <div
                    key={p.id}
                    className={`p-2.5 rounded-[10px] mb-1.5 text-[11px] bg-[#0C1C13] border ${borderStyle}`}
                    style={
                      p.cat === 'STREAK3' || p.cat === 'RULE1000'
                        ? { background: 'linear-gradient(135deg,#0C1C13,#1B0926)' }
                        : p.cat === 'DRAGON' || p.cat === 'FORMULA'
                        ? { background: 'linear-gradient(135deg,#0C1C13,#0E2217)' }
                        : undefined
                    }
                  >
                    <div className="font-bold text-[#00FF80] text-[11px]">{p.name}</div>
                    <div className="text-[#A7F3D0] text-[10px] mt-0.5 font-mono-jb">
                      {p.desc}
                    </div>
                    <div className="flex items-center gap-2 mt-1.5 flex-wrap text-[9px] font-mono-jb font-bold">
                      <span className={p.dir === 'BIG' ? 'text-[#00FF80]' : 'text-[#F5D0FE]'}>
                        {p.dir}
                      </span>
                      <span className="text-[#A7F3D0]/50" aria-hidden="true">
                        ·
                      </span>
                      <span className="text-[#A7F3D0]">W:{p.w}</span>
                      <span className="text-[#A7F3D0]/50" aria-hidden="true">
                        ·
                      </span>
                      <span className="text-[#A7F3D0]">C:{p.conf}%</span>
                      <span className="text-[#A7F3D0]/50" aria-hidden="true">
                        ·
                      </span>
                      <span className="text-[#A7F3D0]">{p.cat}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div
          className="rounded-[20px] p-3.5 border border-[#00FF80]/35 shadow-[0_4px_20px_rgba(0,0,0,0.6),inset_0_0_15px_rgba(0,255,128,0.05)]"
          style={{
            background: 'linear-gradient(135deg,#0C1C13 0%,#150B22 50%,#09150E 100%)',
          }}
        >
          <h2 className="font-orbitron text-[11px] sm:text-xs text-[#00FF80] mb-2.5 tracking-[1.2px] uppercase flex items-center justify-between font-black">
            <span>📊 LAST 30 DRAWS</span>
          </h2>

          {chips.length === 0 ? (
            <div className="text-[#A7F3D0] italic text-[11px] text-center py-4 font-mono-jb">
              Waiting for draw data...
            </div>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {chips.map((d, idx) => {
                const n = parseInt(String(d.number), 10);
                const isBig = n >= 5;
                const isV = n === 0 || n === 5;
                const bg = isV
                  ? isBig
                    ? 'linear-gradient(135deg,#00FF80,#9333EA)'
                    : 'linear-gradient(135deg,#9333EA,#00FF80)'
                  : isBig
                  ? 'linear-gradient(135deg,#00FF80,#00CC66)'
                  : 'linear-gradient(135deg,#9333EA,#581C87)';
                const txt = isBig || isV ? 'text-[#060D09]' : 'text-white';
                return (
                  <div
                    key={`${d.issueNumber}-${idx}`}
                    title={`#${d.issueNumber} -> ${n}`}
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-black font-orbitron shadow-[0_2px_6px_rgba(0,0,0,0.5)] border border-white/30 ${txt}`}
                    style={{ background: bg }}
                  >
                    {n}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

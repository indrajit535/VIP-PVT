import { useEffect } from 'react';
import type { HistoryEntry } from '../types/wingo';

interface ResultPopupProps {
  entry: HistoryEntry | null;
  onClose: () => void;
}

export function ResultPopup({ entry, onClose }: ResultPopupProps) {
  useEffect(() => {
    if (!entry) return;
    const timer = setTimeout(onClose, 10000);
    return () => clearTimeout(timer);
  }, [entry, onClose]);

  if (!entry) return null;

  const isJackpot = entry.isJackpot;
  const isWin = entry.isWin;
  const title = isJackpot ? '💎 JACKPOT!' : isWin ? '🏆 WIN!' : '⚡ LOSS';

  const borderColor = isJackpot ? '#00FF80' : isWin ? '#00FF80' : '#9333EA';
  const titleColor = isJackpot ? '#00FF80' : isWin ? '#00FF80' : '#9333EA';
  const ballBg =
    entry.actualNumber >= 5
      ? 'linear-gradient(135deg,#00FF80,#00CC66)'
      : 'linear-gradient(135deg,#9333EA,#581C87)';

  return (
    <div
      className="fixed inset-0 z-[9999] bg-[#060D09]/92 backdrop-blur-[10px] flex items-center justify-center p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="Prediction Result"
    >
      <div
        className="w-full max-w-[400px] rounded-[24px] px-5 py-6 text-center text-[#E2FEE8] border-2 animate-pop-in"
        style={{
          background: 'linear-gradient(135deg,#0C1C13,#1B0926)',
          borderColor,
          boxShadow: isJackpot
            ? '0 0 60px rgba(0,255,128,.6)'
            : '0 0 50px rgba(0,255,128,.4)',
        }}
      >
        <div
          className="font-orbitron text-[24px] font-black tracking-[2px] mb-1.5"
          style={{
            color: titleColor,
            textShadow: isWin
              ? '0 0 14px rgba(0,255,128,.6)'
              : '0 0 14px rgba(147,51,234,.6)',
          }}
        >
          {title}
        </div>
        <div className="text-[10px] text-[#A7F3D0] mb-3 font-mono-jb">
          ISSUE #{String(entry.period).slice(-6)}
        </div>
        <div
          className="font-orbitron w-[76px] h-[76px] rounded-full inline-flex items-center justify-center text-[34px] font-black text-[#060D09] my-2.5 shadow-[0_8px_28px_rgba(0,0,0,0.6)] border-[3px] border-[#00FF80]"
          style={{ background: ballBg }}
        >
          {entry.actualNumber}
        </div>
        <div className="text-[11px] text-[#A7F3D0] mt-2.5 font-mono-jb">
          Predicted:{' '}
          <b className="text-[#00FF80]">
            {entry.predicted} #{entry.predictedBall}
          </b>
        </div>
        <div className="text-[11px] text-[#E2FEE8] mt-1 font-mono-jb">
          Actual:{' '}
          <b>
            {entry.actualSize} ({entry.actualNumber})
          </b>
        </div>
        <div
          className="text-[20px] font-black mt-3 font-mono-jb"
          style={{ color: entry.profit >= 0 ? '#00FF80' : '#9333EA' }}
        >
          {entry.profit >= 0 ? '+' : ''}
          {entry.profit.toFixed(2)}u
        </div>
        <button
          type="button"
          onClick={onClose}
          className="w-full min-h-[44px] py-3 mt-3.5 rounded-xl font-orbitron font-black text-[11px] tracking-[1.5px] uppercase text-[#060D09] shadow-[0_4px_14px_rgba(0,255,128,0.4)] cursor-pointer active:scale-[0.97] transition-transform"
          style={{ background: 'linear-gradient(135deg,#00FF80,#9333EA)' }}
        >
          CONTINUE
        </button>
      </div>
    </div>
  );
}

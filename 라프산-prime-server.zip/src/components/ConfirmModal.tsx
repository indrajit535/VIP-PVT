interface ConfirmModalProps {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmModal({
  open,
  title,
  message,
  confirmLabel = 'CONFIRM',
  onConfirm,
  onCancel,
}: ConfirmModalProps) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[9999] bg-[#060D09]/90 backdrop-blur-md flex items-center justify-center p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onCancel();
      }}
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div
        className="w-full max-w-[360px] rounded-[22px] p-5 border-2 border-[#00FF80] text-[#E2FEE8] text-center animate-pop-in shadow-[0_0_40px_rgba(0,255,128,0.35)]"
        style={{ background: 'linear-gradient(135deg,#0C1C13,#1B0926)' }}
      >
        <div className="font-orbitron text-sm font-black tracking-[1.5px] text-[#00FF80] mb-2">
          {title}
        </div>
        <div className="text-xs text-[#A7F3D0] font-mono-jb mb-4">{message}</div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 min-h-[42px] py-2.5 rounded-xl font-orbitron font-bold text-[10px] tracking-[1.2px] uppercase border border-[#00FF80]/40 text-[#A7F3D0] bg-[#09150E] cursor-pointer active:scale-[0.97] transition-transform"
          >
            CANCEL
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="flex-1 min-h-[42px] py-2.5 rounded-xl font-orbitron font-black text-[10px] tracking-[1.2px] uppercase text-white cursor-pointer active:scale-[0.97] transition-transform"
            style={{ background: 'linear-gradient(135deg,#9333EA,#581C87)' }}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

import type { DirectionSize } from '../types/wingo';

const SAFE_POOLS = {
  BIG: [5, 6, 7, 8, 9],
  SMALL: [0, 1, 2, 3, 4],
};

const SEED_NUMS = [
  3, 8, 2, 7, 4, 9, 1, 6, 0, 5, 8, 3, 9, 2, 7, 1, 6, 4, 0, 5,
  7, 2, 8, 3, 9, 4, 1, 6, 5, 0, 9, 1, 8, 2, 7, 3, 6, 4, 5, 0,
  8, 9, 7, 6, 5, 4, 3, 2, 1, 0, 1, 3, 5, 7, 9, 2, 4, 6, 8, 0,
  9, 8, 6, 7, 5, 4, 2, 3, 1, 0, 7, 8, 9, 5, 6, 3, 4, 1, 2, 0,
];

interface Normalized200 {
  num: number;
  size: 'Big' | 'Small';
  pureColor: 'Red' | 'Green';
  isViolet: boolean;
  parity: 'Even' | 'Odd';
}

type Pattern200Fn = (h: Normalized200[]) => { vote: 'Big' | 'Small'; weight: number } | null;

export interface Titan200Result {
  prediction: 'Big' | 'Small';
  confidence: number;
  bigScore: number;
  smallScore: number;
  totalPatternsTriggered: number;
  topSignals: { pattern: string; vote: 'Big' | 'Small'; weight: number }[];
  currentStreak: { type: 'Big' | 'Small'; count: number };
}

class WingoBigSmallMaster200 {
  private patterns: Record<string, Pattern200Fn>;

  constructor() {
    this.patterns = this._loadAll200Patterns();
  }

  private _normalize(nums: number[]): Normalized200[] {
    return nums.map((num) => ({
      num,
      size: num >= 5 ? 'Big' : 'Small',
      pureColor: num % 2 === 0 ? 'Red' : 'Green',
      isViolet: num === 0 || num === 5,
      parity: num % 2 === 0 ? 'Even' : 'Odd',
    }));
  }

  private _opp(size: 'Big' | 'Small'): 'Big' | 'Small' {
    return size === 'Big' ? 'Small' : 'Big';
  }

  private _streak(h: Normalized200[], prop: 'size' | 'pureColor' | 'parity'): number {
    if (!h || h.length === 0) return 0;
    let count = 1;
    for (let i = 1; i < h.length; i++) {
      if (h[i] && h[i][prop] === h[0][prop]) count++;
      else break;
    }
    return count;
  }

  private _jumping(h: Normalized200[], prop: 'size' | 'pureColor' | 'parity', minLen: number): boolean {
    if (h.length < minLen) return false;
    for (let i = 0; i < minLen - 1; i++) {
      if (!h[i] || !h[i + 1] || h[i][prop] === h[i + 1][prop]) return false;
    }
    return true;
  }

  private _mirror(h: Normalized200[], prop: 'size' | 'pureColor' | 'parity', len: number): boolean {
    if (h.length < len * 2) return false;
    for (let i = 0; i < len; i++) {
      if (!h[i] || !h[len * 2 - 1 - i] || h[i][prop] !== h[len * 2 - 1 - i][prop]) return false;
    }
    return true;
  }

  private _matchSeq(h: Normalized200[], prop: 'size' | 'pureColor' | 'parity', seq: string[]): boolean {
    if (h.length < seq.length) return false;
    for (let i = 0; i < seq.length; i++) {
      if (!h[i] || h[i][prop] !== seq[i]) return false;
    }
    return true;
  }

  private _loadAll200Patterns(): Record<string, Pattern200Fn> {
    const p: Record<string, Pattern200Fn> = {};

    p['1. Dragon'] = (h) => (this._streak(h, 'size') >= 4 ? { vote: h[0].size, weight: 3.5 } : null);
    p['2. Mirror'] = (h) => (this._mirror(h, 'size', 3) ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['3. Jumping'] = (h) => (this._jumping(h, 'size', 3) ? { vote: this._opp(h[0].size), weight: 3.8 } : null);
    p['4. Staircase'] = (h) =>
      h[2] && h[0].num > h[1].num && h[1].num > h[2].num
        ? { vote: 'Big', weight: 2.8 }
        : h[2] && h[0].num < h[1].num && h[1].num < h[2].num
        ? { vote: 'Small', weight: 2.8 }
        : null;
    p['5. Zigzag'] = (h) => (this._jumping(h, 'size', 4) ? { vote: this._opp(h[0].size), weight: 4.0 } : null);
    p['6. Double Dragon'] = (h) =>
      this._streak(h, 'size') >= 4 && this._streak(h, 'pureColor') >= 4 ? { vote: h[0].size, weight: 4.5 } : null;
    p['7. Triple Dragon'] = (h) =>
      this._streak(h, 'size') >= 3 && this._streak(h, 'pureColor') >= 3 && this._streak(h, 'parity') >= 3
        ? { vote: h[0].size, weight: 4.8 }
        : null;
    p['8. Mega Dragon'] = (h) => (this._streak(h, 'size') >= 7 ? { vote: this._opp(h[0].size), weight: 4.5 } : null);
    p['9. Super Dragon'] = (h) => (this._streak(h, 'size') >= 9 ? { vote: this._opp(h[0].size), weight: 5.0 } : null);
    p['10. Mini Dragon'] = (h) => (this._streak(h, 'size') === 3 ? { vote: h[0].size, weight: 2.6 } : null);
    p['11. Color Dragon'] = (h) => (this._streak(h, 'pureColor') >= 5 ? { vote: h[0].size, weight: 2.5 } : null);
    p['12. Big Dragon'] = (h) =>
      h[0].size === 'Big' && this._streak(h, 'size') >= 4 && this._streak(h, 'size') < 7 ? { vote: 'Big', weight: 3.8 } : null;
    p['13. Small Dragon'] = (h) =>
      h[0].size === 'Small' && this._streak(h, 'size') >= 4 && this._streak(h, 'size') < 7 ? { vote: 'Small', weight: 3.8 } : null;
    p['14. Violet Dragon'] = (h) => (h[1] && h[0].isViolet && h[1].isViolet ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['15. Red Dragon'] = (h) => (h[0].pureColor === 'Red' && this._streak(h, 'pureColor') >= 4 ? { vote: h[0].size, weight: 2.5 } : null);
    p['16. Green Dragon'] = (h) => (h[0].pureColor === 'Green' && this._streak(h, 'pureColor') >= 4 ? { vote: h[0].size, weight: 2.5 } : null);

    p['17. Alternating'] = (h) => (this._jumping(h, 'size', 3) ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['18. 1-1 Pattern'] = (h) =>
      this._matchSeq(h, 'size', ['Big', 'Small', 'Big'])
        ? { vote: 'Small', weight: 4.0 }
        : this._matchSeq(h, 'size', ['Small', 'Big', 'Small'])
        ? { vote: 'Big', weight: 4.0 }
        : null;
    p['19. 2-2 Pattern'] = (h) => {
      if (this._matchSeq(h, 'size', ['Big', 'Small', 'Small'])) return { vote: 'Big', weight: 3.6 };
      if (this._matchSeq(h, 'size', ['Small', 'Big', 'Big'])) return { vote: 'Small', weight: 3.6 };
      return null;
    };
    p['20. 3-3 Pattern'] = (h) => {
      if (this._matchSeq(h, 'size', ['Big', 'Big', 'Small', 'Small', 'Small'])) return { vote: 'Big', weight: 4.2 };
      if (this._matchSeq(h, 'size', ['Small', 'Small', 'Big', 'Big', 'Big'])) return { vote: 'Small', weight: 4.2 };
      return null;
    };
    p['21. 2-1 Pattern'] = (h) =>
      this._matchSeq(h, 'size', ['Big', 'Small', 'Small'])
        ? { vote: 'Big', weight: 3.2 }
        : this._matchSeq(h, 'size', ['Small', 'Big', 'Big'])
        ? { vote: 'Small', weight: 3.2 }
        : null;
    p['22. 1-2 Pattern'] = (h) =>
      this._matchSeq(h, 'size', ['Small', 'Small', 'Big'])
        ? { vote: 'Small', weight: 3.2 }
        : this._matchSeq(h, 'size', ['Big', 'Big', 'Small'])
        ? { vote: 'Big', weight: 3.2 }
        : null;
    p['23. 3-2-1 Pattern'] = (h) =>
      this._matchSeq(h, 'size', ['Small', 'Big', 'Big', 'Small', 'Small', 'Small']) ? { vote: 'Big', weight: 4.0 } : null;
    p['24. 1-2-3 Pattern'] = (h) =>
      this._matchSeq(h, 'size', ['Big', 'Big', 'Big', 'Small', 'Small', 'Big']) ? { vote: 'Small', weight: 4.0 } : null;

    p['25. Double Mirror'] = (h) => (this._mirror(h, 'size', 4) ? { vote: this._opp(h[0].size), weight: 3.4 } : null);
    p['26. Triple Mirror'] = (h) => (this._mirror(h, 'size', 6) ? { vote: this._opp(h[0].size), weight: 3.8 } : null);
    p['27. Symmetrical'] = (h) =>
      h[3] && h[0].size === h[3].size && h[1].size === h[2].size && h[0].size !== h[1].size
        ? { vote: this._opp(h[0].size), weight: 3.2 }
        : null;
    p['28. Reverse Mirror'] = (h) =>
      h.length >= 4 && h[0].size !== h[3].size && h[1].size !== h[2].size ? { vote: h[0].size, weight: 2.4 } : null;
    p['29. Half Mirror'] = (h) => (h[2] && h[0].size === h[2].size && h[1].size !== h[0].size ? { vote: h[1].size, weight: 3.1 } : null);
    p['30. Full Mirror'] = (h) => (this._mirror(h, 'size', 5) ? { vote: this._opp(h[0].size), weight: 4.0 } : null);
    p['31. Jumping Red'] = (h) =>
      h[2] && h[0].pureColor === 'Red' && h[1].pureColor === 'Green' && h[2].pureColor === 'Red'
        ? { vote: this._opp(h[0].size), weight: 2.8 }
        : null;
    p['32. Jumping Green'] = (h) =>
      h[2] && h[0].pureColor === 'Green' && h[1].pureColor === 'Red' && h[2].pureColor === 'Green'
        ? { vote: this._opp(h[0].size), weight: 2.8 }
        : null;
    p['33. Jumping Violet'] = (h) =>
      h[2] && !h[0].isViolet && h[1].isViolet && !h[2].isViolet ? { vote: this._opp(h[0].size), weight: 2.5 } : null;
    p['34. Color Jump'] = (h) =>
      h[2] && h[0].pureColor !== h[1].pureColor && h[1].pureColor !== h[2].pureColor
        ? { vote: this._opp(h[0].size), weight: 2.7 }
        : null;
    p['35. Big Jump'] = (h) =>
      h[2] && h[0].size === 'Big' && h[1].size === 'Small' && h[2].size === 'Big' ? { vote: 'Small', weight: 3.5 } : null;
    p['36. Small Jump'] = (h) =>
      h[2] && h[0].size === 'Small' && h[1].size === 'Big' && h[2].size === 'Small' ? { vote: 'Big', weight: 3.5 } : null;

    p['37. Staircase Up'] = (h) => (h[2] && h[0].num > h[1].num && h[1].num > h[2].num ? { vote: 'Big', weight: 2.9 } : null);
    p['38. Staircase Down'] = (h) => (h[2] && h[0].num < h[1].num && h[1].num < h[2].num ? { vote: 'Small', weight: 2.9 } : null);
    p['39. Big Staircase'] = (h) =>
      h[1] && h[0].size === 'Big' && h[1].size === 'Big' && h[0].num > h[1].num ? { vote: 'Big', weight: 2.8 } : null;
    p['40. Small Staircase'] = (h) =>
      h[1] && h[0].size === 'Small' && h[1].size === 'Small' && h[0].num < h[1].num ? { vote: 'Small', weight: 2.8 } : null;
    p['41. Color Staircase'] = (h) =>
      h[2] && h[0].pureColor === h[1].pureColor && h[0].num > h[1].num && h[1].num > h[2].num
        ? { vote: 'Big', weight: 2.5 }
        : null;
    p['42. Number Staircase'] = (h) =>
      h[2] && Math.abs(h[0].num - h[1].num) === 1 && Math.abs(h[1].num - h[2].num) === 1
        ? { vote: h[0].num > h[1].num ? 'Big' : 'Small', weight: 2.8 }
        : null;
    p['43. Continuous Red'] = (h) =>
      this._streak(h, 'pureColor') >= 3 && h[0].pureColor === 'Red' ? { vote: h[0].size, weight: 2.4 } : null;
    p['44. Continuous Green'] = (h) =>
      this._streak(h, 'pureColor') >= 3 && h[0].pureColor === 'Green' ? { vote: h[0].size, weight: 2.4 } : null;
    p['45. Continuous Big'] = (h) =>
      this._streak(h, 'size') >= 3 && h[0].size === 'Big' && this._streak(h, 'size') < 6 ? { vote: 'Big', weight: 3.2 } : null;
    p['46. Continuous Small'] = (h) =>
      this._streak(h, 'size') >= 3 && h[0].size === 'Small' && this._streak(h, 'size') < 6 ? { vote: 'Small', weight: 3.2 } : null;
    p['47. Continuous Violet'] = (h) => (h[1] && h[0].isViolet && h[1].isViolet ? { vote: this._opp(h[0].size), weight: 2.9 } : null);

    p['48. Break Pattern'] = (h) =>
      h[1] && this._streak(h.slice(1), 'size') >= 4 && h[0].size !== h[1].size ? { vote: h[0].size, weight: 3.6 } : null;
    p['49. Reversal'] = (h) => (this._streak(h, 'size') >= 5 ? { vote: this._opp(h[0].size), weight: 4.0 } : null);
    p['50. Mean Reversion'] = (h) => {
      if (h.length < 10) return null;
      const avg = h.slice(0, 10).reduce((a, b) => a + b.num, 0) / 10;
      return avg >= 5.8 ? { vote: 'Small', weight: 3.4 } : avg <= 3.2 ? { vote: 'Big', weight: 3.4 } : null;
    };
    p['51. Hot Streak'] = (h) => (this._streak(h, 'size') >= 3 && this._streak(h, 'size') <= 5 ? { vote: h[0].size, weight: 2.8 } : null);
    p['52. Cold Streak'] = (h) => (this._streak(h, 'size') >= 6 ? { vote: this._opp(h[0].size), weight: 3.8 } : null);
    p['53. Momentum'] = (h) =>
      h[1] && h[0].num >= 7 && h[1].num >= 6
        ? { vote: 'Big', weight: 3.0 }
        : h[1] && h[0].num <= 2 && h[1].num <= 3
        ? { vote: 'Small', weight: 3.0 }
        : null;
    p['54. Trend Follow'] = (h) => {
      if (h.length < 10) return null;
      const bigs = h.slice(0, 10).filter((x) => x.size === 'Big').length;
      return bigs >= 7 && this._streak(h, 'size') < 5
        ? { vote: 'Big', weight: 3.3 }
        : bigs <= 3 && this._streak(h, 'size') < 5
        ? { vote: 'Small', weight: 3.3 }
        : null;
    };
    p['55. Counter Trend'] = (h) => {
      if (h.length < 10) return null;
      const bigs = h.slice(0, 10).filter((x) => x.size === 'Big').length;
      return bigs >= 8 ? { vote: 'Small', weight: 3.8 } : bigs <= 2 ? { vote: 'Big', weight: 3.8 } : null;
    };
    p['56. Pair Pattern'] = (h) => (h[1] && h[0].num === h[1].num ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['57. Triple Pair'] = (h) =>
      h[3] && h[0].size === h[1].size && h[2].size === h[3].size && h[0].size !== h[2].size
        ? { vote: h[0].size, weight: 3.4 }
        : null;
    p['58. Quad Pattern'] = (h) => (this._streak(h, 'size') === 4 ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['59. Cycle Pattern'] = (h) =>
      h[4] && h[0].size === h[3].size && h[1].size === h[4].size ? { vote: h[2].size, weight: 3.0 } : null;
    p['60. Loop Pattern'] = (h) =>
      h[5] && h[0].size === h[4].size && h[1].size === h[5].size ? { vote: h[2].size, weight: 2.8 } : null;
    p['61. Wave Pattern'] = (h) =>
      h[2] && h[0].num > h[1].num && h[1].num < h[2].num
        ? { vote: 'Small', weight: 2.6 }
        : h[2] && h[0].num < h[1].num && h[1].num > h[2].num
        ? { vote: 'Big', weight: 2.6 }
        : null;
    p['62. Spike Pattern'] = (h) => (h[1] && Math.abs(h[0].num - h[1].num) >= 6 ? { vote: this._opp(h[0].size), weight: 3.2 } : null);

    p['63. Cluster'] = (h) => (h.length >= 4 && h.slice(0, 4).every((x) => x.num >= 4 && x.num <= 6) ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['64. Color Cluster'] = (h) => (h.length >= 5 && h.slice(0, 5).filter((x) => x.pureColor === 'Red').length >= 4 ? { vote: 'Small', weight: 2.6 } : null);
    p['65. Number Cluster'] = (h) => (h[1] && Math.abs(h[0].num - h[1].num) <= 1 ? { vote: this._opp(h[0].size), weight: 2.5 } : null);
    p['66. Big Cluster'] = (h) => (h.length >= 6 && h.slice(0, 6).filter((x) => x.size === 'Big').length >= 5 ? { vote: 'Small', weight: 3.4 } : null);
    p['67. Small Cluster'] = (h) => (h.length >= 6 && h.slice(0, 6).filter((x) => x.size === 'Small').length >= 5 ? { vote: 'Big', weight: 3.4 } : null);
    p['68. Violet Cluster'] = (h) => (h.length >= 6 && h.slice(0, 6).filter((x) => x.isViolet).length >= 2 ? { vote: this._opp(h[0].size), weight: 2.7 } : null);
    p['69. Odd Even'] = (h) => (h[2] && h[0].parity === 'Odd' && h[1].parity === 'Even' && h[2].parity === 'Odd' ? { vote: 'Big', weight: 2.5 } : null);
    p['70. Even Odd'] = (h) => (h[2] && h[0].parity === 'Even' && h[1].parity === 'Odd' && h[2].parity === 'Even' ? { vote: 'Small', weight: 2.5 } : null);
    p['71. Parity Shift'] = (h) => (h[2] && h[0].parity !== h[1].parity && h[1].parity !== h[2].parity ? { vote: this._opp(h[0].size), weight: 2.4 } : null);
    p['72. Color Shift'] = (h) => (h[2] && h[0].pureColor !== h[1].pureColor && h[1].pureColor !== h[2].pureColor ? { vote: this._opp(h[0].size), weight: 2.6 } : null);
    p['73. Size Shift'] = (h) => (h[2] && h[0].size !== h[1].size && h[1].size === h[2].size ? { vote: h[0].size, weight: 2.8 } : null);
    p['74. Dual Color'] = (h) => (h[0].isViolet ? { vote: this._opp(h[0].size), weight: 2.9 } : null);
    p['75. Split Pattern'] = (h) => (h[3] && h[0].size !== h[1].size && h[1].size === h[2].size && h[2].size === h[3].size ? { vote: h[0].size, weight: 3.0 } : null);

    p['76. Hybrid'] = (h) => (h[1] && h[0].pureColor === 'Red' && h[0].size === 'Big' && h[1].pureColor === 'Green' && h[1].size === 'Small' ? { vote: 'Big', weight: 3.0 } : null);
    p['77. Boundary'] = (h) => (h[0].num === 0 || h[0].num === 9 ? { vote: h[0].num === 0 ? 'Big' : 'Small', weight: 3.6 } : null);
    p['78. Edge Pattern'] = (h) => (h[0].num <= 1 || h[0].num >= 8 ? { vote: h[0].num <= 1 ? 'Big' : 'Small', weight: 3.2 } : null);
    p['79. Core Pattern'] = (h) => (h[0].num >= 4 && h[0].num <= 5 ? { vote: h[0].num === 4 ? 'Big' : 'Small', weight: 2.7 } : null);
    p['80. Balance'] = (h) => (h.length >= 10 && h.slice(0, 10).filter((x) => x.size === 'Big').length === 5 ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['81. Imbalance'] = (h) => {
      if (h.length < 8) return null;
      const b = h.slice(0, 8).filter((x) => x.size === 'Big').length;
      return b >= 6 ? { vote: 'Small', weight: 3.8 } : b <= 2 ? { vote: 'Big', weight: 3.8 } : null;
    };
    p['82. Overload'] = (h) => (this._streak(h, 'size') >= 5 ? { vote: this._opp(h[0].size), weight: 3.6 } : null);
    p['83. Underload'] = (h) => {
      if (h.length < 10) return null;
      const last = h.slice(0, 10).filter((x) => x.size === 'Big').length;
      return last <= 3 ? { vote: 'Big', weight: 3.4 } : last >= 7 ? { vote: 'Small', weight: 3.4 } : null;
    };
    p['84. Frequency High'] = (h) => {
      if (h.length < 15) return null;
      const bigs = h.slice(0, 15).filter((x) => x.size === 'Big').length;
      return bigs >= 11 ? { vote: 'Small', weight: 3.5 } : bigs <= 4 ? { vote: 'Big', weight: 3.5 } : null;
    };
    p['85. Frequency Low'] = (h) => {
      if (h.length < 15) return null;
      const bigs = h.slice(0, 15).filter((x) => x.size === 'Big').length;
      return bigs <= 4 ? { vote: 'Big', weight: 3.5 } : null;
    };
    p['86. Missing Pattern'] = (h) => (h.length >= 5 && !h.slice(0, 5).some((x) => x.size === 'Big') ? { vote: 'Big', weight: 4.2 } : null);
    p['87. Due Pattern'] = (h) => (h.length >= 5 && !h.slice(0, 5).some((x) => x.size === 'Small') ? { vote: 'Small', weight: 4.2 } : null);
    p['88. Overdue'] = (h) => (this._streak(h, 'size') >= 6 ? { vote: this._opp(h[0].size), weight: 4.0 } : null);
    p['89. Repeat'] = (h) => (h[1] && h[0].size === h[1].size && this._streak(h, 'size') === 2 ? { vote: h[0].size, weight: 2.2 } : null);
    p['90. Non Repeat'] = (h) => (h[2] && h[0].size !== h[1].size && h[1].size !== h[2].size ? { vote: this._opp(h[0].size), weight: 3.0 } : null);

    p['91. Single Repeat'] = (h) => (h[2] && h[0].size === h[1].size && h[1].size !== h[2].size ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['92. Double Repeat'] = (h) => (h[3] && h[0].size === h[1].size && h[2].size === h[3].size && h[0].size !== h[2].size ? { vote: this._opp(h[0].size), weight: 3.3 } : null);
    p['93. Triple Repeat'] = (h) => (this._streak(h, 'size') === 3 ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['94. Chain'] = (h) => (this._streak(h, 'size') >= 3 && this._streak(h, 'size') < 6 ? { vote: h[0].size, weight: 2.9 } : null);
    p['95. Color Chain'] = (h) => (this._streak(h, 'pureColor') >= 4 && this._streak(h, 'pureColor') < 7 ? { vote: h[0].size, weight: 2.5 } : null);
    p['96. Size Chain'] = (h) => (this._streak(h, 'size') >= 4 && this._streak(h, 'size') < 6 ? { vote: h[0].size, weight: 3.2 } : null);
    p['97. Number Chain'] = (h) => (h[1] && Math.abs(h[0].num - h[1].num) === 1 ? { vote: h[0].num > h[1].num ? 'Big' : 'Small', weight: 2.6 } : null);
    p['98. Break Chain'] = (h) => (this._streak(h, 'size') >= 5 ? { vote: this._opp(h[0].size), weight: 3.6 } : null);
    p['99. Link Pattern'] = (h) => (h[2] && h[0].num === h[2].num ? { vote: this._opp(h[1].size), weight: 2.9 } : null);
    p['100. Bridge'] = (h) => (h[2] && h[0].size === h[2].size && h[1].size !== h[0].size ? { vote: h[0].size, weight: 3.3 } : null);
    p['101. Peak'] = (h) => (h[2] && h[1].num > h[0].num && h[1].num > h[2].num ? { vote: 'Small', weight: 2.8 } : null);
    p['102. Valley'] = (h) => (h[2] && h[1].num < h[0].num && h[1].num < h[2].num ? { vote: 'Big', weight: 2.8 } : null);
    p['103. Peak Valley'] = (h) => (h[1] && h[0].num >= 8 && h[1].num <= 1 ? { vote: 'Small', weight: 3.0 } : null);
    p['104. Rise'] = (h) => (h[2] && h[0].num > h[1].num && h[1].num > h[2].num ? { vote: 'Big', weight: 2.5 } : null);
    p['105. Fall'] = (h) => (h[2] && h[0].num < h[1].num && h[1].num < h[2].num ? { vote: 'Small', weight: 2.5 } : null);

    p['106. Rise Fall'] = (h) => (h[2] && h[0].num < h[1].num && h[1].num > h[2].num ? { vote: 'Small', weight: 2.6 } : null);
    p['107. Flat'] = (h) => (h[1] && h[0].num === h[1].num ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['108. Steady'] = (h) => (h[2] && Math.abs(h[0].num - h[1].num) <= 2 && Math.abs(h[1].num - h[2].num) <= 2 ? { vote: h[0].size, weight: 2.4 } : null);
    p['109. Volatile'] = (h) => (h[2] && Math.abs(h[0].num - h[1].num) >= 5 && Math.abs(h[1].num - h[2].num) >= 5 ? { vote: this._opp(h[0].size), weight: 3.4 } : null);
    p['110. Calm'] = (h) => (h[1] && Math.abs(h[0].num - h[1].num) <= 1 ? { vote: this._opp(h[0].size), weight: 2.5 } : null);
    p['111. Storm'] = (h) => (h[2] && Math.abs(h[0].num - h[1].num) >= 5 && Math.abs(h[1].num - h[2].num) >= 5 ? { vote: this._opp(h[0].size), weight: 3.6 } : null);
    p['112. Quiet'] = (h) => (h[1] && h[0].num >= 4 && h[0].num <= 5 && h[1].num >= 4 && h[1].num <= 5 ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['113. Burst'] = (h) => (h[0].num === 9 || h[0].num === 0 ? { vote: h[0].num === 9 ? 'Small' : 'Big', weight: 3.5 } : null);
    p['114. Explosion'] = (h) => (h[1] && h[0].num === 0 && h[1].num === 9 ? { vote: 'Small', weight: 4.0 } : null);
    p['115. Fade'] = (h) => (h[1] && h[0].num === 5 && h[1].num === 4 ? { vote: 'Small', weight: 2.8 } : null);
    p['116. Strong'] = (h) => (this._streak(h, 'size') >= 4 && this._streak(h, 'size') < 6 ? { vote: h[0].size, weight: 3.2 } : null);
    p['117. Weak'] = (h) => (h[2] && this._streak(h, 'size') === 1 && h[1].size !== h[2].size ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['118. Dominant'] = (h) => (h.length >= 10 && h.slice(0, 10).filter((x) => x.size === 'Big').length >= 8 ? { vote: 'Small', weight: 3.6 } : null);
    p['119. Recessive'] = (h) => (h.length >= 10 && h.slice(0, 10).filter((x) => x.size === 'Small').length >= 8 ? { vote: 'Big', weight: 3.6 } : null);
    p['120. Leader'] = (h) => (h.length >= 8 && h.slice(0, 8).filter((x) => x.size === h[0].size).length >= 6 && this._streak(h, 'size') < 5 ? { vote: h[0].size, weight: 2.7 } : null);
    p['121. Follower'] = (h) => (h[2] && this._streak(h, 'size') === 2 && h[2].size !== h[1].size ? { vote: h[0].size, weight: 2.4 } : null);
    p['122. Switch'] = (h) => (this._streak(h, 'size') >= 5 ? { vote: this._opp(h[0].size), weight: 3.4 } : null);
    p['123. Flip'] = (h) => (this._jumping(h, 'size', 3) ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['124. Flip Flop'] = (h) => (h[2] && h[0].size !== h[1].size && h[1].size !== h[2].size ? { vote: this._opp(h[0].size), weight: 3.5 } : null);
    p['125. Toggle'] = (h) => (h[2] && h[0].size !== h[1].size && h[1].size === h[2].size ? { vote: h[0].size, weight: 2.8 } : null);
    p['126. Oscillate'] = (h) => (this._jumping(h, 'size', 3) ? { vote: this._opp(h[0].size), weight: 3.4 } : null);
    p['127. Swing'] = (h) => (h[1] && Math.abs(h[0].num - h[1].num) >= 5 ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['128. Pendulum'] = (h) => (h[2] && h[0].size === h[2].size && h[1].size !== h[0].size ? { vote: h[0].size, weight: 3.2 } : null);
    p['129. Bounce'] = (h) => (h[0].num === 0 || h[0].num === 9 ? { vote: h[0].num === 0 ? 'Big' : 'Small', weight: 3.4 } : null);
    p['130. Rebound'] = (h) => (h[2] && h[0].size !== h[1].size && h[1].size === h[2].size ? { vote: h[0].size, weight: 2.9 } : null);
    p['131. Echo'] = (h) => (h[2] && h[0].num === h[2].num && h[0].size !== h[1].size ? { vote: h[1].size, weight: 2.9 } : null);
    p['132. Shadow'] = (h) => (h[3] && h[0].size === h[2].size && h[1].size === h[3].size ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['133. Ghost'] = (h) => (h[3] && h[0].size === h[3].size && h[1].size === h[2].size ? { vote: this._opp(h[0].size), weight: 3.1 } : null);
    p['134. Phantom'] = (h) => (h[3] && h[0].num === h[3].num ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['135. Twin'] = (h) => (h[1] && h[0].num === h[1].num ? { vote: this._opp(h[0].size), weight: 3.2 } : null);

    p['136. Clone'] = (h) => (h[1] && h[0].num === h[1].num ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['137. Copy'] = (h) => (h[3] && h[0].size === h[2].size && h[1].size === h[3].size ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['138. Match'] = (h) => (h[1] && h[0].size === h[1].size && this._streak(h, 'size') === 2 ? { vote: this._opp(h[0].size), weight: 2.5 } : null);
    p['139. Mismatch'] = (h) => (h[1] && h[0].size !== h[1].size ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['140. Sync'] = (h) => (h[1] && h[0].size === 'Big' && h[0].parity === 'Odd' && h[1].size === 'Small' && h[1].parity === 'Even' ? { vote: 'Big', weight: 3.1 } : null);
    p['141. Desync'] = (h) => (h[1] && h[0].size === 'Small' && h[0].parity === 'Even' && h[1].size === 'Big' && h[1].parity === 'Odd' ? { vote: 'Small', weight: 3.1 } : null);
    p['142. Phase'] = (h) => (this._matchSeq(h, 'size', ['Big', 'Small']) ? { vote: 'Big', weight: 2.8 } : null);
    p['143. Phase Shift'] = (h) => (h[2] && this._streak(h, 'size') === 2 && h[2].size !== h[1].size ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['144. Cycle 2'] = (h) => (h[3] && h[0].size === h[2].size && h[1].size === h[3].size ? { vote: this._opp(h[0].size), weight: 3.3 } : null);
    p['145. Cycle 3'] = (h) => (h[5] && h[0].size === h[3].size && h[1].size === h[4].size && h[2].size === h[5].size ? { vote: h[0].size, weight: 3.4 } : null);
    p['146. Cycle 4'] = (h) => (h[5] && h[0].size === h[4].size && h[1].size === h[5].size ? { vote: eVal(h[1].size), weight: 3.3 } : null);
    p['147. Cycle 5'] = (h) => (h[6] && h[0].size === h[5].size && h[1].size === h[6].size ? { vote: eVal(h[1].size), weight: 3.0 } : null);
    p['148. Short Cycle'] = (h) => (this._jumping(h, 'size', 3) ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['149. Long Cycle'] = (h) => (this._streak(h, 'size') >= 6 ? { vote: this._opp(h[0].size), weight: 4.0 } : null);
    p['150. Micro Pattern'] = (h) => (h[0].num === 0 ? { vote: 'Big', weight: 3.2 } : h[0].num === 9 ? { vote: 'Small', weight: 3.2 } : null);

    function eVal(v: 'Big' | 'Small'): 'Big' | 'Small' {
      return v;
    }

    p['151. Macro Pattern'] = (h) => {
      if (h.length < 20) return null;
      const bigs = h.slice(0, 20).filter((x) => x.size === 'Big').length;
      return bigs >= 14 ? { vote: 'Small', weight: 4.2 } : bigs <= 6 ? { vote: 'Big', weight: 4.2 } : null;
    };
    p['152. Mini Wave'] = (h) => (h[2] && h[0].num > h[1].num && h[1].num < h[2].num ? { vote: 'Small', weight: 2.6 } : null);
    p['153. Mega Wave'] = (h) => (h[2] && Math.abs(h[0].num - h[1].num) >= 5 && Math.abs(h[1].num - h[2].num) >= 5 ? { vote: this._opp(h[0].size), weight: 3.5 } : null);
    p['154. Soft Trend'] = (h) => (this._streak(h, 'size') === 2 ? { vote: h[0].size, weight: 2.2 } : null);
    p['155. Hard Trend'] = (h) => (this._streak(h, 'size') >= 5 ? { vote: this._opp(h[0].size), weight: 3.8 } : null);
    p['156. Soft Dragon'] = (h) => (this._streak(h, 'size') === 3 ? { vote: h[0].size, weight: 2.8 } : null);
    p['157. Hard Dragon'] = (h) => (this._streak(h, 'size') >= 6 ? { vote: this._opp(h[0].size), weight: 4.2 } : null);
    p['158. Soft Mirror'] = (h) => (this._mirror(h, 'size', 2) ? { vote: this._opp(h[0].size), weight: 2.6 } : null);
    p['159. Hard Mirror'] = (h) => (this._mirror(h, 'size', 4) ? { vote: this._opp(h[0].size), weight: 4.0 } : null);
    p['160. Soft Jump'] = (h) => (h[2] && h[0].size !== h[1].size && h[1].size !== h[2].size ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['161. Hard Jump'] = (h) => (this._jumping(h, 'size', 4) ? { vote: this._opp(h[0].size), weight: 4.2 } : null);
    p['162. Soft Stair'] = (h) => (h[2] && h[0].num > h[1].num && h[1].num > h[2].num ? { vote: 'Big', weight: 2.6 } : null);
    p['163. Hard Stair'] = (h) => (h[3] && h[0].num > h[1].num && h[1].num > h[2].num && h[2].num > h[3].num ? { vote: 'Big', weight: 3.8 } : null);
    p['164. Red Green'] = (h) => (h[1] && h[0].pureColor === 'Green' && h[1].pureColor === 'Red' ? { vote: this._opp(h[0].size), weight: 2.5 } : null);
    p['165. Green Red'] = (h) => (h[1] && h[0].pureColor === 'Red' && h[1].pureColor === 'Green' ? { vote: this._opp(h[0].size), weight: 2.5 } : null);

    p['166. Red Violet'] = (h) => (h[0].num === 0 ? { vote: 'Big', weight: 3.4 } : null);
    p['167. Green Violet'] = (h) => (h[0].num === 5 ? { vote: 'Small', weight: 3.4 } : null);
    p['168. Violet Red'] = (h) => (h[1] && h[1].num === 0 && h[0].pureColor === 'Red' ? { vote: 'Big', weight: 3.0 } : null);
    p['169. Violet Green'] = (h) => (h[1] && h[1].num === 5 && h[0].pureColor === 'Green' ? { vote: 'Small', weight: 3.0 } : null);
    p['170. Big Small'] = (h) => (h[2] && h[0].size === 'Small' && h[1].size === 'Big' && h[2].size === 'Small' ? { vote: 'Big', weight: 3.5 } : null);
    p['171. Small Big'] = (h) => (h[2] && h[0].size === 'Big' && h[1].size === 'Small' && h[2].size === 'Big' ? { vote: 'Small', weight: 3.5 } : null);
    p['172. Big Big'] = (h) => (h[2] && h[0].size === 'Big' && h[1].size === 'Big' && h[2].size === 'Small' ? { vote: 'Small', weight: 3.2 } : null);
    p['173. Small Small'] = (h) => (h[2] && h[0].size === 'Small' && h[1].size === 'Small' && h[2].size === 'Big' ? { vote: 'Big', weight: 3.2 } : null);
    p['174. Mixed Size'] = (h) => (h[2] && h[0].size !== h[1].size && h[1].size !== h[2].size ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['175. Pure Color'] = (h) => (h[1] && !h[0].isViolet && !h[1].isViolet && h[0].pureColor !== h[1].pureColor ? { vote: this._opp(h[0].size), weight: 2.5 } : null);
    p['176. Mixed Color'] = (h) => (h[1] && h[0].isViolet !== h[1].isViolet ? { vote: this._opp(h[0].size), weight: 2.6 } : null);
    p['177. Number Hot'] = (h) => (h[1] && h[0].num >= 8 && h[1].num >= 7 ? { vote: 'Small', weight: 3.2 } : null);
    p['178. Number Cold'] = (h) => (h[1] && h[0].num <= 1 && h[1].num <= 2 ? { vote: 'Big', weight: 3.2 } : null);
    p['179. Digit Run'] = (h) => (h[2] && Math.abs(h[0].num - h[1].num) <= 1 && Math.abs(h[1].num - h[2].num) <= 1 ? { vote: this._opp(h[0].size), weight: 2.8 } : null);
    p['180. Digit Break'] = (h) => (h[1] && Math.abs(h[0].num - h[1].num) >= 6 ? { vote: this._opp(h[0].size), weight: 3.2 } : null);

    p['181. 0-5 Special'] = (h) => (h[0].num === 0 || h[0].num === 5 ? { vote: h[0].num === 0 ? 'Big' : 'Small', weight: 3.8 } : null);
    p['182. Violet Special'] = (h) => (h[0].isViolet ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['183. Dual Hit'] = (h) => (h[1] && h[0].num === h[1].num ? { vote: this._opp(h[0].size), weight: 3.2 } : null);
    p['184. Single Hit'] = (h) => (h[3] && h[0].size !== h[1].size && h[1].size === h[2].size && h[2].size === h[3].size ? { vote: h[0].size, weight: 3.1 } : null);
    p['185. Multi Hit'] = (h) => (this._streak(h, 'size') >= 3 && this._streak(h, 'size') < 6 ? { vote: h[0].size, weight: 2.9 } : null);
    p['186. Safe Pattern'] = (h) => {
      if (h.length < 10) return null;
      const bigs = h.slice(0, 10).filter((x) => x.size === 'Big').length;
      return bigs >= 7 ? { vote: 'Small', weight: 3.5 } : bigs <= 3 ? { vote: 'Big', weight: 3.5 } : null;
    };
    p['187. Risk Pattern'] = (h) => (this._streak(h, 'size') >= 5 ? { vote: this._opp(h[0].size), weight: 3.6 } : null);
    p['188. High Risk'] = (h) => (this._streak(h, 'size') >= 7 ? { vote: this._opp(h[0].size), weight: 4.2 } : null);
    p['189. Low Risk'] = (h) => (h[2] && this._streak(h, 'size') === 2 && h[2].size !== h[1].size ? { vote: h[0].size, weight: 2.6 } : null);
    p['190. Balanced Bet'] = (h) => {
      if (h.length < 6) return null;
      const diff = h.slice(0, 6).filter((x) => x.size === 'Big').length - 3;
      return diff > 1 ? { vote: 'Small', weight: 3.0 } : diff < -1 ? { vote: 'Big', weight: 3.0 } : null;
    };
    p['191. Aggressive'] = (h) => (this._streak(h, 'size') >= 4 && this._streak(h, 'size') < 7 ? { vote: h[0].size, weight: 3.5 } : null);
    p['192. Conservative'] = (h) => (h[2] && h[0].size === h[1].size && h[1].size === h[2].size ? { vote: this._opp(h[0].size), weight: 3.0 } : null);
    p['193. Momentum Ride'] = (h) =>
      h[1] && h[0].num >= 8 && h[1].num >= 7
        ? { vote: 'Big', weight: 3.2 }
        : h[1] && h[0].num <= 1 && h[1].num <= 2
        ? { vote: 'Small', weight: 3.2 }
        : null;
    p['194. Reversal Catch'] = (h) => (this._streak(h, 'size') >= 5 ? { vote: this._opp(h[0].size), weight: 4.2 } : null);
    p['195. Streak Ride'] = (h) => (this._streak(h, 'size') >= 3 && this._streak(h, 'size') < 6 ? { vote: h[0].size, weight: 3.2 } : null);
    p['196. Streak Break'] = (h) => (this._streak(h, 'size') >= 6 ? { vote: this._opp(h[0].size), weight: 4.5 } : null);
    p['197. Pattern Break'] = (h) => (h[1] && this._jumping(h.slice(1), 'size', 4) && h[0].size === h[1].size ? { vote: this._opp(h[0].size), weight: 3.6 } : null);
    p['198. New Pattern'] = (h) => (h[3] && h[0].size !== h[1].size && h[1].size !== h[2].size && h[2].size !== h[3].size ? { vote: this._opp(h[0].size), weight: 3.8 } : null);
    p['199. Classic Pattern'] = (h) =>
      this._matchSeq(h, 'size', ['Big', 'Big', 'Small', 'Small'])
        ? { vote: 'Big', weight: 3.8 }
        : this._matchSeq(h, 'size', ['Small', 'Small', 'Big', 'Big'])
        ? { vote: 'Small', weight: 3.8 }
        : null;
    p['200. Ultimate Pattern'] = (h) => {
      const streak = this._streak(h, 'size');
      const avg10 = h.length >= 10 ? h.slice(0, 10).reduce((a, b) => a + b.num, 0) / 10 : 4.5;
      if (streak >= 3 && streak < 6) return { vote: h[0].size, weight: 4.0 };
      if (streak >= 6) return { vote: this._opp(h[0].size), weight: 4.8 };
      return avg10 >= 5.8 ? { vote: 'Small', weight: 3.8 } : avg10 <= 3.2 ? { vote: 'Big', weight: 3.8 } : null;
    };

    return p;
  }

  public predict(nums: number[]): Titan200Result | null {
    if (!Array.isArray(nums) || nums.length < 3) return null;
    const h = this._normalize(nums);
    let bigScore = 0;
    let smallScore = 0;
    const triggered: { pattern: string; vote: 'Big' | 'Small'; weight: number }[] = [];

    for (const [name, fn] of Object.entries(this.patterns)) {
      try {
        const res = fn(h);
        if (res) {
          if (res.vote === 'Big') bigScore += res.weight;
          else smallScore += res.weight;
          triggered.push({ pattern: name, vote: res.vote, weight: res.weight });
        }
      } catch {
        // Ignore malformed
      }
    }

    const totalScore = bigScore + smallScore;
    const finalPrediction: 'Big' | 'Small' = bigScore >= smallScore ? 'Big' : 'Small';
    const confidence =
      totalScore > 0 ? Number(((Math.max(bigScore, smallScore) / totalScore) * 100).toFixed(2)) : 50;

    triggered.sort((a, b) => b.weight - a.weight);

    return {
      prediction: finalPrediction,
      confidence,
      bigScore: Number(bigScore.toFixed(2)),
      smallScore: Number(smallScore.toFixed(2)),
      totalPatternsTriggered: triggered.length,
      topSignals: triggered.slice(0, 8),
      currentStreak: {
        type: h[0].size,
        count: this._streak(h, 'size'),
      },
    };
  }
}

const master200Engine = new WingoBigSmallMaster200();

type FormulaMaker = (p: number[]) => { name: string; fn: (h: number[]) => 'B' | 'S' };

const FORMULA_TYPES: FormulaMaker[] = [
  (p) => { const [w0, w1, w2, w3, b] = p; return { name: `WLC[${w0},${w1},${w2},${w3},${b}]`, fn: (h) => (Math.abs(h[0] * w0 + h[1] * w1 + h[2] * w2 + h[3] * w3 + b) % 10 >= 5 ? 'B' : 'S') }; },
  (p) => { const [off, mul] = p; return { name: `DCH[${off},${mul}]`, fn: (h) => (Math.abs((h[0] - h[1] * mul + h[2] - h[3] * mul + off) * 3) % 10 >= 5 ? 'B' : 'S') }; },
  (p) => { const [base, mul] = p; const safe = Math.max(2, base); return { name: `PRM[${base},${mul}]`, fn: (h) => { const v = (h[0] + 1) * (h[1] + 1) * (h[2] + 1) * (h[3] + 1) * mul; return Math.abs(v) % safe >= safe / 2 ? 'B' : 'S'; } }; },
  (p) => { const [key, shift] = p; return { name: `XOR[${key},${shift}]`, fn: (h) => { const x = (((h[0] ^ key) << shift) ^ (h[1] ^ (key + 3)) ^ (h[2] << (shift % 4)) ^ h[3]); return Math.abs(x) % 10 >= 5 ? 'B' : 'S'; } }; },
  (p) => { const [t, w0, w1, w2, w3] = p; return { name: `PSW[${t},${w0},${w1},${w2},${w3}]`, fn: (h) => { const s = (h[0] >= 5 ? w0 : 1) + (h[1] >= 5 ? w1 : 1) + (h[2] >= 5 ? w2 : 1) + (h[3] >= 5 ? w3 : 1); return s % 10 >= t ? 'B' : 'S'; } }; },
  (p) => { const [mul, b] = p; return { name: `CSUM[${mul},${b}]`, fn: (h) => { let c = b; for (let i = 0; i < 4; i++) c += h[i] * (1 + ((i * 3) % 10)); return Math.abs(c * mul) % 10 >= 5 ? 'B' : 'S'; } }; },
  (p) => { const [b, m] = p; return { name: `RAVG[${b},${m}]`, fn: (h) => { const v = Math.floor(((h[0] + h[1] + h[2] + h[3]) / 4) * m + b); return Math.abs(v) % 10 >= 5 ? 'B' : 'S'; } }; },
  (p) => { const fib = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]; const [off, mul] = p; return { name: `FIB[${off},${mul}]`, fn: (h) => { let v = 0; for (let i = 0; i < 4; i++) v += h[i] * fib[(((off + i) % 10) + 10) % 10]; return Math.abs(v * mul) % 10 >= 5 ? 'B' : 'S'; } }; },
  (p) => { const primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]; const [pi, off] = p; const pm = primes[((pi % primes.length) + primes.length) % primes.length]; return { name: `PRMG[${pi},${off}]`, fn: (h) => { const s = h[0] * 2 + h[1] * 3 + h[2] * 5 + h[3] * 7 + off; return s % pm >= pm / 2 ? 'B' : 'S'; } }; },
  (p) => { const [r, w0, w1, w2, w3] = p; const row = ((r % 3) + 3) % 3; const ws = [[w0, w1, w2, w3], [((w0 + w1) % 9) + 1, ((w1 + w2) % 9) + 1, ((w2 + w3) % 9) + 1, ((w3 + w0) % 9) + 1], [((w0 + w2) % 9) + 1, ((w1 + w3) % 9) + 1, ((w0 + w3) % 9) + 1, ((w1 + w2) % 9) + 1]]; return { name: `MTX[${r},${w0},${w1},${w2},${w3}]`, fn: (h) => { let v = 0; for (let i = 0; i < 4; i++) v += h[i] * ws[row][i]; return Math.abs(v) % 10 >= 5 ? 'B' : 'S'; } }; },
  (p) => { const [bias, mult] = p; return { name: `DEL[${bias},${mult}]`, fn: (h) => { const d = (h[0] - h[1]) * mult + (h[2] - h[3]) + bias; return Math.abs(d) % 10 >= 5 ? 'B' : 'S'; } }; },
  (p) => { const [a, b, c, d, e] = p; return { name: `POL[${a},${b},${c},${d},${e}]`, fn: (h) => { const v = a * h[0] * h[0] + b * h[1] + c * h[2] * h[3] + d * h[0] * h[3] + e; return Math.abs(v) % 10 >= 5 ? 'B' : 'S'; } }; },
];

export function searchBestFormula(nums: number[], types: ('B' | 'S')[]): {
  found: boolean;
  size: DirectionSize;
  name: string;
  bestScore: number;
} {
  let found = false;
  let finalBS: DirectionSize = 'BIG';
  let finalName = 'TITAN-NEURAL';
  let best = 0;
  const seedSets = [
    [1, 2, 3, 4, 5],
    [2, 3, 5, 7, 11],
    [3, 1, 4, 1, 5],
    [5, 4, 3, 2, 1],
    [7, 5, 3, 2, 9],
    [1, 3, 7, 9, 2],
    [9, 7, 5, 3, 1],
  ];

  for (let fIdx = 0; fIdx < FORMULA_TYPES.length && !found; fIdx++) {
    for (const params of seedSets) {
      const { name, fn: formula } = FORMULA_TYPES[fIdx](params);
      let matchCount = 0;
      for (let j = 0; j < 10; j++) {
        const inp = nums.slice(j + 1, j + 5);
        if (inp.length < 4) continue;
        if (formula(inp) === types[j]) matchCount++;
      }
      if (matchCount > best && nums.length >= 4) {
        best = matchCount;
        finalBS = formula(nums.slice(0, 4)) === 'B' ? 'BIG' : 'SMALL';
        finalName = name;
      }
      if (matchCount === 10) {
        found = true;
        break;
      }
    }
  }
  return { found, size: finalBS, name: finalName, bestScore: best };
}

export function calculateRajputLogic(nums: number[], period: string): {
  name: string;
  size: DirectionSize;
  conf: number;
  hash: number;
} | null {
  if (!Array.isArray(nums) || nums.length < 3) return null;
  const clean = nums.filter(Number.isFinite).slice(0, 5);
  const pStr = String(period || '').replace(/\D/g, '');
  const pInt = pStr ? parseInt(pStr.slice(-3), 10) : 0;
  const weighted =
    clean[0] * 4 +
    clean[1] * 3 +
    clean[2] * 2 +
    (clean[3] !== undefined ? clean[3] : 0) +
    (clean[4] !== undefined ? clean[4] : 0);
  const hash = (weighted + pInt) % 10;
  const size: DirectionSize = hash >= 5 ? 'BIG' : 'SMALL';
  const conf = [0, 9].includes(hash) ? 97 : [1, 8].includes(hash) ? 94 : 90;
  return { name: 'SAMAD GOLD HASH', size, conf, hash };
}

const CPU_PATTERN_DB: Record<string, { next: DirectionSize; conf: number }> = {
  BBB: { next: 'SMALL', conf: 82 }, SSS: { next: 'BIG', conf: 82 },
  BBS: { next: 'SMALL', conf: 70 }, SSB: { next: 'BIG', conf: 70 },
  BSS: { next: 'BIG', conf: 68 }, SBB: { next: 'SMALL', conf: 68 },
  BSB: { next: 'SMALL', conf: 63 }, SBS: { next: 'BIG', conf: 63 },
  BBBB: { next: 'SMALL', conf: 88 }, SSSS: { next: 'BIG', conf: 88 },
  BBBS: { next: 'SMALL', conf: 84 }, SSSB: { next: 'BIG', conf: 84 },
  BBSS: { next: 'SMALL', conf: 76 }, SSBB: { next: 'BIG', conf: 76 },
  BSBS: { next: 'BIG', conf: 62 }, SBSB: { next: 'SMALL', conf: 62 },
  BSSB: { next: 'BIG', conf: 68 }, SBBS: { next: 'SMALL', conf: 68 },
  BSBB: { next: 'SMALL', conf: 68 }, SBSS: { next: 'BIG', conf: 68 },
  BBSB: { next: 'SMALL', conf: 72 }, SSBS: { next: 'BIG', conf: 72 },
  BSSS: { next: 'BIG', conf: 80 }, SBBB: { next: 'SMALL', conf: 80 },
  BBBBB: { next: 'SMALL', conf: 90 }, SSSSS: { next: 'BIG', conf: 90 },
  BBBBS: { next: 'SMALL', conf: 86 }, SSSSB: { next: 'BIG', conf: 86 },
  BBBSS: { next: 'SMALL', conf: 76 }, SSSBB: { next: 'BIG', conf: 76 },
  BSBSBS: { next: 'BIG', conf: 74 }, SBSBSB: { next: 'SMALL', conf: 74 },
  BBBBBB: { next: 'SMALL', conf: 94 }, SSSSSS: { next: 'BIG', conf: 94 },
  BBBBBBB: { next: 'SMALL', conf: 96 }, SSSSSSS: { next: 'BIG', conf: 96 },
};

function runBunnyAndCPUEngine(nums: number[]): { prediction: DirectionSize; confidence: number; name: string } {
  if (!nums || nums.length < 3) return { prediction: 'BIG', confidence: 60, name: 'CHAOS' };
  const types = nums.slice(0, 15).map((n) => (n >= 5 ? 'B' : 'S'));
  const seq = types.join('');

  for (let l = Math.min(seq.length, 6); l >= 3; l--) {
    const sub = seq.substring(0, l);
    if (CPU_PATTERN_DB[sub]) {
      return {
        prediction: CPU_PATTERN_DB[sub].next,
        confidence: CPU_PATTERN_DB[sub].conf,
        name: `CPU-PATTERN [${sub}]`,
      };
    }
  }

  for (let cl = 2; cl <= 4; cl++) {
    if (types.length >= cl * 2) {
      let match = true;
      for (let j = 0; j < cl; j++) {
        if (types[j] !== types[j + cl]) {
          match = false;
          break;
        }
      }
      if (match) {
        return {
          prediction: types[cl] === 'B' ? 'BIG' : 'SMALL',
          confidence: 88,
          name: `BUNNY-CYCLE-${cl}`,
        };
      }
    }
  }

  const bCount = types.slice(0, 8).filter((t) => t === 'B').length;
  if (bCount >= 6) return { prediction: 'SMALL', confidence: 80, name: 'HEAVY_BIG_REVERSE' };
  if (bCount <= 2) return { prediction: 'BIG', confidence: 80, name: 'HEAVY_SMALL_REVERSE' };

  return { prediction: types[0] === 'B' ? 'SMALL' : 'BIG', confidence: 68, name: 'ALT_FLOW' };
}

function mafiyaAnalyze(nums: number[]): { prediction: DirectionSize; confidence: number } {
  if (!nums || nums.length < 5) return { prediction: 'BIG', confidence: 55 };
  const sizes = nums.slice(0, 10).map((n) => (n >= 5 ? 'BIG' : 'SMALL'));
  const bCount = sizes.filter((s) => s === 'BIG').length;
  if (bCount >= 7) return { prediction: 'SMALL', confidence: 82 };
  if (bCount <= 3) return { prediction: 'BIG', confidence: 82 };
  return { prediction: sizes[0] === 'BIG' ? 'SMALL' : 'BIG', confidence: 70 };
}

export function marketRegime(nums: number[]): { name: string; icon: string } {
  const bshr = nums.slice(0, 24).map((n) => (n >= 5 ? 'BIG' : 'SMALL'));
  if (bshr.length < 8) return { name: 'NEUTRAL', icon: '≈' };
  let alt = 0;
  for (let i = 0; i < bshr.length - 1; i++) {
    if (bshr[i] !== bshr[i + 1]) alt++;
  }
  const altR = alt / (bshr.length - 1);
  let maxSt = 1;
  let cur = 1;
  for (let i = 1; i < bshr.length; i++) {
    if (bshr[i] === bshr[i - 1]) {
      cur++;
      if (cur > maxSt) maxSt = cur;
    } else cur = 1;
  }
  const bC = bshr.filter((x) => x === 'BIG').length;
  const bal = Math.abs(bC - (bshr.length - bC)) / bshr.length;
  if (maxSt >= 4 || bal >= 0.5) return { name: 'TRENDING', icon: '🐉' };
  if (altR >= 0.7 && maxSt <= 2) return { name: 'CHOPPY', icon: '🌪️' };
  return { name: 'NEUTRAL', icon: '≈' };
}

export function oracleScan(nums: number[]): { next: DirectionSize; occ: number; rate: number } | null {
  if (nums.length < 3) return null;
  const seqOldestFirst = nums.slice(0, 3).reverse().map((n) => (n >= 5 ? 'BIG' : 'SMALL'));
  const base = nums.length < 10 ? SEED_NUMS : nums.concat(SEED_NUMS);
  const sz = base.map((n) => (n >= 5 ? 'BIG' : 'SMALL'));
  const L = seqOldestFirst.length;
  let b = 0;
  let sm = 0;
  for (let i = 0; i + L < sz.length; i++) {
    let ok = true;
    for (let j = 0; j < L; j++) {
      if (sz[i + j] !== seqOldestFirst[j]) {
        ok = false;
        break;
      }
    }
    if (ok) {
      if (sz[i + L] === 'BIG') b++;
      else sm++;
    }
  }
  const occ = b + sm;
  if (occ < 6) return null;
  const rate = Math.max(b, sm) / occ;
  return { next: b >= sm ? 'BIG' : 'SMALL', occ, rate: Math.round(rate * 100) };
}

function primeFusionStrategy(nums: number[]): { size: DirectionSize; domName: string; domDetail: string } {
  const bsh = nums.map((n) => (n >= 5 ? 'BIG' : 'SMALL'));
  let wB = 0.5;
  let wS = 0.5;
  let streak = bsh.length ? 1 : 0;
  for (let i = 1; i < Math.min(bsh.length, 12); i++) {
    if (bsh[i] === bsh[0]) streak++;
    else break;
  }

  let domName = 'MARKOV';
  let domDetail = 'Base Flow';
  let lockSize: DirectionSize | null = null;

  if (streak >= 6) {
    lockSize = bsh[0] === 'BIG' ? 'SMALL' : 'BIG';
    domName = '🐉 DRAGON-BREAK';
    domDetail = `Streak ${streak} exhausted`;
  } else if (streak >= 3) {
    lockSize = bsh[0] as DirectionSize;
    domName = '🐉 DRAGON-RIDE';
    domDetail = `Streak ${streak} intact`;
  }

  if (!lockSize && bsh.length >= 4) {
    if (bsh[0] === bsh[1] && bsh[2] === bsh[3] && bsh[0] !== bsh[2]) {
      lockSize = bsh[0] === 'BIG' ? 'SMALL' : 'BIG';
      domName = 'TWIN 2-2 LOCK';
      domDetail = 'Pair Flip Lock';
    }
  }

  if (!lockSize && bsh.length >= 6) {
    if (bsh[0] === bsh[3] && bsh[1] === bsh[4] && bsh[2] === bsh[5] && bsh[0] !== bsh[2]) {
      lockSize = bsh[2] as DirectionSize;
      domName = '3-CYCLE LOCK';
      domDetail = 'Cycle Repeat Locked';
    }
  }

  if (lockSize) {
    if (lockSize === 'BIG') {
      wB += 0.45;
      wS -= 0.2;
    } else {
      wS += 0.45;
      wB -= 0.2;
    }
  }

  return {
    size: wB >= wS ? 'BIG' : 'SMALL',
    domName,
    domDetail,
  };
}

const ML_LOGICS: { name: string; weight: number; fn: (nums: number[]) => DirectionSize | null }[] = [
  {
    name: 'STREAK_ENGINE',
    weight: 12,
    fn(nums) {
      const c = nums.slice(0, 5).filter((n) => n >= 5).length;
      if (c >= 4) return 'BIG';
      if (c <= 1) return 'SMALL';
      return null;
    },
  },
  {
    name: 'BD_AKASH_ALT',
    weight: 10,
    fn(nums) {
      if (nums.length < 5) return null;
      const sizes = nums.slice(0, 4).map((n) => (n >= 5 ? 1 : 0));
      let alt = true;
      for (let i = 0; i < 3; i++) {
        if (sizes[i] === sizes[i + 1]) {
          alt = false;
          break;
        }
      }
      if (alt) return sizes[0] === 1 ? 'SMALL' : 'BIG';
      return null;
    },
  },
  {
    name: 'MOMENTUM_AI',
    weight: 11,
    fn(nums) {
      const last3 = nums.slice(0, 3);
      if (last3.every((n) => n >= 5)) return 'BIG';
      if (last3.every((n) => n < 5)) return 'SMALL';
      return null;
    },
  },
  {
    name: 'MEAN_REVERSION',
    weight: 10,
    fn(nums) {
      if (nums.length < 10) return null;
      const ratio = nums.slice(0, 10).filter((n) => n >= 5).length / 10;
      if (ratio > 0.7) return 'SMALL';
      if (ratio < 0.3) return 'BIG';
      return null;
    },
  },
  {
    name: 'BAYESIAN_CORE',
    weight: 10,
    fn(nums) {
      if (nums.length < 8) return null;
      const c = nums.slice(0, 8).filter((n) => n >= 5).length;
      const prob = (c + 2) / 12;
      if (prob > 0.58) return 'BIG';
      if (prob < 0.42) return 'SMALL';
      return null;
    },
  },
  {
    name: 'VOLATILITY_BREAK',
    weight: 8,
    fn(nums) {
      if (nums.length < 7) return null;
      const m = nums.slice(0, 7).reduce((a, b) => a + b, 0) / 7;
      const variance = nums.slice(0, 7).reduce((a, b) => a + (b - m) * (b - m), 0) / 7;
      if (variance > 7.5) return nums[0] >= 5 ? 'SMALL' : 'BIG';
      return null;
    },
  },
];

function evaluateBDAkashEngine(nums: number[]): { predSize: DirectionSize; color: string } {
  let bigScore = 0;
  let smallScore = 0;
  ML_LOGICS.forEach((lg) => {
    const vote = lg.fn(nums);
    if (vote === 'BIG') bigScore += lg.weight;
    else if (vote === 'SMALL') smallScore += lg.weight;
  });

  const sample12 = nums.slice(0, 12);
  const greenCount = sample12.filter((n) => n % 2 === 1).length;
  const redCount = sample12.length - greenCount;
  let color = greenCount >= redCount ? 'GREEN' : 'RED';
  if (nums[0] === 0 || nums[0] === 5) color += '-VIOLET';

  return {
    predSize: bigScore >= smallScore ? 'BIG' : 'SMALL',
    color,
  };
}

export function predictMarkovSmartNumbers(
  favSize: DirectionSize,
  nums: number[]
): { targetNum: number; pairNum: number; safe: number[] } {
  const transitions: number[][] = Array.from({ length: 10 }, () => Array<number>(10).fill(0));
  for (let i = 0; i < nums.length; i++) {
    const n = nums[i];
    if (n >= 0 && n <= 9 && i + 1 < nums.length) {
      const older = nums[i + 1];
      if (older >= 0 && older <= 9) transitions[older][n]++;
    }
  }

  const pool = favSize === 'BIG' ? SAFE_POOLS.BIG : SAFE_POOLS.SMALL;
  const oppPool = favSize === 'BIG' ? SAFE_POOLS.SMALL : SAFE_POOLS.BIG;

  const scorePool = (p: number[]) =>
    p
      .map((n) => {
        let sc = 5.0;
        sc += nums.slice(0, 15).filter((x) => x === n).length * 12;
        if (nums.length > 0) {
          const last = nums[0];
          const row = transitions[last];
          const sum = row ? row.reduce((a, b) => a + b, 0) : 0;
          if (sum > 0 && row[n] > 0) sc += (row[n] / sum) * 25;
        }
        return { num: n, score: sc };
      })
      .sort((a, b) => b.score - a.score);

  const sortedSame = scorePool(pool);
  const sortedOpp = scorePool(oppPool);

  return {
    targetNum: sortedSame[0] ? sortedSame[0].num : favSize === 'BIG' ? 7 : 2,
    pairNum: sortedOpp[0] ? sortedOpp[0].num : favSize === 'BIG' ? 2 : 7,
    safe: sortedSame.slice(0, 3).map((x) => x.num),
  };
}

export interface TitanMasterOutput {
  bigVotes: number;
  smallVotes: number;
  direction: DirectionSize;
  confidence: number;
  targetNum: number;
  pairNum: number;
  safe: number[];
  triColor: string;
  recoveryActive: boolean;
  res200: Titan200Result | null;
  formula: { found: boolean; size: DirectionSize; name: string; bestScore: number };
  rjp: { name: string; size: DirectionSize; conf: number; hash: number } | null;
  regime: { name: string; icon: string };
  oracle: { next: DirectionSize; occ: number; rate: number } | null;
  fusion: { size: DirectionSize; domName: string; domDetail: string };
  bunny: { prediction: DirectionSize; confidence: number; name: string };
}

export function runTitanMasterEngine(
  nums: number[],
  period: string,
  consecutiveLosses = 0,
  lastLossNum: number | null = null
): TitanMasterOutput {
  const types: ('B' | 'S')[] = nums.map((n) => (n >= 5 ? 'B' : 'S'));
  const latestSide: DirectionSize = types[0] === 'B' ? 'BIG' : 'SMALL';
  const oppSide: DirectionSize = latestSide === 'BIG' ? 'SMALL' : 'BIG';

  const res200 = master200Engine.predict(nums);
  const rjp = calculateRajputLogic(nums, period);
  const formula = searchBestFormula(nums, types);
  const fusion = primeFusionStrategy(nums);
  const bunny = runBunnyAndCPUEngine(nums);
  const mafiya = mafiyaAnalyze(nums);
  const bd = evaluateBDAkashEngine(nums);
  const oracle = oracleScan(nums);
  const regime = marketRegime(nums);

  let bigVotes = 0;
  let smallVotes = 0;

  if (res200) {
    bigVotes += res200.bigScore * 0.45;
    smallVotes += res200.smallScore * 0.45;
  }

  if (formula.bestScore >= 7) {
    if (formula.size === 'BIG') bigVotes += 3.5;
    else smallVotes += 3.5;
  }

  if (fusion.size === 'BIG') bigVotes += 3.8;
  else smallVotes += 3.8;

  if (bunny.prediction === 'BIG') bigVotes += bunny.confidence * 0.04;
  else smallVotes += bunny.confidence * 0.04;

  if (mafiya.prediction === 'BIG') bigVotes += 2.0;
  else smallVotes += 2.0;

  if (bd.predSize === 'BIG') bigVotes += 2.2;
  else smallVotes += 2.2;

  if (rjp) {
    if (rjp.size === 'BIG') bigVotes += 3.0;
    else smallVotes += 3.0;
  }

  if (oracle && oracle.rate >= 60) {
    if (oracle.next === 'BIG') bigVotes += 2.5;
    else smallVotes += 2.5;
  }

  const is11Jump =
    types.length >= 4 &&
    types[0] !== types[1] &&
    types[1] !== types[2] &&
    types[2] !== types[3];
  if (is11Jump) {
    if (oppSide === 'BIG') bigVotes += 4.5;
    else smallVotes += 4.5;
  }

  let curStreak = 1;
  for (let i = 1; i < types.length; i++) {
    if (types[i] === types[0]) curStreak++;
    else break;
  }

  if (curStreak >= 5) {
    if (oppSide === 'BIG') bigVotes += 4.0;
    else smallVotes += 4.0;
  } else if (curStreak >= 2 && curStreak <= 4 && !is11Jump) {
    if (latestSide === 'BIG') bigVotes += 2.0;
    else smallVotes += 2.0;
  }

  let recoveryActive = false;
  if (consecutiveLosses >= 1 && lastLossNum !== null) {
    recoveryActive = true;
    if (lastLossNum >= 5) smallVotes += 5.5;
    else bigVotes += 5.5;
  }

  const finalSize: DirectionSize = bigVotes >= smallVotes ? 'BIG' : 'SMALL';
  const voteDiff = Math.abs(bigVotes - smallVotes);
  let finalConf = Math.max(88, Math.min(98, Math.round(88 + voteDiff * 1.6)));
  if (recoveryActive) finalConf = Math.max(94, finalConf);

  const smart = predictMarkovSmartNumbers(finalSize, nums);

  return {
    bigVotes: Number(bigVotes.toFixed(1)),
    smallVotes: Number(smallVotes.toFixed(1)),
    direction: finalSize,
    confidence: finalConf,
    targetNum: smart.targetNum,
    pairNum: smart.pairNum,
    safe: smart.safe,
    triColor: bd.color,
    recoveryActive,
    res200,
    formula,
    rjp,
    regime,
    oracle,
    fusion,
    bunny,
  };
}

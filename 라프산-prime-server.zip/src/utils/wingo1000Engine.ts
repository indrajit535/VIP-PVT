export interface WinGo1000Entry {
  num: number;
  size: 'Big' | 'Small';
  pureColor: 'Red' | 'Green';
  parity: 'Even' | 'Odd';
  isViolet: boolean;
}

export interface WinGo1000TriggeredRule {
  id: number;
  name: string;
  vote: 'Big' | 'Small';
  weight: number;
}

interface RuleDef {
  id: number;
  name: string;
  fn: (e: WinGo1000Entry[]) => { vote: 'Big' | 'Small'; weight: number } | null;
}

export interface WinGo1000Result {
  prediction: 'BIG' | 'SMALL' | 'NEUTRAL';
  confidence: number;
  bigScore: number;
  smallScore: number;
  totalRulesTriggered: number;
  triggeredRules: WinGo1000TriggeredRule[];
}

export class WinGo1000Engine {
  public readonly rules: RuleDef[] = [];

  constructor() {
    this._initRules1To200();
    this._initRules201To1000();
  }

  private _opp(val: string): string {
    if (val === 'Big') return 'Small';
    if (val === 'Small') return 'Big';
    if (val === 'Red') return 'Green';
    if (val === 'Green') return 'Red';
    if (val === 'Even') return 'Odd';
    if (val === 'Odd') return 'Even';
    return val;
  }

  private _oppSize(val: 'Big' | 'Small'): 'Big' | 'Small' {
    return val === 'Big' ? 'Small' : 'Big';
  }

  private _streak(list: WinGo1000Entry[], key: 'size' | 'pureColor' | 'parity'): number {
    if (!list || list.length === 0 || !list[0]) return 0;
    const target = list[0][key];
    let count = 0;
    for (let i = 0; i < list.length; i++) {
      if (list[i] && list[i][key] === target) count++;
      else break;
    }
    return count;
  }

  private _jumping(list: WinGo1000Entry[], key: 'size' | 'pureColor' | 'parity', len: number): boolean {
    if (!list || list.length < len) return false;
    for (let i = 0; i < len - 1; i++) {
      if (!list[i] || !list[i + 1] || list[i][key] === list[i + 1][key]) {
        return false;
      }
    }
    return true;
  }

  private _mirror(list: WinGo1000Entry[], key: 'size' | 'pureColor' | 'parity', len: number): boolean {
    if (!list || list.length < len) return false;
    for (let i = 0; i < Math.floor(len / 2); i++) {
      if (!list[i] || !list[len - 1 - i] || list[i][key] !== list[len - 1 - i][key]) {
        return false;
      }
    }
    return true;
  }

  private _matchSeq(list: WinGo1000Entry[], key: 'size' | 'pureColor' | 'parity', seq: string[]): boolean {
    if (!list || list.length < seq.length) return false;
    for (let i = 0; i < seq.length; i++) {
      if (!list[i] || list[i][key] !== seq[i]) return false;
    }
    return true;
  }

  private _initRules1To200(): void {
    const r: RuleDef[] = [
      { id: 1, name: 'Dragon', fn: (e) => (this._streak(e, 'size') >= 4 ? { vote: e[0].size, weight: 3.5 } : null) },
      { id: 2, name: 'Mirror', fn: (e) => (this._mirror(e, 'size', 3) ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 3, name: 'Jumping', fn: (e) => (this._jumping(e, 'size', 3) ? { vote: this._oppSize(e[0].size), weight: 3.8 } : null) },
      { id: 4, name: 'Staircase', fn: (e) => (e[0] && e[1] && e[2] && e[0].num > e[1].num && e[1].num > e[2].num ? { vote: 'Big', weight: 2.8 } : e[0] && e[1] && e[2] && e[0].num < e[1].num && e[1].num < e[2].num ? { vote: 'Small', weight: 2.8 } : null) },
      { id: 5, name: 'Zigzag', fn: (e) => (this._jumping(e, 'size', 4) ? { vote: this._oppSize(e[0].size), weight: 4 } : null) },
      { id: 6, name: 'Double Dragon', fn: (e) => (this._streak(e, 'size') >= 4 && this._streak(e, 'pureColor') >= 4 ? { vote: e[0].size, weight: 4.5 } : null) },
      { id: 7, name: 'Triple Dragon', fn: (e) => (this._streak(e, 'size') >= 3 && this._streak(e, 'pureColor') >= 3 && this._streak(e, 'parity') >= 3 ? { vote: e[0].size, weight: 4.8 } : null) },
      { id: 8, name: 'Mega Dragon', fn: (e) => (this._streak(e, 'size') >= 7 ? { vote: this._oppSize(e[0].size), weight: 4.5 } : null) },
      { id: 9, name: 'Super Dragon', fn: (e) => (this._streak(e, 'size') >= 9 ? { vote: this._oppSize(e[0].size), weight: 5 } : null) },
      { id: 10, name: 'Mini Dragon', fn: (e) => (this._streak(e, 'size') === 3 ? { vote: e[0].size, weight: 2.6 } : null) },
      { id: 11, name: 'Color Dragon', fn: (e) => (this._streak(e, 'pureColor') >= 5 ? { vote: e[0].size, weight: 2.5 } : null) },
      { id: 12, name: 'Big Dragon', fn: (e) => (e[0].size === 'Big' && this._streak(e, 'size') >= 4 && this._streak(e, 'size') < 7 ? { vote: 'Big', weight: 3.8 } : null) },
      { id: 13, name: 'Small Dragon', fn: (e) => (e[0].size === 'Small' && this._streak(e, 'size') >= 4 && this._streak(e, 'size') < 7 ? { vote: 'Small', weight: 3.8 } : null) },
      { id: 14, name: 'Violet Dragon', fn: (e) => (e[0] && e[1] && e[0].isViolet && e[1].isViolet ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 15, name: 'Red Dragon', fn: (e) => (e[0].pureColor === 'Red' && this._streak(e, 'pureColor') >= 4 ? { vote: e[0].size, weight: 2.5 } : null) },
      { id: 16, name: 'Green Dragon', fn: (e) => (e[0].pureColor === 'Green' && this._streak(e, 'pureColor') >= 4 ? { vote: e[0].size, weight: 2.5 } : null) },
      { id: 17, name: 'Alternating', fn: (e) => (this._jumping(e, 'size', 3) ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 18, name: '1-1 Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Big', 'Small', 'Big']) ? { vote: 'Small', weight: 4 } : this._matchSeq(e, 'size', ['Small', 'Big', 'Small']) ? { vote: 'Big', weight: 4 } : null) },
      { id: 19, name: '2-2 Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Big', 'Small', 'Small']) ? { vote: 'Big', weight: 3.6 } : this._matchSeq(e, 'size', ['Small', 'Big', 'Big']) ? { vote: 'Small', weight: 3.6 } : null) },
      { id: 20, name: '3-3 Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Big', 'Big', 'Small', 'Small', 'Small']) ? { vote: 'Big', weight: 4.2 } : this._matchSeq(e, 'size', ['Small', 'Small', 'Big', 'Big', 'Big']) ? { vote: 'Small', weight: 4.2 } : null) },
      { id: 21, name: '2-1 Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Big', 'Small', 'Small']) ? { vote: 'Big', weight: 3.2 } : this._matchSeq(e, 'size', ['Small', 'Big', 'Big']) ? { vote: 'Small', weight: 3.2 } : null) },
      { id: 22, name: '1-2 Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Small', 'Small', 'Big']) ? { vote: 'Small', weight: 3.2 } : this._matchSeq(e, 'size', ['Big', 'Big', 'Small']) ? { vote: 'Big', weight: 3.2 } : null) },
      { id: 23, name: '3-2-1 Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Small', 'Big', 'Big', 'Small', 'Small', 'Small']) ? { vote: 'Big', weight: 4 } : null) },
      { id: 24, name: '1-2-3 Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Big', 'Big', 'Big', 'Small', 'Small', 'Big']) ? { vote: 'Small', weight: 4 } : null) },
      { id: 25, name: 'Double Mirror', fn: (e) => (this._mirror(e, 'size', 4) ? { vote: this._oppSize(e[0].size), weight: 3.4 } : null) },
      { id: 26, name: 'Triple Mirror', fn: (e) => (this._mirror(e, 'size', 6) ? { vote: this._oppSize(e[0].size), weight: 3.8 } : null) },
      { id: 27, name: 'Symmetrical', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size === e[3].size && e[1].size === e[2].size && e[0].size !== e[1].size ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 28, name: 'Reverse Mirror', fn: (e) => (e.length >= 4 && e[0] && e[1] && e[2] && e[3] && e[0].size !== e[3].size && e[1].size !== e[2].size ? { vote: e[0].size, weight: 2.4 } : null) },
      { id: 29, name: 'Half Mirror', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === e[2].size && e[1].size !== e[0].size ? { vote: e[1].size, weight: 3.1 } : null) },
      { id: 30, name: 'Full Mirror', fn: (e) => (this._mirror(e, 'size', 5) ? { vote: this._oppSize(e[0].size), weight: 4 } : null) },
      { id: 31, name: 'Jumping Red', fn: (e) => (e[0] && e[1] && e[2] && e[0].pureColor === 'Red' && e[1].pureColor === 'Green' && e[2].pureColor === 'Red' ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 32, name: 'Jumping Green', fn: (e) => (e[0] && e[1] && e[2] && e[0].pureColor === 'Green' && e[1].pureColor === 'Red' && e[2].pureColor === 'Green' ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 33, name: 'Jumping Violet', fn: (e) => (e[0] && e[1] && e[2] && !e[0].isViolet && e[1].isViolet && !e[2].isViolet ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null) },
      { id: 34, name: 'Color Jump', fn: (e) => (e[0] && e[1] && e[2] && e[0].pureColor !== e[1].pureColor && e[1].pureColor !== e[2].pureColor ? { vote: this._oppSize(e[0].size), weight: 2.7 } : null) },
      { id: 35, name: 'Big Jump', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === 'Big' && e[1].size === 'Small' && e[2].size === 'Big' ? { vote: 'Small', weight: 3.5 } : null) },
      { id: 36, name: 'Small Jump', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === 'Small' && e[1].size === 'Big' && e[2].size === 'Small' ? { vote: 'Big', weight: 3.5 } : null) },
      { id: 37, name: 'Staircase Up', fn: (e) => (e[0] && e[1] && e[2] && e[0].num > e[1].num && e[1].num > e[2].num ? { vote: 'Big', weight: 2.9 } : null) },
      { id: 38, name: 'Staircase Down', fn: (e) => (e[0] && e[1] && e[2] && e[0].num < e[1].num && e[1].num < e[2].num ? { vote: 'Small', weight: 2.9 } : null) },
      { id: 39, name: 'Big Staircase', fn: (e) => (e[0] && e[1] && e[0].size === 'Big' && e[1].size === 'Big' && e[0].num > e[1].num ? { vote: 'Big', weight: 2.8 } : null) },
      { id: 40, name: 'Small Staircase', fn: (e) => (e[0] && e[1] && e[0].size === 'Small' && e[1].size === 'Small' && e[0].num < e[1].num ? { vote: 'Small', weight: 2.8 } : null) },
      { id: 41, name: 'Color Staircase', fn: (e) => (e[0] && e[1] && e[2] && e[0].pureColor === e[1].pureColor && e[0].num > e[1].num && e[1].num > e[2].num ? { vote: 'Big', weight: 2.5 } : null) },
      { id: 42, name: 'Number Staircase', fn: (e) => (e[0] && e[1] && e[2] && Math.abs(e[0].num - e[1].num) === 1 && Math.abs(e[1].num - e[2].num) === 1 ? { vote: e[0].num > e[1].num ? 'Big' : 'Small', weight: 2.8 } : null) },
      { id: 43, name: 'Continuous Red', fn: (e) => (this._streak(e, 'pureColor') >= 3 && e[0].pureColor === 'Red' ? { vote: e[0].size, weight: 2.4 } : null) },
      { id: 44, name: 'Continuous Green', fn: (e) => (this._streak(e, 'pureColor') >= 3 && e[0].pureColor === 'Green' ? { vote: e[0].size, weight: 2.4 } : null) },
      { id: 45, name: 'Continuous Big', fn: (e) => (this._streak(e, 'size') >= 3 && e[0].size === 'Big' && this._streak(e, 'size') < 6 ? { vote: 'Big', weight: 3.2 } : null) },
      { id: 46, name: 'Continuous Small', fn: (e) => (this._streak(e, 'size') >= 3 && e[0].size === 'Small' && this._streak(e, 'size') < 6 ? { vote: 'Small', weight: 3.2 } : null) },
      { id: 47, name: 'Continuous Violet', fn: (e) => (e[0] && e[1] && e[0].isViolet && e[1].isViolet ? { vote: this._oppSize(e[0].size), weight: 2.9 } : null) },
      { id: 48, name: 'Break Pattern', fn: (e) => (e.length >= 2 && this._streak(e.slice(1), 'size') >= 4 && e[0].size !== e[1].size ? { vote: e[0].size, weight: 3.6 } : null) },
      { id: 49, name: 'Reversal', fn: (e) => (this._streak(e, 'size') >= 5 ? { vote: this._oppSize(e[0].size), weight: 4 } : null) },
      { id: 50, name: 'Mean Reversion', fn: (e) => { if (e.length < 10) return null; const t = e.slice(0, 10).reduce((a, b) => a + b.num, 0) / 10; return t >= 5.8 ? { vote: 'Small', weight: 3.4 } : t <= 3.2 ? { vote: 'Big', weight: 3.4 } : null; } },
      { id: 51, name: 'Hot Streak', fn: (e) => (this._streak(e, 'size') >= 3 && this._streak(e, 'size') <= 5 ? { vote: e[0].size, weight: 2.8 } : null) },
      { id: 52, name: 'Cold Streak', fn: (e) => (this._streak(e, 'size') >= 6 ? { vote: this._oppSize(e[0].size), weight: 3.8 } : null) },
      { id: 53, name: 'Momentum', fn: (e) => (e[0] && e[1] && e[0].num >= 7 && e[1].num >= 6 ? { vote: 'Big', weight: 3 } : e[0] && e[1] && e[0].num <= 2 && e[1].num <= 3 ? { vote: 'Small', weight: 3 } : null) },
      { id: 54, name: 'Trend Follow', fn: (e) => { if (e.length < 10) return null; const t = e.slice(0, 10).filter((x) => x.size === 'Big').length; return t >= 7 && this._streak(e, 'size') < 5 ? { vote: 'Big', weight: 3.3 } : t <= 3 && this._streak(e, 'size') < 5 ? { vote: 'Small', weight: 3.3 } : null; } },
      { id: 55, name: 'Counter Trend', fn: (e) => { if (e.length < 10) return null; const t = e.slice(0, 10).filter((x) => x.size === 'Big').length; return t >= 8 ? { vote: 'Small', weight: 3.8 } : t <= 2 ? { vote: 'Big', weight: 3.8 } : null; } },
      { id: 56, name: 'Pair Pattern', fn: (e) => (e[0] && e[1] && e[0].num === e[1].num ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 57, name: 'Triple Pair', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size === e[1].size && e[2].size === e[3].size && e[0].size !== e[2].size ? { vote: e[0].size, weight: 3.4 } : null) },
      { id: 58, name: 'Quad Pattern', fn: (e) => (this._streak(e, 'size') === 4 ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 59, name: 'Cycle Pattern', fn: (e) => (e[0] && e[1] && e[3] && e[4] && e[0].size === e[3].size && e[1].size === e[4].size && e[2] ? { vote: e[2].size, weight: 3 } : null) },
      { id: 60, name: 'Loop Pattern', fn: (e) => (e[0] && e[1] && e[4] && e[5] && e[0].size === e[4].size && e[1].size === e[5].size && e[2] ? { vote: e[2].size, weight: 2.8 } : null) },
      { id: 61, name: 'Wave Pattern', fn: (e) => (e[0] && e[1] && e[2] && e[0].num > e[1].num && e[1].num < e[2].num ? { vote: 'Small', weight: 2.6 } : e[0] && e[1] && e[2] && e[0].num < e[1].num && e[1].num > e[2].num ? { vote: 'Big', weight: 2.6 } : null) },
      { id: 62, name: 'Spike Pattern', fn: (e) => (e[0] && e[1] && Math.abs(e[0].num - e[1].num) >= 6 ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 63, name: 'Cluster', fn: (e) => (e.length >= 4 && e.slice(0, 4).every((x) => x.num >= 4 && x.num <= 6) ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 64, name: 'Color Cluster', fn: (e) => (e.length >= 5 && e.slice(0, 5).filter((x) => x.pureColor === 'Red').length >= 4 ? { vote: 'Small', weight: 2.6 } : null) },
      { id: 65, name: 'Number Cluster', fn: (e) => (e[0] && e[1] && Math.abs(e[0].num - e[1].num) <= 1 ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null) },
      { id: 66, name: 'Big Cluster', fn: (e) => (e.length >= 6 && e.slice(0, 6).filter((x) => x.size === 'Big').length >= 5 ? { vote: 'Small', weight: 3.4 } : null) },
      { id: 67, name: 'Small Cluster', fn: (e) => (e.length >= 6 && e.slice(0, 6).filter((x) => x.size === 'Small').length >= 5 ? { vote: 'Big', weight: 3.4 } : null) },
      { id: 68, name: 'Violet Cluster', fn: (e) => (e.length >= 6 && e.slice(0, 6).filter((x) => x.isViolet).length >= 2 ? { vote: this._oppSize(e[0].size), weight: 2.7 } : null) },
      { id: 69, name: 'Odd Even', fn: (e) => (e[0] && e[1] && e[2] && e[0].parity === 'Odd' && e[1].parity === 'Even' && e[2].parity === 'Odd' ? { vote: 'Big', weight: 2.5 } : null) },
      { id: 70, name: 'Even Odd', fn: (e) => (e[0] && e[1] && e[2] && e[0].parity === 'Even' && e[1].parity === 'Odd' && e[2].parity === 'Even' ? { vote: 'Small', weight: 2.5 } : null) },
      { id: 71, name: 'Parity Shift', fn: (e) => (e[0] && e[1] && e[2] && e[0].parity !== e[1].parity && e[1].parity !== e[2].parity ? { vote: this._oppSize(e[0].size), weight: 2.4 } : null) },
      { id: 72, name: 'Color Shift', fn: (e) => (e[0] && e[1] && e[2] && e[0].pureColor !== e[1].pureColor && e[1].pureColor !== e[2].pureColor ? { vote: this._oppSize(e[0].size), weight: 2.6 } : null) },
      { id: 73, name: 'Size Shift', fn: (e) => (e[0] && e[1] && e[2] && e[0].size !== e[1].size && e[1].size === e[2].size ? { vote: e[0].size, weight: 2.8 } : null) },
      { id: 74, name: 'Dual Color', fn: (e) => (e[0].isViolet ? { vote: this._oppSize(e[0].size), weight: 2.9 } : null) },
      { id: 75, name: 'Split Pattern', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size !== e[1].size && e[1].size === e[2].size && e[2].size === e[3].size ? { vote: e[0].size, weight: 3 } : null) },
      { id: 76, name: 'Hybrid', fn: (e) => (e[0] && e[1] && e[0].pureColor === 'Red' && e[0].size === 'Big' && e[1].pureColor === 'Green' && e[1].size === 'Small' ? { vote: 'Big', weight: 3 } : null) },
      { id: 77, name: 'Boundary', fn: (e) => (e[0].num === 0 || e[0].num === 9 ? { vote: e[0].num === 0 ? 'Big' : 'Small', weight: 3.6 } : null) },
      { id: 78, name: 'Edge Pattern', fn: (e) => (e[0].num <= 1 || e[0].num >= 8 ? { vote: e[0].num <= 1 ? 'Big' : 'Small', weight: 3.2 } : null) },
      { id: 79, name: 'Core Pattern', fn: (e) => (e[0].num >= 4 && e[0].num <= 5 ? { vote: e[0].num === 4 ? 'Big' : 'Small', weight: 2.7 } : null) },
      { id: 80, name: 'Balance', fn: (e) => (e.length < 10 ? null : e.slice(0, 10).filter((x) => x.size === 'Big').length === 5 ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 81, name: 'Imbalance', fn: (e) => { if (e.length < 8) return null; const t = e.slice(0, 8).filter((x) => x.size === 'Big').length; return t >= 6 ? { vote: 'Small', weight: 3.8 } : t <= 2 ? { vote: 'Big', weight: 3.8 } : null; } },
      { id: 82, name: 'Overload', fn: (e) => (this._streak(e, 'size') >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.6 } : null) },
      { id: 83, name: 'Underload', fn: (e) => { if (e.length < 10) return null; const t = e.slice(0, 10).filter((x) => x.size === 'Big').length; return t <= 3 ? { vote: 'Big', weight: 3.4 } : t >= 7 ? { vote: 'Small', weight: 3.4 } : null; } },
      { id: 84, name: 'Frequency High', fn: (e) => { if (e.length < 15) return null; const t = e.slice(0, 15).filter((x) => x.size === 'Big').length; return t >= 11 ? { vote: 'Small', weight: 3.5 } : t <= 4 ? { vote: 'Big', weight: 3.5 } : null; } },
      { id: 85, name: 'Frequency Low', fn: (e) => (e.length < 15 ? null : e.slice(0, 15).filter((x) => x.size === 'Big').length <= 4 ? { vote: 'Big', weight: 3.5 } : null) },
      { id: 86, name: 'Missing Pattern', fn: (e) => (e.length < 5 || e.slice(0, 5).some((x) => x.size === 'Big') ? null : { vote: 'Big', weight: 4.2 }) },
      { id: 87, name: 'Due Pattern', fn: (e) => (e.length < 5 || e.slice(0, 5).some((x) => x.size === 'Small') ? null : { vote: 'Small', weight: 4.2 }) },
      { id: 88, name: 'Overdue', fn: (e) => (this._streak(e, 'size') >= 6 ? { vote: this._oppSize(e[0].size), weight: 4 } : null) },
      { id: 89, name: 'Repeat', fn: (e) => (e[0] && e[1] && e[0].size === e[1].size && this._streak(e, 'size') === 2 ? { vote: e[0].size, weight: 2.2 } : null) },
      { id: 90, name: 'Non Repeat', fn: (e) => (e[0] && e[1] && e[2] && e[0].size !== e[1].size && e[1].size !== e[2].size ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 91, name: 'Single Repeat', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === e[1].size && e[1].size !== e[2].size ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 92, name: 'Double Repeat', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size === e[1].size && e[2].size === e[3].size && e[0].size !== e[2].size ? { vote: this._oppSize(e[0].size), weight: 3.3 } : null) },
      { id: 93, name: 'Triple Repeat', fn: (e) => (this._streak(e, 'size') === 3 ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 94, name: 'Chain', fn: (e) => (this._streak(e, 'size') >= 3 && this._streak(e, 'size') < 6 ? { vote: e[0].size, weight: 2.9 } : null) },
      { id: 95, name: 'Color Chain', fn: (e) => (this._streak(e, 'pureColor') >= 4 && this._streak(e, 'pureColor') < 7 ? { vote: e[0].size, weight: 2.5 } : null) },
      { id: 96, name: 'Size Chain', fn: (e) => (this._streak(e, 'size') >= 4 && this._streak(e, 'size') < 6 ? { vote: e[0].size, weight: 3.2 } : null) },
      { id: 97, name: 'Number Chain', fn: (e) => (e[0] && e[1] && Math.abs(e[0].num - e[1].num) === 1 ? { vote: e[0].num > e[1].num ? 'Big' : 'Small', weight: 2.6 } : null) },
      { id: 98, name: 'Break Chain', fn: (e) => (this._streak(e, 'size') >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.6 } : null) },
      { id: 99, name: 'Link Pattern', fn: (e) => (e[0] && e[1] && e[2] && e[0].num === e[2].num ? { vote: this._oppSize(e[1].size), weight: 2.9 } : null) },
      { id: 100, name: 'Bridge', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === e[2].size && e[1].size !== e[0].size ? { vote: e[0].size, weight: 3.3 } : null) },
      { id: 101, name: 'Peak', fn: (e) => (e[0] && e[1] && e[2] && e[1].num > e[0].num && e[1].num > e[2].num ? { vote: 'Small', weight: 2.8 } : null) },
      { id: 102, name: 'Valley', fn: (e) => (e[0] && e[1] && e[2] && e[1].num < e[0].num && e[1].num < e[2].num ? { vote: 'Big', weight: 2.8 } : null) },
      { id: 103, name: 'Peak Valley', fn: (e) => (e[0] && e[1] && e[0].num >= 8 && e[1].num <= 1 ? { vote: 'Small', weight: 3 } : null) },
      { id: 104, name: 'Rise', fn: (e) => (e[0] && e[1] && e[2] && e[0].num > e[1].num && e[1].num > e[2].num ? { vote: 'Big', weight: 2.5 } : null) },
      { id: 105, name: 'Fall', fn: (e) => (e[0] && e[1] && e[2] && e[0].num < e[1].num && e[1].num < e[2].num ? { vote: 'Small', weight: 2.5 } : null) },
      { id: 106, name: 'Rise Fall', fn: (e) => (e[0] && e[1] && e[2] && e[0].num < e[1].num && e[1].num > e[2].num ? { vote: 'Small', weight: 2.6 } : null) },
      { id: 107, name: 'Flat', fn: (e) => (e[0] && e[1] && e[0].num === e[1].num ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 108, name: 'Steady', fn: (e) => (e[0] && e[1] && e[2] && Math.abs(e[0].num - e[1].num) <= 2 && Math.abs(e[1].num - e[2].num) <= 2 ? { vote: e[0].size, weight: 2.4 } : null) },
      { id: 109, name: 'Volatile', fn: (e) => (e[0] && e[1] && e[2] && Math.abs(e[0].num - e[1].num) >= 5 && Math.abs(e[1].num - e[2].num) >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.4 } : null) },
      { id: 110, name: 'Calm', fn: (e) => (e[0] && e[1] && Math.abs(e[0].num - e[1].num) <= 1 ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null) },
      { id: 111, name: 'Storm', fn: (e) => (e[0] && e[1] && e[2] && Math.abs(e[0].num - e[1].num) >= 5 && Math.abs(e[1].num - e[2].num) >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.6 } : null) },
      { id: 112, name: 'Quiet', fn: (e) => (e[0] && e[1] && e[0].num >= 4 && e[0].num <= 5 && e[1].num >= 4 && e[1].num <= 5 ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 113, name: 'Burst', fn: (e) => (e[0].num === 9 || e[0].num === 0 ? { vote: e[0].num === 9 ? 'Small' : 'Big', weight: 3.5 } : null) },
      { id: 114, name: 'Explosion', fn: (e) => (e[0] && e[1] && e[0].num === 0 && e[1].num === 9 ? { vote: 'Small', weight: 4 } : null) },
      { id: 115, name: 'Fade', fn: (e) => (e[0] && e[1] && e[0].num === 5 && e[1].num === 4 ? { vote: 'Small', weight: 2.8 } : null) },
      { id: 116, name: 'Strong', fn: (e) => (this._streak(e, 'size') >= 4 && this._streak(e, 'size') < 6 ? { vote: e[0].size, weight: 3.2 } : null) },
      { id: 117, name: 'Weak', fn: (e) => (e[1] && e[2] && this._streak(e, 'size') === 1 && e[1].size !== e[2].size ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 118, name: 'Dominant', fn: (e) => (e.length >= 10 && e.slice(0, 10).filter((x) => x.size === 'Big').length >= 8 ? { vote: 'Small', weight: 3.6 } : null) },
      { id: 119, name: 'Recessive', fn: (e) => (e.length >= 10 && e.slice(0, 10).filter((x) => x.size === 'Small').length >= 8 ? { vote: 'Big', weight: 3.6 } : null) },
      { id: 120, name: 'Leader', fn: (e) => (e.length >= 8 && e.slice(0, 8).filter((t) => t.size === e[0].size).length >= 6 && this._streak(e, 'size') < 5 ? { vote: e[0].size, weight: 2.7 } : null) },
      { id: 121, name: 'Follower', fn: (e) => (e[1] && e[2] && this._streak(e, 'size') === 2 && e[2].size !== e[1].size ? { vote: e[0].size, weight: 2.4 } : null) },
      { id: 122, name: 'Switch', fn: (e) => (this._streak(e, 'size') >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.4 } : null) },
      { id: 123, name: 'Flip', fn: (e) => (this._jumping(e, 'size', 3) ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 124, name: 'Flip Flop', fn: (e) => (e[0] && e[1] && e[2] && e[0].size !== e[1].size && e[1].size !== e[2].size ? { vote: this._oppSize(e[0].size), weight: 3.5 } : null) },
      { id: 125, name: 'Toggle', fn: (e) => (e[0] && e[1] && e[2] && e[0].size !== e[1].size && e[1].size === e[2].size ? { vote: e[0].size, weight: 2.8 } : null) },
      { id: 126, name: 'Oscillate', fn: (e) => (this._jumping(e, 'size', 3) ? { vote: this._oppSize(e[0].size), weight: 3.4 } : null) },
      { id: 127, name: 'Swing', fn: (e) => (e[0] && e[1] && Math.abs(e[0].num - e[1].num) >= 5 ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 128, name: 'Pendulum', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === e[2].size && e[1].size !== e[0].size ? { vote: e[0].size, weight: 3.2 } : null) },
      { id: 129, name: 'Bounce', fn: (e) => (e[0].num === 0 || e[0].num === 9 ? { vote: e[0].num === 0 ? 'Big' : 'Small', weight: 3.4 } : null) },
      { id: 130, name: 'Rebound', fn: (e) => (e[0] && e[1] && e[2] && e[0].size !== e[1].size && e[1].size === e[2].size ? { vote: e[0].size, weight: 2.9 } : null) },
      { id: 131, name: 'Echo', fn: (e) => (e[0] && e[1] && e[2] && e[0].num === e[2].num && e[0].size !== e[1].size ? { vote: e[1].size, weight: 2.9 } : null) },
      { id: 132, name: 'Shadow', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size === e[2].size && e[1].size === e[3].size ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 133, name: 'Ghost', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size === e[3].size && e[1].size === e[2].size ? { vote: this._oppSize(e[0].size), weight: 3.1 } : null) },
      { id: 134, name: 'Phantom', fn: (e) => (e[0] && e[3] && e[0].num === e[3].num ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 135, name: 'Twin', fn: (e) => (e[0] && e[1] && e[0].num === e[1].num ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 136, name: 'Clone', fn: (e) => (e[0] && e[1] && e[0].num === e[1].num ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 137, name: 'Copy', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size === e[2].size && e[1].size === e[3].size ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 138, name: 'Match', fn: (e) => (e[0] && e[1] && e[0].size === e[1].size && this._streak(e, 'size') === 2 ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null) },
      { id: 139, name: 'Mismatch', fn: (e) => (e[0] && e[1] && e[0].size !== e[1].size ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 140, name: 'Sync', fn: (e) => (e[0] && e[1] && e[0].size === 'Big' && e[0].parity === 'Odd' && e[1].size === 'Small' && e[1].parity === 'Even' ? { vote: 'Big', weight: 3.1 } : null) },
      { id: 141, name: 'Desync', fn: (e) => (e[0] && e[1] && e[0].size === 'Small' && e[0].parity === 'Even' && e[1].size === 'Big' && e[1].parity === 'Odd' ? { vote: 'Small', weight: 3.1 } : null) },
      { id: 142, name: 'Phase', fn: (e) => (this._matchSeq(e, 'size', ['Big', 'Small']) ? { vote: 'Big', weight: 2.8 } : null) },
      { id: 143, name: 'Phase Shift', fn: (e) => (e[1] && e[2] && this._streak(e, 'size') === 2 && e[2].size !== e[1].size ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 144, name: 'Cycle 2', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size === e[2].size && e[1].size === e[3].size ? { vote: this._oppSize(e[0].size), weight: 3.3 } : null) },
      { id: 145, name: 'Cycle 3', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[4] && e[5] && e[0].size === e[3].size && e[1].size === e[4].size && e[2].size === e[5].size ? { vote: e[0].size, weight: 3.4 } : null) },
      { id: 146, name: 'Cycle 4', fn: (e) => (e[0] && e[1] && e[4] && e[5] && e[0].size === e[4].size && e[1].size === e[5].size ? { vote: e[1].size, weight: 3.3 } : null) },
      { id: 147, name: 'Cycle 5', fn: (e) => (e[0] && e[1] && e[5] && e[6] && e[0].size === e[5].size && e[1].size === e[6].size ? { vote: e[1].size, weight: 3 } : null) },
      { id: 148, name: 'Short Cycle', fn: (e) => (this._jumping(e, 'size', 3) ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 149, name: 'Long Cycle', fn: (e) => (this._streak(e, 'size') >= 6 ? { vote: this._oppSize(e[0].size), weight: 4 } : null) },
      { id: 150, name: 'Micro Pattern', fn: (e) => (e[0].num === 0 ? { vote: 'Big', weight: 3.2 } : e[0].num === 9 ? { vote: 'Small', weight: 3.2 } : null) },
      { id: 151, name: 'Macro Pattern', fn: (e) => { if (e.length < 20) return null; const t = e.slice(0, 20).filter((x) => x.size === 'Big').length; return t >= 14 ? { vote: 'Small', weight: 4.2 } : t <= 6 ? { vote: 'Big', weight: 4.2 } : null; } },
      { id: 152, name: 'Mini Wave', fn: (e) => (e[0] && e[1] && e[2] && e[0].num > e[1].num && e[1].num < e[2].num ? { vote: 'Small', weight: 2.6 } : null) },
      { id: 153, name: 'Mega Wave', fn: (e) => (e[0] && e[1] && e[2] && Math.abs(e[0].num - e[1].num) >= 5 && Math.abs(e[1].num - e[2].num) >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.5 } : null) },
      { id: 154, name: 'Soft Trend', fn: (e) => (this._streak(e, 'size') === 2 ? { vote: e[0].size, weight: 2.2 } : null) },
      { id: 155, name: 'Hard Trend', fn: (e) => (this._streak(e, 'size') >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.8 } : null) },
      { id: 156, name: 'Soft Dragon', fn: (e) => (this._streak(e, 'size') === 3 ? { vote: e[0].size, weight: 2.8 } : null) },
      { id: 157, name: 'Hard Dragon', fn: (e) => (this._streak(e, 'size') >= 6 ? { vote: this._oppSize(e[0].size), weight: 4.2 } : null) },
      { id: 158, name: 'Soft Mirror', fn: (e) => (this._mirror(e, 'size', 2) ? { vote: this._oppSize(e[0].size), weight: 2.6 } : null) },
      { id: 159, name: 'Hard Mirror', fn: (e) => (this._mirror(e, 'size', 4) ? { vote: this._oppSize(e[0].size), weight: 4 } : null) },
      { id: 160, name: 'Soft Jump', fn: (e) => (e[0] && e[1] && e[2] && e[0].size !== e[1].size && e[1].size !== e[2].size ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 161, name: 'Hard Jump', fn: (e) => (this._jumping(e, 'size', 4) ? { vote: this._oppSize(e[0].size), weight: 4.2 } : null) },
      { id: 162, name: 'Soft Stair', fn: (e) => (e[0] && e[1] && e[2] && e[0].num > e[1].num && e[1].num > e[2].num ? { vote: 'Big', weight: 2.6 } : null) },
      { id: 163, name: 'Hard Stair', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].num > e[1].num && e[1].num > e[2].num && e[2].num > e[3].num ? { vote: 'Big', weight: 3.8 } : null) },
      { id: 164, name: 'Red Green', fn: (e) => (e[0] && e[1] && e[0].pureColor === 'Green' && e[1].pureColor === 'Red' ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null) },
      { id: 165, name: 'Green Red', fn: (e) => (e[0] && e[1] && e[0].pureColor === 'Red' && e[1].pureColor === 'Green' ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null) },
      { id: 166, name: 'Red Violet', fn: (e) => (e[0].num === 0 ? { vote: 'Big', weight: 3.4 } : null) },
      { id: 167, name: 'Green Violet', fn: (e) => (e[0].num === 5 ? { vote: 'Small', weight: 3.4 } : null) },
      { id: 168, name: 'Violet Red', fn: (e) => (e[1] && e[1].num === 0 && e[0].pureColor === 'Red' ? { vote: 'Big', weight: 3 } : null) },
      { id: 169, name: 'Violet Green', fn: (e) => (e[1] && e[1].num === 5 && e[0].pureColor === 'Green' ? { vote: 'Small', weight: 3 } : null) },
      { id: 170, name: 'Big Small', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === 'Small' && e[1].size === 'Big' && e[2].size === 'Small' ? { vote: 'Big', weight: 3.5 } : null) },
      { id: 171, name: 'Small Big', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === 'Big' && e[1].size === 'Small' && e[2].size === 'Big' ? { vote: 'Small', weight: 3.5 } : null) },
      { id: 172, name: 'Big Big', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === 'Big' && e[1].size === 'Big' && e[2].size === 'Small' ? { vote: 'Small', weight: 3.2 } : null) },
      { id: 173, name: 'Small Small', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === 'Small' && e[1].size === 'Small' && e[2].size === 'Big' ? { vote: 'Big', weight: 3.2 } : null) },
      { id: 174, name: 'Mixed Size', fn: (e) => (e[0] && e[1] && e[2] && e[0].size !== e[1].size && e[1].size !== e[2].size ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 175, name: 'Pure Color', fn: (e) => (e[0] && e[1] && !e[0].isViolet && !e[1].isViolet && e[0].pureColor !== e[1].pureColor ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null) },
      { id: 176, name: 'Mixed Color', fn: (e) => (e[0] && e[1] && e[0].isViolet !== e[1].isViolet ? { vote: this._oppSize(e[0].size), weight: 2.6 } : null) },
      { id: 177, name: 'Number Hot', fn: (e) => (e[0] && e[1] && e[0].num >= 8 && e[1].num >= 7 ? { vote: 'Small', weight: 3.2 } : null) },
      { id: 178, name: 'Number Cold', fn: (e) => (e[0] && e[1] && e[0].num <= 1 && e[1].num <= 2 ? { vote: 'Big', weight: 3.2 } : null) },
      { id: 179, name: 'Digit Run', fn: (e) => (e[0] && e[1] && e[2] && Math.abs(e[0].num - e[1].num) <= 1 && Math.abs(e[1].num - e[2].num) <= 1 ? { vote: this._oppSize(e[0].size), weight: 2.8 } : null) },
      { id: 180, name: 'Digit Break', fn: (e) => (e[0] && e[1] && Math.abs(e[0].num - e[1].num) >= 6 ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 181, name: '0-5 Special', fn: (e) => (e[0].num === 0 || e[0].num === 5 ? { vote: e[0].num === 0 ? 'Big' : 'Small', weight: 3.8 } : null) },
      { id: 182, name: 'Violet Special', fn: (e) => (e[0].isViolet ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 183, name: 'Dual Hit', fn: (e) => (e[0] && e[1] && e[0].num === e[1].num ? { vote: this._oppSize(e[0].size), weight: 3.2 } : null) },
      { id: 184, name: 'Single Hit', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size !== e[1].size && e[1].size === e[2].size && e[2].size === e[3].size ? { vote: e[0].size, weight: 3.1 } : null) },
      { id: 185, name: 'Multi Hit', fn: (e) => (this._streak(e, 'size') >= 3 && this._streak(e, 'size') < 6 ? { vote: e[0].size, weight: 2.9 } : null) },
      { id: 186, name: 'Safe Pattern', fn: (e) => { if (e.length < 10) return null; const t = e.slice(0, 10).filter((x) => x.size === 'Big').length; return t >= 7 ? { vote: 'Small', weight: 3.5 } : t <= 3 ? { vote: 'Big', weight: 3.5 } : null; } },
      { id: 187, name: 'Risk Pattern', fn: (e) => (this._streak(e, 'size') >= 5 ? { vote: this._oppSize(e[0].size), weight: 3.6 } : null) },
      { id: 188, name: 'High Risk', fn: (e) => (this._streak(e, 'size') >= 7 ? { vote: this._oppSize(e[0].size), weight: 4.2 } : null) },
      { id: 189, name: 'Low Risk', fn: (e) => (e[1] && e[2] && this._streak(e, 'size') === 2 && e[2].size !== e[1].size ? { vote: e[0].size, weight: 2.6 } : null) },
      { id: 190, name: 'Balanced Bet', fn: (e) => { if (e.length < 6) return null; const t = e.slice(0, 6).filter((x) => x.size === 'Big').length - 3; return t > 1 ? { vote: 'Small', weight: 3 } : t < -1 ? { vote: 'Big', weight: 3 } : null; } },
      { id: 191, name: 'Aggressive', fn: (e) => (this._streak(e, 'size') >= 4 && this._streak(e, 'size') < 7 ? { vote: e[0].size, weight: 3.5 } : null) },
      { id: 192, name: 'Conservative', fn: (e) => (e[0] && e[1] && e[2] && e[0].size === e[1].size && e[1].size === e[2].size ? { vote: this._oppSize(e[0].size), weight: 3 } : null) },
      { id: 193, name: 'Momentum Ride', fn: (e) => (e[0] && e[1] && e[0].num >= 8 && e[1].num >= 7 ? { vote: 'Big', weight: 3.2 } : e[0] && e[1] && e[0].num <= 1 && e[1].num <= 2 ? { vote: 'Small', weight: 3.2 } : null) },
      { id: 194, name: 'Reversal Catch', fn: (e) => (this._streak(e, 'size') >= 5 ? { vote: this._oppSize(e[0].size), weight: 4.2 } : null) },
      { id: 195, name: 'Streak Ride', fn: (e) => (this._streak(e, 'size') >= 3 && this._streak(e, 'size') < 6 ? { vote: e[0].size, weight: 3.2 } : null) },
      { id: 196, name: 'Streak Break', fn: (e) => (this._streak(e, 'size') >= 6 ? { vote: this._oppSize(e[0].size), weight: 4.5 } : null) },
      { id: 197, name: 'Pattern Break', fn: (e) => (e.length >= 2 && this._jumping(e.slice(1), 'size', 4) && e[0].size === e[1].size ? { vote: this._oppSize(e[0].size), weight: 3.6 } : null) },
      { id: 198, name: 'New Pattern', fn: (e) => (e[0] && e[1] && e[2] && e[3] && e[0].size !== e[1].size && e[1].size !== e[2].size && e[2].size !== e[3].size ? { vote: this._oppSize(e[0].size), weight: 3.8 } : null) },
      { id: 199, name: 'Classic Pattern', fn: (e) => (this._matchSeq(e, 'size', ['Big', 'Big', 'Small', 'Small']) ? { vote: 'Big', weight: 3.8 } : this._matchSeq(e, 'size', ['Small', 'Small', 'Big', 'Big']) ? { vote: 'Small', weight: 3.8 } : null) },
      { id: 200, name: 'Ultimate Pattern', fn: (e) => { const t = this._streak(e, 'size'); const n = e.length >= 10 ? e.slice(0, 10).reduce((a, b) => a + b.num, 0) / 10 : 4.5; return t >= 3 && t < 6 ? { vote: e[0].size, weight: 4 } : t >= 6 ? { vote: this._oppSize(e[0].size), weight: 4.8 } : n >= 5.8 ? { vote: 'Small', weight: 3.8 } : n <= 3.2 ? { vote: 'Big', weight: 3.8 } : null; } },
    ];
    this.rules.push(...r);
  }

  private _initRules201To1000(): void {
    let currentId = 201;

    const getCombinations = (vals: string[], len: number): string[][] => {
      if (len === 1) return vals.map((v) => [v]);
      const prev = getCombinations(vals, len - 1);
      const res: string[][] = [];
      for (const p of prev) {
        for (const v of vals) res.push([...p, v]);
      }
      return res;
    };

    for (const len of [3, 4, 5, 6]) {
      const combos = getCombinations(['Big', 'Small'], len);
      for (const c of combos) {
        const seqName = c.join('-');
        const vote: 'Big' | 'Small' = c[0] === 'Big' ? 'Small' : 'Big';
        const targetSeq = [...c];
        this.rules.push({
          id: currentId++,
          name: `Size Sequence ${seqName}`,
          fn: (e) => (this._matchSeq(e, 'size', targetSeq) ? { vote, weight: 2.4 } : null),
        });
      }
    }

    for (const len of [3, 4, 5, 6]) {
      const combos = getCombinations(['Red', 'Green'], len);
      for (const c of combos) {
        const seqName = c.join('-');
        const vote: 'Big' | 'Small' = c[0] === 'Red' ? 'Big' : 'Small';
        const targetSeq = [...c];
        this.rules.push({
          id: currentId++,
          name: `Purecolor Sequence ${seqName}`,
          fn: (e) => (this._matchSeq(e, 'pureColor', targetSeq) ? { vote, weight: 2.4 } : null),
        });
      }
    }

    for (const len of [3, 4, 5, 6]) {
      const combos = getCombinations(['Even', 'Odd'], len);
      for (const c of combos) {
        const seqName = c.join('-');
        const vote: 'Big' | 'Small' = c[0] === 'Even' ? 'Big' : 'Small';
        const targetSeq = [...c];
        this.rules.push({
          id: currentId++,
          name: `Parity Sequence ${seqName}`,
          fn: (e) => (this._matchSeq(e, 'parity', targetSeq) ? { vote, weight: 2.4 } : null),
        });
      }
    }

    for (let s = 2; s <= 19; s++) {
      const targetS = s;
      this.rules.push({
        id: currentId++,
        name: `Size Streak ${targetS}`,
        fn: (e) => (this._streak(e, 'size') >= targetS ? { vote: e[0].size, weight: 2.2 } : null),
      });
    }

    for (let s = 2; s <= 19; s++) {
      const targetS = s;
      this.rules.push({
        id: currentId++,
        name: `Purecolor Streak ${targetS}`,
        fn: (e) => (this._streak(e, 'pureColor') >= targetS ? { vote: 'Big', weight: 2.2 } : null),
      });
    }

    for (let s = 2; s <= 19; s++) {
      const targetS = s;
      this.rules.push({
        id: currentId++,
        name: `Parity Streak ${targetS}`,
        fn: (e) => (this._streak(e, 'parity') >= targetS ? { vote: 'Small', weight: 2.2 } : null),
      });
    }

    for (let a = 2; a <= 15; a++) {
      const targetA = a;
      this.rules.push({
        id: currentId++,
        name: `Size Alternation ${targetA}`,
        fn: (e) => (this._jumping(e, 'size', targetA) ? { vote: this._oppSize(e[0].size), weight: 2.6 } : null),
      });
    }

    for (let a = 2; a <= 15; a++) {
      const targetA = a;
      this.rules.push({
        id: currentId++,
        name: `Purecolor Alternation ${targetA}`,
        fn: (e) => (this._jumping(e, 'pureColor', targetA) ? { vote: 'Small', weight: 2.6 } : null),
      });
    }

    for (let a = 2; a <= 15; a++) {
      const targetA = a;
      this.rules.push({
        id: currentId++,
        name: `Parity Alternation ${targetA}`,
        fn: (e) => (this._jumping(e, 'parity', targetA) ? { vote: 'Big', weight: 2.6 } : null),
      });
    }

    for (let m = 2; m <= 10; m++) {
      const targetM = m;
      this.rules.push({
        id: currentId++,
        name: `Size Mirror ${targetM}`,
        fn: (e) => (this._mirror(e, 'size', targetM) ? { vote: this._oppSize(e[0].size), weight: 2.5 } : null),
      });
    }

    for (let m = 2; m <= 10; m++) {
      const targetM = m;
      this.rules.push({
        id: currentId++,
        name: `Purecolor Mirror ${targetM}`,
        fn: (e) => (this._mirror(e, 'pureColor', targetM) ? { vote: 'Big', weight: 2.5 } : null),
      });
    }

    for (let m = 2; m <= 10; m++) {
      const targetM = m;
      this.rules.push({
        id: currentId++,
        name: `Parity Mirror ${targetM}`,
        fn: (e) => (this._mirror(e, 'parity', targetM) ? { vote: 'Small', weight: 2.5 } : null),
      });
    }

    const thresholds = [2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7];
    for (let w = 3; w <= 12; w++) {
      for (const t of thresholds) {
        const targetW = w;
        const targetT = t;
        const oppT = 10 - t;
        this.rules.push({
          id: currentId++,
          name: `Numeric Mean W${targetW} T${targetT}`,
          fn: (e) => {
            if (e.length < targetW) return null;
            const avg = e.slice(0, targetW).reduce((s, x) => s + x.num, 0) / targetW;
            return avg >= targetT ? { vote: 'Small', weight: 2.3 } : avg <= oppT ? { vote: 'Big', weight: 2.3 } : null;
          },
        });
      }
    }

    for (let w = 3; w <= 12; w++) {
      for (let c = 1; c < w; c++) {
        const targetW = w;
        const targetC = c;
        this.rules.push({
          id: currentId++,
          name: `Size Big Count W${targetW} C${targetC}`,
          fn: (e) =>
            e.length >= targetW && e.slice(0, targetW).filter((x) => x.size === 'Big').length >= targetC
              ? { vote: 'Small', weight: 2.1 }
              : null,
        });
      }
    }

    for (let w = 3; w <= 12; w++) {
      for (let c = 1; c < w; c++) {
        const targetW = w;
        const targetC = c;
        this.rules.push({
          id: currentId++,
          name: `Purecolor Red Count W${targetW} C${targetC}`,
          fn: (e) =>
            e.length >= targetW && e.slice(0, targetW).filter((x) => x.pureColor === 'Red').length >= targetC
              ? { vote: 'Big', weight: 2.1 }
              : null,
        });
      }
    }

    for (let w = 3; w <= 12; w++) {
      for (let c = 1; c < w; c++) {
        const targetW = w;
        const targetC = c;
        this.rules.push({
          id: currentId++,
          name: `Parity Even Count W${targetW} C${targetC}`,
          fn: (e) =>
            e.length >= targetW && e.slice(0, targetW).filter((x) => x.parity === 'Even').length >= targetC
              ? { vote: 'Big', weight: 2.1 }
              : null,
        });
      }
    }

    for (let w = 3; w <= 8; w++) {
      const maxD = w === 8 ? 2 : 4;
      for (let d = 1; d <= maxD; d++) {
        const targetW = w;
        const targetD = d;
        this.rules.push({
          id: currentId++,
          name: `Numeric Equal Gap W${targetW} D${targetD}`,
          fn: (e) => {
            if (e.length < targetW) return null;
            const ok = e
              .slice(0, targetW)
              .every((x, i, a) => i === 0 || Math.abs(x.num - a[i - 1].num) === targetD);
            return ok ? { vote: e[0].num >= 5 ? 'Small' : 'Big', weight: 2.7 } : null;
          },
        });
      }
    }
  }

  public static formatResult(num: number): WinGo1000Entry {
    const n = Math.abs(Math.round(num)) % 10;
    const isViolet = n === 0 || n === 5;
    const pureColor: 'Red' | 'Green' = n % 2 === 0 ? 'Red' : 'Green';
    const size: 'Big' | 'Small' = n >= 5 ? 'Big' : 'Small';
    const parity: 'Even' | 'Odd' = n % 2 === 0 ? 'Even' : 'Odd';
    return { num: n, size, pureColor, parity, isViolet };
  }

  public predict(nums: number[]): WinGo1000Result {
    if (!nums || nums.length === 0) {
      return {
        prediction: 'NEUTRAL',
        confidence: 50,
        bigScore: 0,
        smallScore: 0,
        totalRulesTriggered: 0,
        triggeredRules: [],
      };
    }

    const history = nums.map((n) => WinGo1000Engine.formatResult(n));
    let bigScore = 0;
    let smallScore = 0;
    const triggered: WinGo1000TriggeredRule[] = [];

    for (const rule of this.rules) {
      try {
        const res = rule.fn(history);
        if (res && res.vote && res.weight) {
          triggered.push({
            id: rule.id,
            name: rule.name,
            vote: res.vote,
            weight: res.weight,
          });
          if (res.vote === 'Big') bigScore += res.weight;
          else if (res.vote === 'Small') smallScore += res.weight;
        }
      } catch {
        // Safe skip
      }
    }

    triggered.sort((a, b) => b.weight - a.weight);
    const totalWeight = bigScore + smallScore;
    const prediction: 'BIG' | 'SMALL' | 'NEUTRAL' =
      bigScore > smallScore ? 'BIG' : smallScore > bigScore ? 'SMALL' : 'NEUTRAL';
    const confidence =
      totalWeight > 0
        ? Number(((Math.max(bigScore, smallScore) / totalWeight) * 100).toFixed(2))
        : 50;

    return {
      prediction,
      confidence,
      bigScore: Number(bigScore.toFixed(2)),
      smallScore: Number(smallScore.toFixed(2)),
      totalRulesTriggered: triggered.length,
      triggeredRules: triggered,
    };
  }
}

export const winGo1000Engine = new WinGo1000Engine();

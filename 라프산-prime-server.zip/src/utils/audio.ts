class SoundEngine {
  private ctx: AudioContext | null = null;
  public enabled = true;

  private getContext(): AudioContext | null {
    if (!this.enabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AC) {
        this.ctx = new AC();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  private tone(
    freq: number,
    type: OscillatorType,
    duration: number,
    volume: number,
    delay = 0,
    endFreq?: number
  ): void {
    const c = this.getContext();
    if (!c) return;
    try {
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, c.currentTime + delay);
      if (endFreq !== undefined) {
        o.frequency.exponentialRampToValueAtTime(endFreq, c.currentTime + delay + duration);
      }
      g.gain.setValueAtTime(volume, c.currentTime + delay);
      g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + delay + duration);
      o.connect(g);
      g.connect(c.destination);
      o.start(c.currentTime + delay);
      o.stop(c.currentTime + delay + duration);
    } catch {
      // Ignore WebAudio context errors when blocked before user gesture
    }
  }

  public key(): void {
    this.tone(1200, 'sine', 0.05, 0.08, 0, 800);
  }

  public tab(): void {
    this.tone(800, 'sine', 0.06, 0.06, 0, 1400);
  }

  public granted(): void {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      this.tone(f, 'sine', 0.35, 0.12, i * 0.08);
    });
  }

  public denied(): void {
    this.tone(140, 'sawtooth', 0.3, 0.15);
  }

  public tick(s = 5): void {
    const high = s <= 3;
    this.tone(high ? 1200 : 700, high ? 'square' : 'sine', high ? 0.15 : 0.08, high ? 0.12 : 0.06);
  }

  public win(): void {
    [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) => {
      this.tone(f, 'triangle', 0.45, 0.18, i * 0.09);
    });
  }

  public jackpot(): void {
    [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98, 2093].forEach((f, i) => {
      this.tone(f, 'sine', 0.5, 0.22, i * 0.06);
    });
  }

  public loss(): void {
    [320, 240, 180].forEach((f, i) => {
      this.tone(f, 'sawtooth', 0.25, 0.12, i * 0.12);
    });
  }

  public cash(): void {
    [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98, 2093].forEach((f, i) => {
      this.tone(f, 'triangle', 0.6, 0.16, i * 0.045);
    });
  }
}

export const soundEngine = new SoundEngine();

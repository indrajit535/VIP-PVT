import type { HistoryEntry, UserSession } from '../types/wingo';

const KEYS = {
  SESSION: 'sdd_pvt_session_v1',
  HISTORY: 'sdd_pvt_hist_v1',
  DEVICE: 'sdd_pvt_device_id_v1',
} as const;

export const storage = {
  getSession(): UserSession | null {
    try {
      const raw = localStorage.getItem(KEYS.SESSION);
      return raw ? (JSON.parse(raw) as UserSession) : null;
    } catch {
      return null;
    }
  },

  saveSession(session: UserSession): void {
    localStorage.setItem(KEYS.SESSION, JSON.stringify(session));
  },

  clearSession(): void {
    localStorage.removeItem(KEYS.SESSION);
  },

  getHistory(): HistoryEntry[] {
    try {
      const raw = localStorage.getItem(KEYS.HISTORY);
      return raw ? (JSON.parse(raw) as HistoryEntry[]) : [];
    } catch {
      return [];
    }
  },

  saveHistory(history: HistoryEntry[]): void {
    localStorage.setItem(KEYS.HISTORY, JSON.stringify(history.slice(0, 200)));
  },

  clearHistory(): void {
    localStorage.removeItem(KEYS.HISTORY);
  },

  getDeviceId(): string {
    let id = localStorage.getItem(KEYS.DEVICE);
    if (!id) {
      id = 'SDD-Q-' + Math.random().toString(36).slice(2, 8).toUpperCase();
      localStorage.setItem(KEYS.DEVICE, id);
    }
    return id;
  },
};

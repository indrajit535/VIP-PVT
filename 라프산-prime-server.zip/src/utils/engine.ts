import type {
  CombinedAnalysis,
  DirectionSize,
  DrawRecord,
  PatternRule,
  PredictionResult,
} from '../types/wingo';
import { predictMarkovSmartNumbers, runTitanMasterEngine } from './titanMasterEngine';
import { winGo1000Engine } from './wingo1000Engine';

export function toSize(n: string | number): DirectionSize {
  return parseInt(String(n), 10) >= 5 ? 'BIG' : 'SMALL';
}

export function ballColor(n: number): { label: string; cls: 'g' | 'p' } {
  const d = Math.abs(Math.round(n)) % 10;
  if (d === 0 || d === 5) {
    return { label: d === 0 ? 'PURPLE+SPECIAL' : 'GREEN+SPECIAL', cls: 'p' };
  }
  if ([1, 3, 7, 9].includes(d)) {
    return { label: 'GREEN', cls: 'g' };
  }
  return { label: 'PURPLE', cls: 'p' };
}

export function hashString(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

export function analyzeDragonStrikePatterns(history: DrawRecord[]): PatternRule[] {
  const out: PatternRule[] = [];
  if (!history || history.length < 5) return out;

  const nums = history.slice(0, 35).map((x) => parseInt(String(x.number ?? 0), 10));
  const sz = nums.map(toSize);

  const streakLabel = sz[0];
  let streakCount = 1;
  for (let i = 1; i < sz.length; i++) {
    if (sz[i] === streakLabel) streakCount++;
    else break;
  }

  if (streakCount >= 3) {
    out.push({
      id: 'P_DRAGON_STRIKE',
      cat: 'DRAGON',
      name: `Dragon Strike (${streakCount}x ${streakLabel})`,
      dir: streakLabel,
      w: 24,
      conf: Number(Math.min(96.5, 88.0 + streakCount * 1.5).toFixed(1)),
      desc: `Active Dragon Strike detected! ${streakCount} consecutive ${streakLabel} outcomes.`,
    });
  }

  const last3 = [sz[0], sz[1], sz[2]];
  if (last3[0] === 'BIG' && last3[1] === 'BIG' && last3[2] === 'BIG') {
    out.push({
      id: 'P_3BIG',
      cat: 'STREAK3',
      name: '3 BIG Streak (BBB)',
      dir: 'SMALL',
      w: 18,
      conf: 91.5,
      desc: 'Sequence: BIG, BIG, BIG -> Mean reversion watch.',
    });
  } else if (last3[0] === 'SMALL' && last3[1] === 'SMALL' && last3[2] === 'SMALL') {
    out.push({
      id: 'P_3SMALL',
      cat: 'STREAK3',
      name: '3 SMALL Streak (SSS)',
      dir: 'BIG',
      w: 18,
      conf: 91.5,
      desc: 'Sequence: SMALL, SMALL, SMALL -> Mean reversion watch.',
    });
  }

  if (last3[0] === 'SMALL' && last3[1] === 'BIG' && last3[2] === 'BIG') {
    out.push({
      id: 'P_BBS',
      cat: 'BREAK',
      name: 'BIG Pair Broken (BBS)',
      dir: 'SMALL',
      w: 14,
      conf: 88.0,
      desc: 'Sequence: BIG, BIG, SMALL -> Opposite pressure.',
    });
  } else if (last3[0] === 'BIG' && last3[1] === 'SMALL' && last3[2] === 'SMALL') {
    out.push({
      id: 'P_SSB',
      cat: 'BREAK',
      name: 'SMALL Pair Broken (SSB)',
      dir: 'BIG',
      w: 14,
      conf: 88.0,
      desc: 'Sequence: SMALL, SMALL, BIG -> Opposite pressure.',
    });
  }

  if (sz[0] === 'BIG' && sz[1] === 'SMALL' && sz[2] === 'BIG') {
    out.push({
      id: 'P_BSB',
      cat: 'ZIGZAG',
      name: 'Alternating Wave (BSB)',
      dir: 'SMALL',
      w: 12,
      conf: 86.5,
      desc: 'Alternating wave around SMALL observed.',
    });
  } else if (sz[0] === 'SMALL' && sz[1] === 'BIG' && sz[2] === 'SMALL') {
    out.push({
      id: 'P_SBS',
      cat: 'ZIGZAG',
      name: 'Alternating Wave (SBS)',
      dir: 'BIG',
      w: 12,
      conf: 86.5,
      desc: 'Alternating wave around BIG observed.',
    });
  }

  const bCnt = sz.filter((s) => s === 'BIG').length;
  const sCnt = sz.length - bCnt;
  const dom: DirectionSize = bCnt >= sCnt ? 'BIG' : 'SMALL';
  out.push({
    id: 'P_MACRO',
    cat: 'MACRO',
    name: 'Global Distribution Trend',
    dir: dom,
    w: 10,
    conf: 84.0,
    desc: `Macro dominant side: ${dom} (${Math.max(bCnt, sCnt)}/${sz.length})`,
  });

  return out.sort((a, b) => b.w - a.w);
}

export function combineAllEngines(
  history: DrawRecord[],
  period: string,
  level: number,
  consecutiveLosses = 0,
  lastLossNum: number | null = null
): CombinedAnalysis {
  const nums = history
    .slice(0, 40)
    .map((x) => parseInt(String(x.number ?? '0'), 10))
    .filter((n) => Number.isFinite(n) && n >= 0 && n <= 9);

  // 1. Dragon Strike Core
  const dragonPatterns = analyzeDragonStrikePatterns(history);

  // 2. Titan 200-Pattern + 12 Formulas + Samad Hash + Prime Fusion + CPU/Bunny + Mafiya + BD Akash ML
  const titan = runTitanMasterEngine(nums, period, consecutiveLosses, lastLossNum);

  // 3. WinGo 1000-Rule Engine
  const rules1000 = winGo1000Engine.predict(nums);

  // Combine weighted votes across all 3 engines
  let totalBig = titan.bigVotes;
  let totalSmall = titan.smallVotes;

  // Normalize 1000-rule engine weight onto Titan scale (~15-35 vote range)
  const r1000Total = rules1000.bigScore + rules1000.smallScore;
  if (r1000Total > 0) {
    const bigShare = (rules1000.bigScore / r1000Total) * 30;
    const smallShare = (rules1000.smallScore / r1000Total) * 30;
    totalBig += bigShare;
    totalSmall += smallShare;
  }

  // Add Dragon Strike core votes (scaled cleanly)
  dragonPatterns.forEach((p) => {
    if (p.dir === 'BIG') totalBig += p.w * 0.35;
    else totalSmall += p.w * 0.35;
  });

  const direction: DirectionSize = totalBig >= totalSmall ? 'BIG' : 'SMALL';
  const totalCombined = Math.max(1, totalBig + totalSmall);
  const margin = Math.abs(totalBig - totalSmall) / totalCombined;
  const levelBase = level === 1 ? 89.5 : level === 2 ? 93.2 : 95.8;
  const conf = Number(
    Math.min(
      98.9,
      Math.max(titan.recoveryActive ? 94.0 : 88.0, levelBase + margin * 12)
    ).toFixed(1)
  );

  // Build unified PatternRule list showcasing signals from ALL engines
  const unifiedPatterns: PatternRule[] = [...dragonPatterns];

  if (titan.formula.bestScore >= 5) {
    unifiedPatterns.push({
      id: 'TITAN_FORMULA',
      cat: 'FORMULA',
      name: `Titan Math: ${titan.formula.name}`,
      dir: titan.formula.size,
      w: Math.round(titan.formula.bestScore * 4),
      conf: Math.min(97, 78 + titan.formula.bestScore * 2),
      desc: `Verified ${titan.formula.bestScore}/10 recent rounds. Regime: ${titan.regime.icon} ${titan.regime.name}`,
    });
  }

  if (titan.rjp) {
    unifiedPatterns.push({
      id: 'SAMAD_HASH',
      cat: 'TITAN200',
      name: `Samad Gold Hash #${titan.rjp.hash}`,
      dir: titan.rjp.size,
      w: 22,
      conf: titan.rjp.conf,
      desc: `Weighted hash ${titan.rjp.hash} locks ${titan.rjp.size} (${titan.rjp.conf}%).`,
    });
  }

  if (titan.res200) {
    titan.res200.topSignals.slice(0, 4).forEach((sig, i) => {
      unifiedPatterns.push({
        id: `T200_${i}_${sig.pattern}`,
        cat: 'TITAN200',
        name: `200-Pat: ${sig.pattern}`,
        dir: sig.vote === 'Big' ? 'BIG' : 'SMALL',
        w: Math.round(sig.weight * 5),
        conf: Number(titan.res200!.confidence.toFixed(1)),
        desc: `Titan 200-Pattern match (${titan.res200!.totalPatternsTriggered} active signals).`,
      });
    });
  }

  rules1000.triggeredRules.slice(0, 5).forEach((r) => {
    unifiedPatterns.push({
      id: `R1000_${r.id}`,
      cat: 'RULE1000',
      name: `Rule #${r.id}: ${r.name}`,
      dir: r.vote === 'Big' ? 'BIG' : 'SMALL',
      w: Math.round(r.weight * 5),
      conf: Number(rules1000.confidence.toFixed(1)),
      desc: `1000-Rule Matrix consensus (${rules1000.totalRulesTriggered}/1000 rules triggered).`,
    });
  });

  unifiedPatterns.sort((a, b) => b.w - a.w);

  return {
    patterns: unifiedPatterns,
    top: unifiedPatterns[0] || null,
    votesBig: Math.round(totalBig),
    votesSmall: Math.round(totalSmall),
    direction,
    confidence: conf,
    telemetry: {
      titan200Triggered: titan.res200?.totalPatternsTriggered || 0,
      titan200TopPattern: titan.res200?.topSignals[0]?.pattern || titan.formula.name,
      formulaName: titan.formula.name,
      formulaScore: titan.formula.bestScore,
      samadHash: titan.rjp?.hash ?? null,
      samadSize: titan.rjp?.size ?? null,
      regimeName: titan.regime.name,
      regimeIcon: titan.regime.icon,
      oracleMatch: titan.oracle,
      rules1000Triggered: rules1000.totalRulesTriggered,
      rules1000BigScore: rules1000.bigScore,
      rules1000SmallScore: rules1000.smallScore,
      rules1000Confidence: rules1000.confidence,
      recoveryActive: titan.recoveryActive,
      triColor: titan.triColor,
    },
  };
}

export function predictOutcome(
  history: DrawRecord[],
  period: string,
  level: number,
  consecutiveLosses = 0,
  lastLossNum: number | null = null
): PredictionResult {
  if (!history || history.length === 0) {
    return {
      period: String(period),
      size: 'BIG',
      color: 'GREEN',
      ball: 7,
      opposite: 2,
      safe: [5, 7, 8],
      level: 1,
      mult: '1X',
      confidence: 89.0,
      algo: 'SDD PVT UNIFIED CORE',
      combined: {
        votesBig: 50,
        votesSmall: 50,
        patterns: [],
        top: null,
        direction: 'BIG',
        confidence: 89.0,
        telemetry: {
          titan200Triggered: 0,
          titan200TopPattern: 'INIT',
          formulaName: 'TITAN-NEURAL',
          formulaScore: 0,
          samadHash: null,
          samadSize: null,
          regimeName: 'NEUTRAL',
          regimeIcon: '≈',
          oracleMatch: null,
          rules1000Triggered: 0,
          rules1000BigScore: 0,
          rules1000SmallScore: 0,
          rules1000Confidence: 50,
          recoveryActive: false,
          triColor: 'GREEN',
        },
      },
    };
  }

  const nums = history
    .slice(0, 40)
    .map((x) => parseInt(String(x.number ?? '0'), 10))
    .filter((n) => Number.isFinite(n) && n >= 0 && n <= 9);

  const comb = combineAllEngines(history, period, level, consecutiveLosses, lastLossNum);
  const dir = comb.direction;
  const smart = predictMarkovSmartNumbers(dir, nums);
  const color = ballColor(smart.targetNum);
  const mult = level === 1 ? '1X' : level === 2 ? '3X' : '9X';

  const algo = comb.telemetry.recoveryActive
    ? `🛡️ ANTI-LOSS RECOVERY (${comb.telemetry.rules1000Triggered} + ${comb.telemetry.titan200Triggered} Rules)`
    : `${comb.telemetry.titan200TopPattern} · ${comb.telemetry.rules1000Triggered}/1000 Rules`;

  return {
    period: String(period),
    size: dir,
    color: color.label,
    ball: smart.targetNum,
    opposite: smart.pairNum,
    safe: smart.safe,
    level,
    mult,
    confidence: comb.confidence,
    algo,
    combined: comb,
  };
}

export const WINGO_1M_HISTORY_API =
  'https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json';

function parseDrawPayload(json: unknown): DrawRecord[] {
  const obj = json as {
    data?: { list?: unknown[] } | unknown[];
    list?: unknown[];
  };
  const rawList =
    (obj?.data && !Array.isArray(obj.data) ? obj.data.list : undefined) ||
    obj?.list ||
    (Array.isArray(obj?.data) ? obj.data : undefined) ||
    (Array.isArray(json) ? json : undefined);

  if (!Array.isArray(rawList) || rawList.length === 0) return [];

  const parsed = rawList
    .slice(0, 40)
    .map((item) => {
      const row = item as Record<string, unknown>;
      const issueNumber = String(
        row.issueNumber ?? row.issue ?? row.period ?? row.periodNumber ?? ''
      ).trim();
      const rawNum = String(
        row.number ?? row.num ?? row.result ?? row.digit ?? row.openNum ?? ''
      ).trim();
      const digit = parseInt(rawNum, 10);
      if (!issueNumber || !Number.isFinite(digit)) return null;
      return { issueNumber, number: String(Math.abs(digit) % 10) };
    })
    .filter((x): x is DrawRecord => x !== null);

  parsed.sort((a, b) => (a.issueNumber < b.issueNumber ? 1 : a.issueNumber > b.issueNumber ? -1 : 0));
  return parsed;
}

export function getStandardWingoPeriod(offsetMinutes = 0): string {
  // Official WinGo 1M uses Asia/Kolkata (UTC+5:30 = +330 minutes)
  const istNow = new Date(
    Date.now() + (new Date().getTimezoneOffset() + 330) * 60000 + offsetMinutes * 60000
  );
  const y = istNow.getFullYear();
  const m = String(istNow.getMonth() + 1).padStart(2, '0');
  const d = String(istNow.getDate()).padStart(2, '0');
  const totalMin = istNow.getHours() * 60 + istNow.getMinutes();
  const serialNo = totalMin + 1;
  return `${y}${m}${d}10001${String(serialNo).padStart(4, '0')}`;
}

export function incrementPeriod(p: string): string {
  if (!p || p === '---') return getStandardWingoPeriod(0);
  try {
    const clean = p.trim();
    if (/^\d+$/.test(clean)) {
      if (clean.length >= 13) {
        const datePart = clean.slice(0, 8);
        const midPart = clean.slice(8, -4);
        const seqNum = parseInt(clean.slice(-4), 10);
        if (seqNum >= 1440) {
          const yr = parseInt(datePart.slice(0, 4), 10);
          const mo = parseInt(datePart.slice(4, 6), 10) - 1;
          const dy = parseInt(datePart.slice(6, 8), 10);
          const nextDay = new Date(Date.UTC(yr, mo, dy + 1));
          const ny = nextDay.getUTCFullYear();
          const nm = String(nextDay.getUTCMonth() + 1).padStart(2, '0');
          const nd = String(nextDay.getUTCDate()).padStart(2, '0');
          return `${ny}${nm}${nd}${midPart}0001`;
        }
      }
      return (BigInt(clean) + 1n).toString();
    }
  } catch {
    // Fallback
  }
  return getStandardWingoPeriod(0);
}

export function generateMockData(): DrawRecord[] {
  const out: DrawRecord[] = [];
  for (let i = 1; i <= 40; i++) {
    const period = getStandardWingoPeriod(-i);
    const hash = hashString(period);
    const num = String(hash % 10);
    out.push({ issueNumber: period, number: num });
  }
  return out;
}

export async function fetchLiveHistory(mockMode: boolean): Promise<DrawRecord[]> {
  if (mockMode) {
    return generateMockData();
  }

  const ts = Date.now();
  const directUrl = `${WINGO_1M_HISTORY_API}?ts=${ts}`;
  const endpoints = [
    directUrl,
    `/api/wingo/history?ts=${ts}`,
    `https://api.allorigins.win/raw?url=${encodeURIComponent(directUrl)}`,
    `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(directUrl)}`,
  ];

  for (const endpoint of endpoints) {
    try {
      const res = await fetch(endpoint, {
        cache: 'no-store',
        signal: AbortSignal.timeout(5500),
      });
      if (!res.ok) continue;
      const json: unknown = await res.json();
      const parsed = parseDrawPayload(json);
      if (parsed.length > 0) {
        return parsed;
      }
    } catch {
      continue;
    }
  }

  throw new Error('Live WinGo 1M API unavailable');
}

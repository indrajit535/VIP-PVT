import { useCallback, useEffect, useRef, useState } from 'react';
import { BarChart3, Box, Gamepad2, RotateCcw, User } from 'lucide-react';
import { AccountTab } from './components/AccountTab';
import { AnalyticsTab } from './components/AnalyticsTab';
import { ConfirmModal } from './components/ConfirmModal';
import { GamesTab } from './components/GamesTab';
import { HistoryTab } from './components/HistoryTab';
import { LoginGateway } from './components/LoginGateway';
import { ResultPopup } from './components/ResultPopup';
import { RoundsTab } from './components/RoundsTab';
import { StarfieldBackground } from './components/StarfieldBackground';
import type {
  DrawRecord,
  HistoryEntry,
  LiveStatus,
  PredictionResult,
  TabId,
  UserSession,
} from './types/wingo';
import { soundEngine } from './utils/audio';
import {
  fetchLiveHistory,
  getStandardWingoPeriod,
  incrementPeriod,
  predictOutcome,
  toSize,
} from './utils/engine';
import { storage } from './utils/storage';

const TABS: { id: TabId; label: string; Icon: typeof Box }[] = [
  { id: 'rounds', label: 'ROUNDS', Icon: Box },
  { id: 'history', label: 'HISTORY', Icon: RotateCcw },
  { id: 'analytics', label: 'ANALYTICS', Icon: BarChart3 },
  { id: 'games', label: 'GAMES', Icon: Gamepad2 },
  { id: 'account', label: 'ACCOUNT', Icon: User },
];

function computeSecondsLeft(): number {
  const secNow = Math.floor(Date.now() / 1000);
  return 59 - (secNow % 60);
}

export default function App() {
  const [session, setSession] = useState<UserSession | null>(() => {
    const existing = storage.getSession();
    return existing && existing.key === 'SDD_PVT' ? existing : null;
  });
  const [activeTab, setActiveTab] = useState<TabId>('rounds');
  const [history, setHistory] = useState<DrawRecord[]>([]);
  const [trackerHistory, setTrackerHistory] = useState<HistoryEntry[]>(() =>
    storage.getHistory()
  );
  const [currentPeriod, setCurrentPeriod] = useState<string>('---');
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [mockMode, setMockMode] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [liveStatus, setLiveStatus] = useState<{ status: LiveStatus; text: string }>({
    status: 'loading',
    text: 'SYNCING',
  });
  const [secondsLeft, setSecondsLeft] = useState<number>(() => computeSecondsLeft());
  const [popupEntry, setPopupEntry] = useState<HistoryEntry | null>(null);
  const [toastText, setToastText] = useState<string | null>(null);
  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    type: 'logout' | 'clearHistory' | null;
  }>({ open: false, type: null });

  const levelRef = useRef<number>(1);
  const consecutiveLossesRef = useRef<number>(0);
  const lastLossNumRef = useRef<number | null>(null);
  const predictionRef = useRef<PredictionResult | null>(null);
  const lastEvaluatedRef = useRef<string | null>(null);
  const lastIssueRef = useRef<string | null>(null);
  const lastCountSecRef = useRef<number>(-1);
  const mockModeRef = useRef<boolean>(false);
  const wasMockRef = useRef<boolean>(false);
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const rolloverTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    soundEngine.enabled = soundEnabled;
  }, [soundEnabled]);

  useEffect(() => {
    mockModeRef.current = mockMode;
  }, [mockMode]);

  const showToast = useCallback((text: string) => {
    setToastText(text);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToastText(null), 4000);
  }, []);

  const evaluateIncoming = useCallback((list: DrawRecord[]) => {
    const currentPred = predictionRef.current;
    if (!currentPred || !currentPred.period || !list.length) return;
    if (lastEvaluatedRef.current === currentPred.period) return;

    const matched = list.find((item) => String(item.issueNumber) === currentPred.period);
    if (!matched) return;

    const issue = String(matched.issueNumber);
    const actualNum = parseInt(String(matched.number), 10);
    if (isNaN(actualNum)) return;

    const actualSize = actualNum >= 5 ? 'BIG' : 'SMALL';
    const isBallWin = actualNum === currentPred.ball;
    const isOppWin = actualNum === currentPred.opposite;
    const isJackpot = isBallWin || isOppWin;
    const isSizeWin = actualSize === currentPred.size;
    const isWin = isSizeWin || isJackpot;
    const profit = isJackpot ? 9 : isWin ? 1.96 : -1;

    const entry: HistoryEntry = {
      id: `h_${issue}_${Date.now()}`,
      period: issue,
      predicted: currentPred.size,
      predictedBall: currentPred.ball,
      actualNumber: actualNum,
      actualSize,
      isWin,
      isJackpot,
      profit,
      time: new Date().toLocaleTimeString(),
    };

    const updated = [entry, ...storage.getHistory()].slice(0, 200);
    storage.saveHistory(updated);
    setTrackerHistory(updated);
    lastEvaluatedRef.current = issue;

    if (isWin) {
      levelRef.current = 1;
      consecutiveLossesRef.current = 0;
      lastLossNumRef.current = null;
    } else {
      levelRef.current = Math.min(3, levelRef.current + 1);
      consecutiveLossesRef.current += 1;
      lastLossNumRef.current = actualNum;
    }

    if (soundEngine.enabled) {
      if (entry.isJackpot) soundEngine.jackpot();
      else if (entry.isWin) soundEngine.win();
      else soundEngine.loss();
    }
    setPopupEntry(entry);
  }, []);

  const bootData = useCallback(
    async (silent = false, forceMock?: boolean) => {
      const useMock = forceMock !== undefined ? forceMock : mockModeRef.current;
      if (!silent) {
        setLiveStatus({ status: 'loading', text: 'SYNCING' });
      }

      try {
        const list = await fetchLiveHistory(useMock);
        if (!useMock) {
          evaluateIncoming(list);
        } else if (wasMockRef.current) {
          evaluateIncoming(list);
        }

        const latestIssue = String(list[0].issueNumber);
        const nextPeriod = incrementPeriod(latestIssue);
        const shouldPredict =
          !predictionRef.current ||
          predictionRef.current.period !== nextPeriod ||
          lastIssueRef.current !== latestIssue ||
          wasMockRef.current !== useMock;

        if (shouldPredict) {
          const nextPred = predictOutcome(
            list,
            nextPeriod,
            levelRef.current,
            consecutiveLossesRef.current,
            lastLossNumRef.current
          );
          predictionRef.current = nextPred;
          setPrediction(nextPred);
        }

        lastIssueRef.current = latestIssue;
        wasMockRef.current = useMock;
        setHistory(list);
        setCurrentPeriod(nextPeriod);
        setLiveStatus({
          status: useMock ? 'mock' : 'live',
          text: useMock ? 'MOCK FEED' : 'LIVE 1M',
        });
      } catch {
        setLiveStatus({ status: 'off', text: 'RETRYING' });
      }
    },
    [evaluateIncoming]
  );

  useEffect(() => {
    if (!session) return;
    void bootData(false);

    const clockInterval = setInterval(() => {
      const sec = computeSecondsLeft();
      setSecondsLeft(sec);
      if (soundEngine.enabled && sec <= 5 && sec > 0 && lastCountSecRef.current !== sec) {
        soundEngine.tick(sec);
      }
      if (sec === 59 && lastCountSecRef.current === 0) {
        void bootData(true);
        rolloverTimersRef.current.forEach(clearTimeout);
        rolloverTimersRef.current = [
          setTimeout(() => void bootData(true), 1500),
          setTimeout(() => void bootData(true), 3500),
        ];
      }
      lastCountSecRef.current = sec;
    }, 300);

    const refreshInterval = setInterval(() => {
      void bootData(true);
    }, 2500);

    return () => {
      clearInterval(clockInterval);
      clearInterval(refreshInterval);
      rolloverTimersRef.current.forEach(clearTimeout);
      rolloverTimersRef.current = [];
    };
  }, [session, bootData]);

  const handleTabChange = (tab: TabId) => {
    if (activeTab === tab) return;
    soundEngine.tab();
    setActiveTab(tab);
  };

  const handleCopyPrediction = () => {
    if (!prediction) return;
    soundEngine.key();
    const text = `💲𝗪𝗜𝗡𝗚𝗢 1 𝗠𝗜𝗡𝗨𝗧𝗘 📣
▶️ 𝗦𝗨𝗥𝗘𝗦𝗛𝗢𝗧 𝗣𝗥𝗘𝗗𝗜𝗖𝗧𝗜𝗢𝗡 🌟

❄️ ${prediction.period}
➡️  ${prediction.size} [${prediction.ball},${prediction.opposite}] ✅✅✅

🟡 𝗥𝗘𝗚𝗜𝗦𝗧𝗘𝗥 𝗕𝗢𝗡𝗨𝗦 𝗜𝗡𝗦𝗧𝗔𝗡𝗧
https://9kclub44.com/register?inviteCode=J86AWZN&from`;

    const fallbackCopy = () => {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        soundEngine.cash();
        showToast(text);
      } catch {
        showToast(text);
      }
    };

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(text)
        .then(() => {
          soundEngine.cash();
          showToast(text);
        })
        .catch(() => fallbackCopy());
    } else {
      fallbackCopy();
    }
  };

  const handleTestPopup = (type: 'WIN' | 'LOSS' | 'JACKPOT') => {
    soundEngine.key();
    const pred = prediction || { size: 'BIG' as const, ball: 7 };
    let entry: HistoryEntry;
    if (type === 'WIN') {
      entry = {
        id: `test_${Date.now()}`,
        period: String(Date.now()).slice(-6),
        predicted: pred.size,
        predictedBall: pred.ball,
        actualNumber: pred.size === 'BIG' ? 7 : 2,
        actualSize: pred.size,
        isWin: true,
        isJackpot: false,
        profit: 1.96,
        time: new Date().toLocaleTimeString(),
      };
    } else if (type === 'JACKPOT') {
      entry = {
        id: `test_${Date.now()}`,
        period: String(Date.now()).slice(-6),
        predicted: pred.size,
        predictedBall: pred.ball,
        actualNumber: pred.ball,
        actualSize: toSize(pred.ball),
        isWin: true,
        isJackpot: true,
        profit: 9,
        time: new Date().toLocaleTimeString(),
      };
    } else {
      entry = {
        id: `test_${Date.now()}`,
        period: String(Date.now()).slice(-6),
        predicted: pred.size,
        predictedBall: pred.ball,
        actualNumber: pred.size === 'BIG' ? 2 : 7,
        actualSize: pred.size === 'BIG' ? 'SMALL' : 'BIG',
        isWin: false,
        isJackpot: false,
        profit: -1,
        time: new Date().toLocaleTimeString(),
      };
    }

    const updated = [entry, ...storage.getHistory()].slice(0, 200);
    storage.saveHistory(updated);
    setTrackerHistory(updated);

    if (soundEngine.enabled) {
      if (entry.isJackpot) soundEngine.jackpot();
      else if (entry.isWin) soundEngine.win();
      else soundEngine.loss();
    }
    setPopupEntry(entry);
  };

  const handleManualResult = (isWin: boolean) => {
    soundEngine.key();
    const latest = history[0] || { issueNumber: getStandardWingoPeriod(-1), number: '5' };
    const entry: HistoryEntry = {
      id: `man_${Date.now()}`,
      period: latest.issueNumber,
      predicted: prediction?.size || 'BIG',
      predictedBall: prediction?.ball || 7,
      actualNumber: parseInt(latest.number, 10),
      actualSize: toSize(latest.number),
      isWin,
      isJackpot: false,
      profit: isWin ? 1.96 : -1,
      time: new Date().toLocaleTimeString(),
    };
    const updated = [entry, ...storage.getHistory()].slice(0, 200);
    storage.saveHistory(updated);
    setTrackerHistory(updated);
  };

  const handleConfirmAction = () => {
    if (confirmState.type === 'logout') {
      storage.clearSession();
      setSession(null);
      setPopupEntry(null);
      setActiveTab('rounds');
    } else if (confirmState.type === 'clearHistory') {
      storage.clearHistory();
      setTrackerHistory([]);
    }
    setConfirmState({ open: false, type: null });
  };

  const pillColors =
    liveStatus.status === 'off'
      ? 'bg-[#581C87]/30 border-[#581C87] text-[#D8B4FE]'
      : liveStatus.status === 'mock'
      ? 'bg-[#9333EA]/20 border-[#9333EA] text-[#F5D0FE]'
      : 'bg-[#00FF80]/15 border-[#00FF80] text-[#A7F3D0] shadow-[0_0_10px_rgba(0,255,128,0.25)]';

  const dotColors =
    liveStatus.status === 'off'
      ? 'bg-[#581C87]'
      : liveStatus.status === 'loading'
      ? 'bg-[#C084FC] shadow-[0_0_8px_#C084FC] animate-pulse-glow'
      : liveStatus.status === 'mock'
      ? 'bg-[#9333EA] shadow-[0_0_8px_#9333EA] animate-pulse-glow'
      : 'bg-[#00FF80] shadow-[0_0_8px_#00FF80] animate-pulse-glow';

  return (
    <>
      <StarfieldBackground />

      <div className="relative z-10 max-w-[540px] lg:max-w-[1040px] mx-auto px-2.5 sm:px-4 pt-2 pb-24 md:pb-8">
        {!session ? (
          <LoginGateway
            onSuccess={(newSess) => setSession(newSess)}
            onNotify={showToast}
          />
        ) : (
          <div className="animate-fade-in">
            <header className="flex items-center justify-between py-2 px-1 mb-2 gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-full border-2 border-[#00FF80] flex items-center justify-center font-orbitron font-black text-[#060D09] text-xs sm:text-[13px] shrink-0 shadow-[0_0_18px_rgba(0,255,128,0.5)]"
                  style={{ background: 'linear-gradient(135deg,#9333EA,#00CC66)' }}
                >
                  <span
                    className="absolute -inset-[3px] rounded-full border border-dashed border-[#00FF80]/60 animate-spin-slow pointer-events-none"
                    aria-hidden="true"
                  />
                  SD
                </div>
                <div className="min-w-0">
                  <div
                    className="font-orbitron text-sm sm:text-base font-black tracking-[1.2px] text-[#00FF80] leading-tight truncate"
                    style={{ textShadow: '0 0 10px rgba(0,255,128,.4)' }}
                  >
                    SDD PVT
                  </div>
                  <div className="text-[8px] sm:text-[8.5px] tracking-[1.2px] mt-0.5 text-[#A7F3D0] font-mono-jb font-bold truncate">
                    1000-RULE + TITAN 200 CORE
                  </div>
                </div>
              </div>

              <div
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-[20px] border text-[9.5px] sm:text-[10px] font-bold tracking-[0.8px] font-mono-jb shrink-0 whitespace-nowrap ${pillColors}`}
              >
                <span className={`w-[7px] h-[7px] rounded-full ${dotColors}`} />
                <span>{liveStatus.text}</span>
              </div>
            </header>

            <nav
              className="fixed bottom-0 left-0 right-0 z-40 md:static grid grid-cols-5 gap-1 p-1.5 pb-[max(0.4rem,env(safe-area-inset-bottom))] md:pb-1.5 bg-[#060D09]/95 md:bg-[#0A1810]/85 border-t md:border border-[#00FF80]/30 md:rounded-[22px] md:mb-3 backdrop-blur-md shadow-[0_-6px_24px_rgba(0,0,0,0.75)] md:shadow-none"
              aria-label="Primary Navigation"
            >
              {TABS.map(({ id, label, Icon }) => {
                const isActive = activeTab === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => handleTabChange(id)}
                    className={`min-h-[46px] py-1.5 px-1 rounded-2xl text-[8px] sm:text-[9px] font-orbitron tracking-[0.6px] cursor-pointer transition-all flex flex-col items-center justify-center gap-1 whitespace-nowrap ${
                      isActive
                        ? 'text-[#060D09] font-black shadow-[0_0_16px_rgba(0,255,128,0.5)]'
                        : 'text-[#A7F3D0] font-bold hover:text-[#00FF80]'
                    }`}
                    style={
                      isActive
                        ? { background: 'linear-gradient(135deg,#9333EA,#00FF80)' }
                        : undefined
                    }
                  >
                    <Icon className="w-[16px] h-[16px]" strokeWidth={2.5} />
                    <span>{label}</span>
                  </button>
                );
              })}
            </nav>

            <main>
              {activeTab === 'rounds' && (
                <RoundsTab
                  currentPeriod={currentPeriod}
                  secondsLeft={secondsLeft}
                  prediction={prediction}
                  history={history}
                  onCopyPrediction={handleCopyPrediction}
                  onForceSync={() => {
                    soundEngine.key();
                    void bootData(false);
                  }}
                  onTestPopup={handleTestPopup}
                />
              )}

              {activeTab === 'history' && (
                <HistoryTab
                  trackerHistory={trackerHistory}
                  onManualResult={handleManualResult}
                  onClearHistory={() => {
                    soundEngine.key();
                    setConfirmState({ open: true, type: 'clearHistory' });
                  }}
                />
              )}

              {activeTab === 'analytics' && (
                <AnalyticsTab history={history} prediction={prediction} />
              )}

              {activeTab === 'games' && <GamesTab />}

              {activeTab === 'account' && (
                <AccountTab
                  soundEnabled={soundEnabled}
                  mockMode={mockMode}
                  onToggleSound={() => {
                    soundEngine.key();
                    setSoundEnabled((prev) => !prev);
                  }}
                  onToggleMockMode={() => {
                    soundEngine.key();
                    const next = !mockMode;
                    setMockMode(next);
                    mockModeRef.current = next;
                    predictionRef.current = null;
                    lastIssueRef.current = null;
                    lastEvaluatedRef.current = null;
                    void bootData(false, next);
                  }}
                  onRequestLogout={() => {
                    soundEngine.key();
                    setConfirmState({ open: true, type: 'logout' });
                  }}
                />
              )}
            </main>
          </div>
        )}
      </div>

      <ResultPopup entry={popupEntry} onClose={() => setPopupEntry(null)} />

      <ConfirmModal
        open={confirmState.open}
        title={confirmState.type === 'logout' ? 'LOGOUT CONFIRMATION' : 'CLEAR HISTORY'}
        message={
          confirmState.type === 'logout'
            ? 'Logout from SDD PVT?'
            : 'Clear all saved win/loss history records?'
        }
        confirmLabel={confirmState.type === 'logout' ? 'LOGOUT' : 'CLEAR'}
        onConfirm={handleConfirmAction}
        onCancel={() => setConfirmState({ open: false, type: null })}
      />

      {toastText && (
        <div
          className="fixed bottom-24 md:bottom-6 left-1/2 -translate-x-1/2 bg-[#0C1C13] border-2 border-[#00FF80] rounded-xl px-4 py-2.5 text-[11px] font-bold text-[#00FF80] z-[9000] shadow-[0_0_24px_rgba(0,255,128,0.5)] w-[92%] sm:w-auto max-w-[420px] whitespace-pre-line break-words text-center font-mono-jb"
          role="status"
        >
          {toastText}
        </div>
      )}
    </>
  );
}

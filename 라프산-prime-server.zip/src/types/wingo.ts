export type DirectionSize = 'BIG' | 'SMALL';

export type TabId = 'rounds' | 'history' | 'analytics' | 'games' | 'account';

export type LiveStatus = 'live' | 'loading' | 'mock' | 'off';

export type PatternCategory =
  | 'DRAGON'
  | 'STREAK3'
  | 'BREAK'
  | 'ZIGZAG'
  | 'MACRO'
  | 'TITAN200'
  | 'RULE1000'
  | 'FORMULA';

export interface DrawRecord {
  issueNumber: string;
  number: string;
}

export interface PatternRule {
  id: string;
  cat: PatternCategory;
  name: string;
  dir: DirectionSize;
  w: number;
  conf: number;
  desc: string;
}

export interface EngineTelemetry {
  titan200Triggered: number;
  titan200TopPattern: string;
  formulaName: string;
  formulaScore: number;
  samadHash: number | null;
  samadSize: DirectionSize | null;
  regimeName: string;
  regimeIcon: string;
  oracleMatch: { next: DirectionSize; occ: number; rate: number } | null;
  rules1000Triggered: number;
  rules1000BigScore: number;
  rules1000SmallScore: number;
  rules1000Confidence: number;
  recoveryActive: boolean;
  triColor: string;
}

export interface CombinedAnalysis {
  patterns: PatternRule[];
  top: PatternRule | null;
  votesBig: number;
  votesSmall: number;
  direction: DirectionSize;
  confidence: number;
  telemetry: EngineTelemetry;
}

export interface PredictionResult {
  period: string;
  size: DirectionSize;
  color: string;
  ball: number;
  opposite: number;
  safe: number[];
  level: number;
  mult: string;
  confidence: number;
  algo: string;
  combined: CombinedAnalysis;
}

export interface HistoryEntry {
  id: string;
  period: string;
  predicted: DirectionSize;
  predictedBall: number;
  actualNumber: number;
  actualSize: DirectionSize;
  isWin: boolean;
  isJackpot: boolean;
  profit: number;
  time: string;
}

export interface UserSession {
  key: string;
  device: string;
  at: number;
  lifetime: boolean;
  token?: string;
}
